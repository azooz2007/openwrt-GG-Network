'use strict';
'require baseclass';
'require dom';
'require ggnet.common as gg';

/*
 * Smart route (beta, spec 1.42) on the connection card: the player's pick
 * (Normal route or Smart route, like the Normal / Aggressive choice), the
 * route the server chose for each game server, from the first server to the exit,
 * and the routes of this connection.
 *
 * BETA: may be removed with ggnetd core/smartroute.go. network.js only does
 * `smartmod.create(onChange)`, puts `.node` on the card and calls
 * `.update(st)` (lines marked "beta (smartroute.js)").
 */

function show(el, on) { el.style.display = on ? '' : 'none'; }

var styleDone = false;
function injectStyle() {
	if (styleDone || !document.head)
		return;
	styleDone = true;
	document.head.appendChild(E('style', { 'type': 'text/css' }, [
		'.gg-smart-beta{font-size:70%;font-weight:bold;letter-spacing:.05em;padding:0 .4em;border-radius:3px;background:#d29922;color:#fff;margin-left:.4em;vertical-align:middle}' +
		'.gg-smart-line{margin:.25em 0;line-height:1.7}' +
		'.gg-smart-exit{font-weight:bold;color:#1a7f37;border:1px solid #1a7f37;border-radius:4px;padding:0 .35em}' +
		'.gg-smart-hint{color:#d29922;margin-top:.3em}' +
		'.gg-smart-note{opacity:.75;font-size:90%;margin-top:.3em}' +
		'.gg-smart-tbl{border-collapse:collapse;font-size:90%;margin-top:.4em}' +
		'.gg-smart-tbl th,.gg-smart-tbl td{padding:.2em .6em;border-bottom:1px solid rgba(128,128,128,.25);text-align:left;vertical-align:top}'
	]));
}

var SmartView = baseclass.extend({
	__init__: function(onChange) {
		var self = this;
		injectStyle();
		this.onChange = onChange;
		this.sel = E('select', { 'class': 'cbi-input-select', 'change': function() { self.pick(); } }, [
			E('option', { 'value': '0' }, _('Normal route')),
			E('option', { 'value': '1' }, '🧭 ' + _('Smart route'))
		]);
		this.title = E('span', {}, '🧭 ' + _('Smart route'));
		this.hint = E('div', { 'class': 'gg-smart-hint', 'style': 'display:none' });
		this.note = E('div', { 'class': 'gg-smart-note', 'style': 'display:none' });
		this.lines = E('div', { 'style': 'display:none;margin-top:.4em' });
		this.tblBody = E('tbody');
		this.details = E('details', { 'style': 'display:none;margin-top:.4em' }, [
			E('summary', { 'style': 'cursor:pointer' }, _('Routes of this connection')),
			E('div', { 'style': 'overflow-x:auto' }, E('table', { 'class': 'gg-smart-tbl' }, [
				E('thead', {}, E('tr', {}, [ _('Game server'), _('Path'), _('Exit'), _('ms'), _('Saved'), _('How measured') ].map(function(h) { return E('th', {}, h); }))),
				this.tblBody
			]))
		]);
		this.node = E('div', { 'class': 'gg-frow', 'style': 'display:none' }, [
			E('div', { 'class': 'gg-frow-label' }, [ this.title, E('span', { 'class': 'gg-smart-beta', 'title': _('A beta: GGamers may remove it.') }, _('BETA')) ]),
			E('div', { 'class': 'gg-frow-field' }, [ this.sel, this.hint, this.note, this.lines, this.details ])
		]);
	},

	pick: function() {
		var self = this, on = this.sel.value === '1';
		this.busy = true;
		if (this.st && this.st.smart_route) {
			this.st.smart_route.chosen = on;
			this.update(this.st);
		}
		gg.act('smart_set', { on: on }, _('Smart route')).then(function() {
			self.busy = false;
			if (self.onChange)
				self.onChange();
		});
	},

	update: function(st) {
		this.st = st;
		var sr = st.smart_route;
		show(this.node, !!sr);
		if (!sr)
			return;
		if (!this.busy && document.activeElement !== this.sel)
			this.sel.value = sr.chosen ? '1' : '0';
		if (sr.label)
			this.title.textContent = '🧭 ' + String(sr.label);

		var sel = String(st.selected || ''), combo = sel.indexOf('combo:') === 0;
		var hint = '', note = '';
		if (sr.chosen) {
			if (combo)
				hint = _('A combo keeps its own route: Smart route is used when you connect to a server.');
			else if (sel && !sr.server_smart)
				hint = _('This server can\'t do Smart route yet: it connects as before.');
			else if (sr.refused)
				hint = _('The server refused Smart route: connected without it until the next start.');
			else if (st.aggr_effective && !sr.aggressive && (st.aggressive_mode || {}).enabled)
				note = _('Aggressive mode carries the game: Smart route is used for the connections outside it.');
			else if (!st.running)
				note = _('From your next connection: GGamers takes each game server out through the fastest of up to %d servers, and only detours when it is clearly faster. Running games never switch paths.').format(Number(sr.max_nodes) || 3);
		}
		else if (st.running)
			note = _('Picking Smart route applies to new game connections; running games keep theirs.');
		this.hint.textContent = hint;
		show(this.hint, !!hint);
		this.note.textContent = note;
		show(this.note, !!note);

		var routes = Array.isArray(sr.routes) ? sr.routes : [];
		show(this.lines, !!sr.in_use);
		show(this.details, !!sr.in_use && routes.length > 0);
		if (!sr.in_use)
			return;

		var sig = JSON.stringify([ routes, st.selected_ping_ms, Math.floor(Date.now() / 60000) ]);   /* minute: the 10-minute window moves */
		if (sig === this.sig)
			return;
		this.sig = sig;

		var cc = {};
		(Array.isArray(st.servers) ? st.servers : []).forEach(function(s) { cc[String(s.name).toLowerCase()] = String(s.cc || ''); });
		var node = function(name, exit) {
			var f = gg.flag(cc[String(name).toLowerCase()] || '');
			return exit ? E('span', { 'class': 'gg-smart-exit', 'title': _('The exit: what the game server sees') }, [ f, f ? ' ' : '', String(name), ' ', _('(exit)') ])
				: E('span', {}, [ f, f ? ' ' : '', String(name) ]);
		};
		var mine = Number(st.selected_ping_ms);
		var you = mine > 0 ? _('You (%d ms)').format(Math.round(mine)) : _('You');

		/* spec 1.43: one line per game server (dest) of the last 10 minutes, newest first
		 * (routes come newest first), each with its own exit; no game name */
		var seen = {}, lines = [], recent = Date.now() - 600000;
		routes.forEach(function(r) {
			var d = String(r.dest || ''), at = Date.parse(String(r.at || ''));
			if (seen[d] || (!isNaN(at) && at < recent))
				return;
			seen[d] = true;
			var path = Array.isArray(r.path) ? r.path : [];
			var parts = [ you ];
			path.forEach(function(n, i) { parts.push(' → ', node(n, i === path.length - 1)); });
			parts.push(' → ', d || _('game server'));
			if (Number(r.ms) > 0)   /* 0 = no number yet: the path alone */
				parts.push(' · ', E('b', {}, _('%d ms').format(Math.round(Number(r.ms)))));
			if (path.length <= 1)
				parts.push(' · ', E('span', { 'style': 'opacity:.7' }, _('direct is fastest')));
			else if (Number(r.saved_ms) > 0)
				parts.push(' · ', E('span', { 'style': 'opacity:.7' }, _('saves %d ms').format(Math.round(Number(r.saved_ms)))));
			lines.push(E('div', { 'class': 'gg-smart-line' }, parts));
		});
		if (!lines.length)
			lines.push(E('div', { 'class': 'gg-smart-line' }, '🧭 ' + _('Smart route on · choosing the best path…')));
		dom.content(this.lines, lines);

		dom.content(this.tblBody, routes.map(function(r) {
			var path = Array.isArray(r.path) ? r.path : [];
			var c = String(r.country || '').toUpperCase();
			return E('tr', {}, [
				E('td', {}, [ gg.flag(c), gg.isCountry(c) ? ' ' : '', String(r.dest || '') ]),
				E('td', {}, path.join(' → ')),
				E('td', {}, String(r.exit || path[path.length - 1] || '')),
				E('td', {}, Number(r.ms) > 0 ? String(Math.round(Number(r.ms))) : '–'),
				E('td', {}, Number(r.saved_ms) > 0 ? String(Math.round(Number(r.saved_ms))) : '–'),
				E('td', {}, String(r.how || ''))
			]);
		}));
	}
});

return baseclass.extend({
	/* onChange: called after the pick was saved (network.js polls the status) */
	create: function(onChange) { return new SmartView(onChange); }
});
