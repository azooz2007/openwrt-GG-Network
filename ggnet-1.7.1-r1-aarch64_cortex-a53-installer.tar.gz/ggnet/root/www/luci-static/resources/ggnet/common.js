'use strict';
'require baseclass';
'require rpc';
'require ui';
'require dom';

/*
 * Shared helpers for the GG Network LuCI views.
 * Backend contract: docs/RPC.md (rpcd object "ggnet").
 */

var METHODS = {
	status:        [],
	login:         [ 'username', 'password', 'remember', 'captcha_id', 'captcha' ],
	captcha:       [],
	logout:        [],
	select:        [ 'target' ],
	start:         [],
	stop:          [],
	aggr_set:      [ 'on', 'udp', 'tcp', 'duplicate', 'shortcut' ],
	smart_set:     [ 'on' ],   /* beta (smartroute.go) */
	refresh:       [],
	combos:        [],
	combo_nodes:   [],
	combo_probe:   [ 'node_id' ],
	combo_create:  [ 'name', 'hops', 'isp', 'target_country', 'connection_type', 'user_ping_ms', 'game_host', 'game_port' ],
	combo_edit:    [ 'id', 'name', 'hops', 'isp', 'target_country', 'connection_type', 'user_ping_ms', 'game_host', 'game_port' ],
	combo_delete:  [ 'id' ],
	combo_attach:  [ 'id' ],
	combo_detach:  [ 'id' ],
	marketplace:   [ 'continent', 'country', 'q', 'page' ],
	chat:          [],
	chat_send:     [ 'text' ],
	chat_history:  [ 'before' ],
	log:           [ 'since' ],
	/* v1.1 */
	devices:       [],
	settings_get:  [],
	settings_set:  [ 'settings' ],
	preset_apply:  [],
	connections:   [ 'direct' ],
	conn_close:    [ 'id' ],
	traffic:       [],
	/* v1.2 */
	geoip:         [ 'host' ],
	conn_test:     [],
	/* v1.3 */
	direct_ping:   [ 'host', 'port' ],
	/* v1.2.0: Investigation mode */
	problem_report: [ 'note', 'ago_min', 'happened_at' ],
	/* v1.3.0 */
	chat_command:   [ 'cmd' ],
	combo_gameprobe: [ 'node_id', 'host', 'port' ],
	update_check:   [],
	update_install: []
};

var rpcFns = {};
Object.keys(METHODS).forEach(function(m) {
	rpcFns[m] = rpc.declare({
		object: 'ggnet',
		method: m,
		params: METHODS[m],
		expect: { '': {} }
	});
});

var DAEMON_DOWN_MSG = _('The GG Network service isn\'t running — start it in System → Startup (ggnet).');

var ERROR_TEXT = {
	daemon_down:         DAEMON_DOWN_MSG,
	busy:                _('GG Network is busy: the GGamers panel is slow to answer. Try again in a moment.'),
	not_signed_in:       _('You are not signed in.'),
	bad_request:         _('The request was not valid.'),
	network:             _('Can\'t reach GGamers. Check the router\'s internet connection.'),
	tampered:            _('The answer from GGamers could not be verified (signature invalid). Your connection may be intercepted.'),
	invalid_credentials: _('Wrong username or password.'),
	captcha_required:    _('Type the characters in the picture to sign in.'),
	locked:              _('Too many wrong tries. Wait and try again.'),
	ip_banned:           _('This network is blocked from signing in. Contact GGamers support.'),
	banned:              _('This account is banned.'),
	disabled:            _('This account is disabled. Contact support.'),
	device_limit:        _('This account is already used on the maximum number of devices.'),
	rate_limited:        _('Too many requests — wait a moment and retry.'),
	too_frequent:        _('Too many requests — wait a few seconds and retry.'),
	daily_limit:         _('Daily limit reached — try again tomorrow.'),
	investigation_off:   _('Problem reports aren\'t being collected right now.'),
	feature_disabled:    _('This feature is turned off by GGamers right now.'),
	maintenance:         _('GGamers is under maintenance.'),
	unavailable:         _('Not available right now.'),
	invalid_combo:       _('This combo can\'t be saved.'),
	running:             _('Stop the connection first to switch to another server or combo.'),
	unreachable:         _('The game server doesn\'t answer (neither ICMP nor TCP).'),
	failed:              _('The action failed.')
};

function errorText(res) {
	if (!res)
		return _('Unknown error');
	if (res.error === 'daemon_down')
		return DAEMON_DOWN_MSG;
	if (res.message)
		return String(res.message);
	if (res.error && ERROR_TEXT[res.error])
		return ERROR_TEXT[res.error];
	return res.error ? _('Error: %s').format(res.error) : _('Unknown error');
}

/* Call an ggnet method with a named-args object. Never rejects:
 * transport errors are turned into {ok:false, error:'daemon_down', ...}. */
function call(method, args) {
	var fn = rpcFns[method];
	if (!fn)
		return Promise.resolve({ ok: false, error: 'bad_request', message: 'unknown method ' + method });

	var a = args || {};
	var pos = METHODS[method].map(function(k) { return a[k]; });

	return fn.apply(null, pos).then(function(res) {
		if (!res || typeof res !== 'object' || Object.keys(res).length === 0)
			return { ok: false, error: 'daemon_down', message: DAEMON_DOWN_MSG };
		if (res.ok === false && res.error === 'daemon_down')
			res.message = DAEMON_DOWN_MSG;
		return res;
	}).catch(function(err) {
		/* LuCI gives up after its own timeout while ggnetd is still working (usually the
		 * GGamers panel is slow): that is "busy", not "not running" */
		if (/time(d)? ?out/i.test(String(err)))
			return { ok: false, error: 'busy', message: ERROR_TEXT.busy, detail: String(err) };
		return { ok: false, error: 'daemon_down', message: DAEMON_DOWN_MSG, detail: String(err) };
	});
}

function notify(res, prefix) {
	var msg = errorText(res);
	if (res && res.error === 'no_devices') {
		/* "Only the devices below" with nothing to capture: a popup that leads to the list */
		ui.showModal(_('Choose your devices'), [
			E('p', {}, [ msg ]),
			E('div', { 'class': 'right' }, [
				E('button', { 'class': 'btn', 'click': ui.hideModal }, _('Close')), ' ',
				E('button', { 'class': 'btn cbi-button-action', 'click': function() {
					ui.hideModal();
					window.location.href = L.url('admin/services/ggnet/settings');
				} }, _('Open Settings'))
			])
		]);
		return;
	}
	ui.addNotification(null, E('p', {}, [ prefix ? prefix + ': ' + msg : msg ]), 'danger');
}

/* call() that shows a notification on failure; resolves to the result. */
function act(method, args, prefix) {
	return call(method, args).then(function(res) {
		if (!res.ok)
			notify(res, prefix);
		return res;
	});
}

function formatBytes(n) {
	if (n === -1 || n === '-1')
		return _('Unlimited');
	n = Number(n);
	if (!isFinite(n) || n < 0)
		return '–';
	var units = [ 'B', 'KB', 'MB', 'GB', 'TB', 'PB' ], i = 0;
	while (n >= 1024 && i < units.length - 1) { n /= 1024; i++; }
	return (i === 0 ? n.toFixed(0) : n.toFixed(n >= 100 ? 0 : (n >= 10 ? 1 : 2))) + ' ' + units[i];
}

function formatDuration(sec) {
	sec = Math.max(0, Math.floor(Number(sec) || 0));
	var d = Math.floor(sec / 86400), h = Math.floor(sec % 86400 / 3600),
	    m = Math.floor(sec % 3600 / 60), s = sec % 60;
	if (d > 0) return '%dd %dh %dm'.format(d, h, m);
	if (h > 0) return '%dh %dm %ds'.format(h, m, s);
	if (m > 0) return '%dm %ds'.format(m, s);
	return '%ds'.format(s);
}

/* ts: unix seconds (number) or ISO string → local date/time string */
function toDate(ts) {
	if (ts == null || ts === '')
		return null;
	var d = (typeof ts === 'number') ? new Date(ts * 1000) : new Date(ts);
	return isNaN(d.getTime()) ? null : d;
}

function formatTime(ts, timeOnly) {
	var d = toDate(ts);
	if (!d)
		return '–';
	return timeOnly ? d.toLocaleTimeString() : d.toLocaleString();
}

function formatMs(v) {
	if (v == null || v === '' || Number(v) < 0 || !isFinite(Number(v)))
		return '–';
	return Math.round(Number(v)) + ' ms';
}

/* latency colours (green < 80 ms, amber < 150 ms, red from 150 ms) */
var PING_GOOD = '#2ea043', PING_MID = '#d29922', PING_BAD = '#e04848';

function pingColor(v) {
	v = Number(v);
	if (!isFinite(v) || v < 0) return PING_BAD;
	return v < 80 ? PING_GOOD : (v < 150 ? PING_MID : PING_BAD);
}

/* Latency pill: null/undefined = "measuring…", < 0 = "not answering", else "N ms". */
function pingBadge(v) {
	var base = 'display:inline-block;padding:.05em .55em;border-radius:10px;font-size:85%;font-weight:bold;white-space:nowrap;';
	if (v == null || v === '' || !isFinite(Number(v)))
		return E('span', { 'style': base + 'border:1px solid rgba(128,128,128,.5);opacity:.75;font-weight:normal' }, [ _('measuring…') ]);
	if (Number(v) < 0)
		return E('span', { 'style': base + 'color:#fff;background:' + PING_BAD }, [ _('not answering') ]);
	return E('span', { 'style': base + 'color:#fff;background:' + pingColor(v) }, [ Math.round(Number(v)) + ' ms' ]);
}

function formatNum(n) {
	n = Number(n) || 0;
	return n.toLocaleString();
}

var ROLE_COLOR = {
	administrator: '#ff6a3d',
	admin:         '#ff4fd8',
	moderator:     '#3fb950',
	ambassador:    '#e3b341',
	active:        '#58a6ff',
	inactive:      '#8b98a8'
};

var ROLE_BADGE = {
	administrator: 'ADMINISTRATOR',
	admin:         'ADMIN',
	moderator:     'MOD'
};

function roleColor(role) { return ROLE_COLOR[role] || ROLE_COLOR.inactive; }
function roleBadge(role) { return ROLE_BADGE[role] || ''; }

function badgeEl(text, color) {
	return E('span', {
		'style': 'display:inline-block;padding:0 .45em;margin-left:.4em;border-radius:3px;font-size:85%;font-weight:bold;color:#fff;background:' + (color || '#888')
	}, [ String(text == null ? '' : text) ]);
}

/* ISO 3166-1 alpha-2 codes */
var COUNTRY_CODES = (
	'AD AE AF AG AI AL AM AO AQ AR AS AT AU AW AX AZ BA BB BD BE BF BG BH BI BJ BL BM BN BO BQ BR BS BT BV BW BY BZ ' +
	'CA CC CD CF CG CH CI CK CL CM CN CO CR CU CV CW CX CY CZ DE DJ DK DM DO DZ EC EE EG EH ER ES ET FI FJ FK FM FO FR ' +
	'GA GB GD GE GF GG GH GI GL GM GN GP GQ GR GS GT GU GW GY HK HM HN HR HT HU ID IE IL IM IN IO IQ IR IS IT JE JM JO JP ' +
	'KE KG KH KI KM KN KP KR KW KY KZ LA LB LC LI LK LR LS LT LU LV LY MA MC MD ME MF MG MH MK ML MM MN MO MP MQ MR MS MT ' +
	'MU MV MW MX MY MZ NA NC NE NF NG NI NL NO NP NR NU NZ OM PA PE PF PG PH PK PL PM PN PR PS PT PW PY QA RE RO RS RU RW ' +
	'SA SB SC SD SE SG SH SI SJ SK SL SM SN SO SR SS ST SV SX SY SZ TC TD TF TG TH TJ TK TL TM TN TO TR TT TV TW TZ UA UG ' +
	'UM US UY UZ VA VC VE VG VI VN VU WF WS YE YT ZA ZM ZW'
).split(' ');

var COUNTRY_SET = {};
COUNTRY_CODES.forEach(function(c) { COUNTRY_SET[c] = true; });

/* Country names: ggnet/geo/countries.json ({"FR":{"n":"France","c":"eu",…}}),
 * loaded once; Intl.DisplayNames until it arrives (or if it fails). */
var geoInfo = null;          /* the parsed countries.json */
var countryCache = null;     /* sorted [{code, name, continent}] */
var countryPromise = null;
var displayNames;

function intlName(cc) {
	if (displayNames === undefined) {
		try { displayNames = new Intl.DisplayNames([ 'en' ], { type: 'region' }); } catch (e) { displayNames = null; }
	}
	try { if (displayNames) return displayNames.of(cc) || cc; } catch (e) {}
	return cc;
}

function loadCountries() {
	if (!countryPromise)
		countryPromise = fetch(L.resource('ggnet/geo/countries.json'), { credentials: 'same-origin' }).then(function(r) {
			if (!r.ok)
				throw new Error('HTTP ' + r.status);
			return r.json();
		}).then(function(info) {
			if (info && typeof info === 'object') {
				geoInfo = {};
				Object.keys(info).forEach(function(k) {
					if (/^[A-Za-z]{2}$/.test(k))
						geoInfo[k.toUpperCase()] = info[k] || {};
				});
				countryCache = null;
			}
			return countries();
		}).catch(function() {
			return countries();
		});
	return countryPromise;
}

/* sorted list, synchronous: from countries.json when loaded, else Intl */
function countries() {
	if (countryCache)
		return countryCache;
	var codes = geoInfo ? Object.keys(geoInfo) : COUNTRY_CODES;
	var list = codes.map(function(c) {
		var i = geoInfo && geoInfo[c];
		return { code: c, name: (i && i.n) ? String(i.n) : intlName(c), continent: (i && i.c) || '' };
	}).sort(function(a, b) { return a.name.localeCompare(b.name); });
	if (geoInfo)
		countryCache = list;
	return list;
}

function isCountry(cc) {
	if (!cc || typeof cc !== 'string' || !/^[A-Za-z]{2}$/.test(cc))
		return false;
	cc = cc.toUpperCase();
	return geoInfo ? !!geoInfo[cc] || !!COUNTRY_SET[cc] : !!COUNTRY_SET[cc];
}

function countryName(cc) {
	if (!cc) return '';
	cc = String(cc).toUpperCase();
	var i = geoInfo && geoInfo[cc];
	if (i && i.n)
		return String(i.n);
	return /^[A-Z]{2}$/.test(cc) ? intlName(cc) : cc;
}

/* ------------------------------------------------------------------ */
/* Flags (local PNGs — Windows browsers can't show flag emoji)        */
/* ------------------------------------------------------------------ */

var styleDone = false;
function injectStyle() {
	if (styleDone || !document.head)
		return;
	styleDone = true;
	var css =
		'.gg-flag{display:inline-block;height:14px;width:auto;border-radius:2px;vertical-align:middle;' +
			'box-shadow:0 0 0 1px rgba(128,128,128,.35);margin:0 .1em;position:relative;top:-1px}' +
		'.gg-pick{position:relative;display:inline-block;max-width:100%;vertical-align:middle}' +
		'.gg-pick-btn{display:inline-flex !important;align-items:center;gap:.5em;justify-content:space-between;text-align:left;' +
			'width:100%;max-width:100%;min-width:12em;height:auto !important;min-height:2.2em;white-space:nowrap;overflow:hidden;cursor:pointer;margin:0}' +
		'.gg-pick-btn[disabled]{cursor:not-allowed;opacity:.6}' +
		'.gg-pick-label{overflow:hidden;text-overflow:ellipsis;flex:1 1 auto;min-width:0;font-weight:normal}' +
		'.gg-pick-ph{opacity:.6}' +
		'.gg-pick-caret{opacity:.6;flex:none;font-size:80%}' +
		'.gg-pick-pop{position:absolute;z-index:1100;left:0;top:100%;margin-top:2px;min-width:100%;max-width:min(40em,94vw);' +
			'box-sizing:border-box;border:1px solid rgba(128,128,128,.5);border-radius:4px;box-shadow:0 6px 18px rgba(0,0,0,.28);padding:.3em}' +
		'.gg-pick-pop.right{left:auto;right:0}' +
		'.gg-pick-search{width:100% !important;box-sizing:border-box;margin:0 0 .3em 0 !important}' +
		'.gg-pick-list{max-height:20em;overflow:auto}' +
		'.gg-pick-item{padding:.3em .5em;border-radius:3px;cursor:pointer;white-space:nowrap}' +
		'.gg-pick-item.act{background:rgba(88,166,255,.2)}' +
		'.gg-pick-item.sel{font-weight:bold}' +
		'.gg-pick-item.dis{opacity:.45;cursor:not-allowed}' +
		'.gg-pick-sub{opacity:.65;font-size:85%;margin-left:.5em}' +
		'.gg-pick-empty{padding:.3em .5em;opacity:.65}';
	document.head.appendChild(E('style', { 'type': 'text/css' }, [ css ]));
}

function flagUrl(cc) {
	if (!isCountry(cc))
		return '';
	return L.resource('ggnet/flags/' + cc.toLowerCase() + '.png');
}

/* <img class="gg-flag"> for a country code, or '' (an empty text child) when unknown.
 * opts: {size: px height (14), title: tooltip (country name), style: extra css} */
function flag(cc, opts) {
	opts = opts || {};
	if (!isCountry(cc))
		return '';
	injectStyle();
	var CC = cc.toUpperCase();
	var h = Number(opts.size) > 0 ? Number(opts.size) : 14;
	var img = E('img', {
		'class': 'gg-flag',
		'src': flagUrl(CC),
		'alt': CC,
		'title': opts.title != null ? String(opts.title) : countryName(CC),
		'loading': 'lazy',
		'style': 'height:' + h + 'px' + (opts.style ? ';' + opts.style : '')
	});
	img.addEventListener('error', function() { img.style.display = 'none'; });
	return img;
}

/* [flag, ' ', text] as a safe children array (text defaults to the country name) */
function ccLabel(cc, text) {
	var f = flag(cc);
	var t = String(text != null ? text : countryName(cc));
	return f ? [ f, ' ' + t ] : [ t ];
}

/* only http(s) links from the daemon */
function safeUrl(u) {
	u = String(u == null ? '' : u).trim();
	return /^https?:\/\/[^\s"'<>]+$/i.test(u) ? u : '';
}

/* nearest opaque background colour (for popups in light and dark themes) */
function pageBackground(el) {
	var n = el || document.body;
	while (n && n.nodeType === 1) {
		var bg = window.getComputedStyle(n).backgroundColor || '';
		var m = bg.match(/rgba?\(([\d.]+)[, ]+([\d.]+)[, ]+([\d.]+)(?:[, /]+([\d.]+))?/);
		if (m && (m[4] == null || Number(m[4]) > 0.5))
			return bg;
		n = n.parentNode;
	}
	return '#fff';
}

/*
 * Small searchable dropdown that can show flags (a <select> can't hold images).
 *   var p = picker({ items: [{value, label, cc, sub, disabled, search, content: fn→children}],
 *                    value, placeholder, search: true, searchPlaceholder, style, onChange(value, item) });
 *   p.node; p.getValue(); p.setValue(v); p.setItems(list); p.setDisabled(b); p.isOpen(); p.close()
 * All text is inserted as text nodes.
 */
function picker(opts) {
	opts = opts || {};
	injectStyle();

	var items = [], value = opts.value != null ? String(opts.value) : '';
	var isOpen = false, shown = [], active = -1, disabled = false;

	var label = E('span', { 'class': 'gg-pick-label' });
	var btn = E('button', {
		'type': 'button',
		'class': 'btn cbi-button gg-pick-btn',
		'aria-haspopup': 'listbox'
	}, [ label, E('span', { 'class': 'gg-pick-caret' }, [ '▼' ]) ]);
	var search = opts.search === false ? null : E('input', {
		'type': 'search', 'class': 'cbi-input-text gg-pick-search',
		'placeholder': opts.searchPlaceholder || _('Search…'),
		'autocomplete': 'off', 'autocapitalize': 'off', 'spellcheck': 'false'
	});
	var list = E('div', { 'class': 'gg-pick-list', 'role': 'listbox' });
	var pop = E('div', { 'class': 'gg-pick-pop', 'style': 'display:none' }, search ? [ search, list ] : [ list ]);
	var node = E('div', { 'class': 'gg-pick', 'style': opts.style || '' }, [ btn, pop ]);

	var content = function(it) {
		var c = [];
		var f = it.cc ? flag(it.cc) : '';
		if (f) c.push(f, ' ');
		if (typeof it.content === 'function')
			c = c.concat(it.content());
		else
			c.push(String(it.label == null ? '' : it.label));
		if (it.sub)
			c.push(E('span', { 'class': 'gg-pick-sub' }, [ String(it.sub) ]));
		return c;
	};

	var find = function(v) {
		for (var i = 0; i < items.length; i++)
			if (String(items[i].value) === v) return items[i];
		return null;
	};

	var renderLabel = function() {
		var it = find(value);
		if (it)
			dom.content(label, content(it));
		else
			dom.content(label, [ E('span', { 'class': 'gg-pick-ph' }, [ String(opts.placeholder || _('— choose —')) ]) ]);
		btn.title = it ? String(it.search || it.label || '') : '';
	};

	var matches = function(it, q) {
		if (!q) return true;
		var hay = [ it.search, it.label, it.sub, it.cc, it.cc ? countryName(it.cc) : '' ].join(' ').toLowerCase();
		return hay.indexOf(q) >= 0;
	};

	var setActive = function(i) {
		active = i;
		var kids = list.querySelectorAll('.gg-pick-item');
		for (var k = 0; k < kids.length; k++)
			kids[k].classList.toggle('act', Number(kids[k].getAttribute('data-i')) === i);
		var a = list.querySelector('.gg-pick-item.act');
		if (a && a.scrollIntoView)
			a.scrollIntoView({ block: 'nearest' });
	};

	var renderList = function() {
		var q = search ? search.value.trim().toLowerCase() : '';
		shown = items.filter(function(it) { return matches(it, q); });
		if (!shown.length) {
			dom.content(list, [ E('div', { 'class': 'gg-pick-empty' }, [ _('No match') ]) ]);
			active = -1;
			return;
		}
		dom.content(list, shown.map(function(it, i) {
			return E('div', {
				'class': 'gg-pick-item' + (it.disabled ? ' dis' : '') + (String(it.value) === value ? ' sel' : ''),
				'role': 'option',
				'data-i': String(i),
				'mousedown': function(ev) { ev.preventDefault(); },
				'click': function(ev) { ev.preventDefault(); choose(it); },
				'mousemove': function() { if (active !== i) setActive(i); }
			}, content(it));
		}));
		var sel = -1;
		shown.forEach(function(it, i) { if (sel < 0 && String(it.value) === value) sel = i; });
		if (q || sel < 0)
			for (var i = 0; i < shown.length && sel < 0; i++)
				if (!shown[i].disabled) sel = i;
		setActive(sel);
	};

	var outside = function(ev) {
		if (!node.contains(ev.target))
			close();
	};

	var open = function() {
		if (isOpen || disabled)
			return;
		isOpen = true;
		pop.style.background = pageBackground(node);
		pop.style.color = window.getComputedStyle(node).color;
		pop.style.display = '';
		pop.classList.remove('right');
		var r = pop.getBoundingClientRect();
		if (r.right > (window.innerWidth || document.documentElement.clientWidth) - 4)
			pop.classList.add('right');
		if (search) {
			search.value = '';
			search.focus();
		}
		renderList();
		document.addEventListener('mousedown', outside, true);
		document.addEventListener('touchstart', outside, true);
	};

	var close = function() {
		if (!isOpen)
			return;
		isOpen = false;
		pop.style.display = 'none';
		document.removeEventListener('mousedown', outside, true);
		document.removeEventListener('touchstart', outside, true);
	};

	var choose = function(it) {
		if (!it || it.disabled)
			return;
		var changed = String(it.value) !== value;
		value = String(it.value);
		close();
		renderLabel();
		btn.focus();
		if (typeof opts.onChange === 'function' && (changed || opts.always))
			opts.onChange(value, it);
	};

	var move = function(dir) {
		if (!shown.length) return;
		var i = active;
		for (var n = 0; n < shown.length; n++) {
			i = (i + dir + shown.length) % shown.length;
			if (!shown[i].disabled) break;
		}
		setActive(i);
	};

	var onKey = function(ev) {
		if (!isOpen) {
			if (ev.key === 'ArrowDown' || ev.key === 'Enter' || ev.key === ' ') {
				ev.preventDefault();
				open();
			}
			return;
		}
		if (ev.key === 'ArrowDown') { ev.preventDefault(); move(1); }
		else if (ev.key === 'ArrowUp') { ev.preventDefault(); move(-1); }
		else if (ev.key === 'Enter') { ev.preventDefault(); choose(shown[active]); }
		else if (ev.key === 'Escape') { ev.preventDefault(); close(); btn.focus(); }
		else if (ev.key === 'Tab') close();
	};

	btn.addEventListener('click', function(ev) { ev.preventDefault(); isOpen ? close() : open(); });
	btn.addEventListener('keydown', onKey);
	if (search) {
		search.addEventListener('keydown', onKey);
		search.addEventListener('input', renderList);
	}

	var api = {
		node: node,
		getValue: function() { return value; },
		setValue: function(v) { value = v == null ? '' : String(v); renderLabel(); if (isOpen) renderList(); },
		setItems: function(list2) {
			items = Array.isArray(list2) ? list2.slice() : [];
			renderLabel();
			if (isOpen) renderList();
		},
		setDisabled: function(b) { disabled = !!b; btn.disabled = disabled; if (disabled) close(); },
		isOpen: function() { return isOpen; },
		hasFocus: function() { return isOpen || node.contains(document.activeElement); },
		close: close
	};
	api.setItems(opts.items || []);
	return api;
}

loadCountries();

function formatRate(n) {
	n = Number(n);
	if (!isFinite(n) || n < 0)
		return '–';
	return formatBytes(n) + '/s';
}

/* Copy text to the clipboard. navigator.clipboard needs a secure context
 * (routers are often plain http), so fall back to execCommand. Resolves to bool. */
function copyText(text) {
	text = String(text == null ? '' : text);
	var fallback = function() {
		var ta = E('textarea', { 'style': 'position:fixed;top:0;left:0;width:1px;height:1px;opacity:0', 'readonly': 'readonly' });
		ta.value = text;
		document.body.appendChild(ta);
		ta.select();
		var ok = false;
		try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
		document.body.removeChild(ta);
		return ok;
	};
	try {
		if (navigator.clipboard && window.isSecureContext)
			return navigator.clipboard.writeText(text).then(function() { return true; }, function() { return fallback(); });
	} catch (e) {}
	return Promise.resolve(fallback());
}

/* localStorage that never throws */
function storeGet(key, dflt) {
	try {
		var v = window.localStorage.getItem(key);
		return v == null ? dflt : v;
	} catch (e) { return dflt; }
}

function storeSet(key, value) {
	try { window.localStorage.setItem(key, String(value)); } catch (e) {}
}

/* ------------------------------------------------------------------ */
/* Emojis as Twemoji images (like the Windows client): Windows browsers */
/* can't draw flags, many joined emojis or newer ones. The images come  */
/* from the jsDelivr CDN (graphics © Twitter / X and contributors,      */
/* CC-BY 4.0); without internet the emoji stays text.                   */
/* ------------------------------------------------------------------ */

var TWEMOJI = 'https://cdn.jsdelivr.net/gh/jdecked/twemoji@15.1.0/assets/72x72/';

/* the same list as the Windows client (ChatEmoji.BlockedSequences) */
var BLOCKED_EMOJI = [ '🏳️‍🌈', '🏳️‍⚧️', '⚧️',
	'👩‍❤️‍👩', '👨‍❤️‍👨', '👩‍❤️‍💋‍👩', '👨‍❤️‍💋‍👨',
	'👨‍👨‍👦', '👨‍👨‍👧', '👨‍👨‍👧‍👦', '👨‍👨‍👦‍👦', '👨‍👨‍👧‍👧',
	'👩‍👩‍👦', '👩‍👩‍👧', '👩‍👩‍👧‍👦', '👩‍👩‍👦‍👦', '👩‍👩‍👧‍👧' ].map(function(s) { return s.replace(/️/g, ''); });

var EMOJI_RE = null;
try { EMOJI_RE = new RegExp('\\p{Extended_Pictographic}|\\p{Regional_Indicator}|[#*0-9]\\uFE0F?\\u20E3', 'u'); } catch (e) {}

function graphemes(s) {
	s = String(s == null ? '' : s);
	try {
		if (typeof Intl !== 'undefined' && Intl.Segmenter)
			return Array.from(new Intl.Segmenter(undefined, { granularity: 'grapheme' }).segment(s), function(x) { return x.segment; });
	}
	catch (e) {}
	return Array.from(s);
}

function isEmoji(g) { return !!EMOJI_RE && EMOJI_RE.test(g) && !/^[#*0-9]$/.test(g); }
function emojiBlocked(g) { return BLOCKED_EMOJI.indexOf(String(g).replace(/️/g, '')) >= 0 || /^⚧/.test(g); }

/* the text without the blocked emojis (used before sending, and for what is shown) */
function stripEmoji(text) {
	return graphemes(text).filter(function(g) { return !(isEmoji(g) && emojiBlocked(g)); }).join('');
}

/* Twemoji's file name: code points in lower-case hex joined by "-"; U+FE0F is dropped unless the
 * sequence has a ZWJ (U+200D), with the other spelling as the fallback */
function twemojiNames(g) {
	var cps = Array.from(g).map(function(c) { return c.codePointAt(0); });
	var hex = function(list) { return list.map(function(c) { return c.toString(16); }).join('-'); };
	var without = hex(cps.filter(function(c) { return c !== 0xFE0F; })), withFe = hex(cps);
	return cps.indexOf(0x200D) >= 0 ? [ withFe, without ] : [ without, withFe ];
}

function emojiImg(g, size) {
	var names = twemojiNames(g), i = 0;
	var img = E('img', {
		'src': TWEMOJI + names[0] + '.png', 'alt': g, 'title': g, 'draggable': 'false',
		'style': 'height:' + (size || 1.25) + 'em;width:' + (size || 1.25) + 'em;vertical-align:-0.25em;margin:0 .05em'
	});
	img.addEventListener('error', function() {
		if (++i < names.length && names[i] !== names[0])
			img.src = TWEMOJI + names[i] + '.png';
		else if (img.parentNode)
			img.parentNode.replaceChild(document.createTextNode(g), img);
	});
	return img;
}

/* text → children: plain text runs plus Twemoji <img> for every emoji (blocked ones left out) */
function emojiText(text, size) {
	var out = [], buf = '';
	graphemes(text).forEach(function(g) {
		if (!isEmoji(g)) { buf += g; return; }
		if (emojiBlocked(g)) return;
		if (buf) { out.push(buf); buf = ''; }
		out.push(emojiImg(g, size));
	});
	if (buf) out.push(buf);
	return out;
}

return baseclass.extend({
	call: call,
	act: act,
	notify: notify,
	errorText: errorText,
	DAEMON_DOWN_MSG: DAEMON_DOWN_MSG,
	formatBytes: formatBytes,
	formatDuration: formatDuration,
	formatTime: formatTime,
	formatMs: formatMs,
	formatNum: formatNum,
	pingColor: pingColor,
	pingBadge: pingBadge,
	toDate: toDate,
	flag: flag,
	flagUrl: flagUrl,
	ccLabel: ccLabel,
	isCountry: isCountry,
	picker: picker,
	pageBackground: pageBackground,
	safeUrl: safeUrl,
	ROLE_COLOR: ROLE_COLOR,
	roleColor: roleColor,
	roleBadge: roleBadge,
	badgeEl: badgeEl,
	countries: countries,
	loadCountries: loadCountries,
	countryName: countryName,
	formatRate: formatRate,
	copyText: copyText,
	storeGet: storeGet,
	storeSet: storeSet,
	graphemes: graphemes,
	emojiText: emojiText,
	emojiImg: emojiImg,
	stripEmoji: stripEmoji
});
