'use strict';
'require baseclass';
'require poll';
'require ui';
'require dom';
'require ggnet.common as gg';

/*
 * "Report a problem" (GGamers server 1.30, Investigation mode, client spec §13.3).
 * A floating button at the bottom right of every GG Network page. It shows only
 * while status.report.show is true and opens a small dialog; nothing is ever sent
 * by itself. Backend contract: docs/RPC.md "v1.2.0 additions: Investigation mode".
 */

var POLL_SEC = 5;
var AFTER_SEND_SEC = 120;
var NOTE_MAX = 1000;

var mounted = false;
var btn = null, btnLabel = null;
var lastStatus = null;
var show = false;
var blockedUntil = 0;       /* ms timestamp: keep the button disabled until then */
var ticker = null;
var listeners = [];

/* dialog state */
var dlgOpen = false, sending = false;

function now() { return Date.now(); }

function injectStyle() {
	if (document.getElementById('gg-report-style'))
		return;
	var css =
		'.gg-report-btn{position:fixed;right:16px;bottom:16px;z-index:1050;display:inline-flex !important;align-items:center;gap:.45em;' +
			'height:auto !important;padding:.5em .9em !important;border-radius:20px !important;box-shadow:0 3px 12px rgba(0,0,0,.3);' +
			'cursor:pointer;white-space:nowrap;margin:0 !important}' +
		'.gg-report-btn[disabled]{cursor:not-allowed;opacity:.6}' +
		'.gg-report-ico{font-size:110%;line-height:1}' +
		'.gg-report-dlg label.gg-rl{display:block;font-weight:bold;margin:.8em 0 .3em}' +
		'.gg-report-dlg textarea{width:100%;box-sizing:border-box;min-height:6em;resize:vertical}' +
		'.gg-report-dlg .gg-rcount{font-size:80%;opacity:.65;text-align:right}' +
		'.gg-report-dlg .gg-rwhen label{display:block;margin:.2em 0;font-weight:normal;cursor:pointer}' +
		'.gg-report-dlg .gg-rinfo{font-size:90%;opacity:.8;margin-top:.9em}' +
		'.gg-report-dlg .gg-rerr{margin-top:.8em}';
	document.head.appendChild(E('style', { 'type': 'text/css', 'id': 'gg-report-style' }, [ css ]));
}

function waitLeft() {
	return Math.max(0, Math.ceil((blockedUntil - now()) / 1000));
}

function block(sec) {
	sec = Number(sec) || 0;
	if (sec > 0)
		blockedUntil = Math.max(blockedUntil, now() + sec * 1000);
	update();
}

function update() {
	if (!btn)
		return;
	btn.style.display = show ? '' : 'none';
	var left = waitLeft();
	btn.disabled = left > 0 || dlgOpen;
	btn.title = left > 0
		? _('A report was just sent. You can send another one in %s.').format(gg.formatDuration(left))
		: _('Tell GGamers about a freeze, a disconnect or another problem. Your note and the app\'s recent log are sent.');

	if (left > 0 && !ticker)
		ticker = window.setInterval(function() {
			if (waitLeft() <= 0) {
				window.clearInterval(ticker);
				ticker = null;
			}
			update();
		}, 1000);
}

function applyStatus(st) {
	if (!st || st.ok === false)
		return;
	lastStatus = st;
	var r = st.report || {};
	show = !!r.show;
	if (Number(r.wait_sec) > 0)
		blockedUntil = Math.max(blockedUntil, now() + Number(r.wait_sec) * 1000);
	update();
	listeners.forEach(function(fn) {
		try { fn(st); } catch (e) {}
	});
}

function refresh() {
	return gg.call('status').then(applyStatus);
}

/* RFC 3339 from a datetime-local value (local time) */
function toRfc3339(v) {
	var d = new Date(v);
	if (isNaN(d.getTime()))
		return null;
	return d.toISOString();
}

function localInputValue(d) {
	var p = function(n) { return (n < 10 ? '0' : '') + n; };
	return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + 'T' + p(d.getHours()) + ':' + p(d.getMinutes());
}

function openDialog() {
	if (dlgOpen || waitLeft() > 0 || !show)
		return;

	var r = (lastStatus && lastStatus.report) || {};
	var inv = (lastStatus && lastStatus.investigation) || {};
	var minutes = Number(r.log_minutes) || Number(inv.log_minutes) || 10;
	var kb = Number(r.log_kb);

	var note = E('textarea', {
		'class': 'cbi-input-textarea', 'id': 'gg-report-note', 'maxlength': String(NOTE_MAX),
		'placeholder': _('Optional — e.g. "The game froze for a few seconds, then I was disconnected."')
	});
	var count = E('div', { 'class': 'gg-rcount' }, [ '0 / ' + NOTE_MAX ]);
	note.addEventListener('input', function() {
		if (note.value.length > NOTE_MAX)
			note.value = note.value.substring(0, NOTE_MAX);
		count.textContent = note.value.length + ' / ' + NOTE_MAX;
	});

	var picker = E('input', {
		'type': 'datetime-local', 'class': 'cbi-input-text', 'disabled': 'disabled',
		'value': localInputValue(new Date()), 'max': localInputValue(new Date()),
		'style': 'margin-left:.4em'
	});

	var radios = [];
	var radio = function(val, text, extra) {
		var rb = E('input', { 'type': 'radio', 'name': 'gg-report-when', 'value': val });
		if (val === '0')
			rb.checked = true;
		rb.addEventListener('change', function() { picker.disabled = !(rb.checked && val === 'at'); });
		radios.push(rb);
		return E('label', {}, [ rb, ' ', text ].concat(extra || []));
	};

	var whenBox = E('div', { 'class': 'gg-rwhen' }, [
		radio('0', _('Just now')),
		radio('5', _('About 5 minutes ago')),
		radio('15', _('About 15 minutes ago')),
		radio('at', _('At:'), [ picker ])
	]);

	var info = E('div', { 'class': 'gg-rinfo' }, [
		isFinite(kb) && kb >= 0
			? _('Your note, the server and mode you use, and the app\'s log of the last %d minutes (%s) are sent.').format(minutes, gg.formatBytes(kb * 1024))
			: _('Your note, the server and mode you use, and the app\'s log of the last %d minutes are sent.').format(minutes)
	]);

	var errBox = E('div', { 'class': 'alert-message warning gg-rerr', 'style': 'display:none' });
	var showErr = function(text) {
		errBox.textContent = String(text);
		errBox.style.display = '';
	};

	var cancelBtn = E('button', { 'class': 'btn cbi-button' }, [ _('Cancel') ]);
	var sendBtn = E('button', { 'class': 'btn cbi-button cbi-button-action important' }, [ _('Send') ]);

	var close = function() {
		dlgOpen = false;
		sending = false;
		ui.hideModal();
		update();
	};

	cancelBtn.addEventListener('click', function(ev) {
		ev.preventDefault();
		if (!sending)
			close();
	});

	sendBtn.addEventListener('click', function(ev) {
		ev.preventDefault();
		if (sending)
			return;
		errBox.style.display = 'none';

		var args = { note: note.value.substring(0, NOTE_MAX) };
		var sel = radios.filter(function(rb) { return rb.checked; })[0];
		var val = sel ? sel.value : '';
		if (val === 'at') {
			var iso = toRfc3339(picker.value);
			if (!iso || new Date(iso).getTime() > now() + 60000) {
				showErr(_('Pick a time in the past.'));
				return;
			}
			args.happened_at = iso;
		}
		else if (val === '0' || val === '5' || val === '15') {
			args.ago_min = Number(val);
		}
		else {
			args.ago_min = -1;
		}

		sending = true;
		sendBtn.disabled = true;
		cancelBtn.disabled = true;
		note.readOnly = true;
		dom.content(sendBtn, [ E('span', { 'class': 'spinning' }, [ _('Sending…') ]) ]);

		var restore = function() {
			sending = false;
			sendBtn.disabled = false;
			cancelBtn.disabled = false;
			note.readOnly = false;
			dom.content(sendBtn, [ _('Send') ]);
		};

		gg.call('problem_report', args).then(function(res) {
			if (res && res.ok) {
				block(Math.max(AFTER_SEND_SEC, Number(res.wait_sec) || 0));
				close();
				ui.addNotification(null, E('p', {}, [
					res.id != null ? _('Sent. Thank you! Report #%s').format(String(res.id)) : _('Sent. Thank you!')
				]), 'info');
				return;
			}

			var err = res && res.error;
			if (err === 'investigation_off') {
				show = false;
				close();
				ui.addNotification(null, E('p', {}, [ _('Problem reports aren\'t being collected right now.') ]), 'info');
				return;
			}
			if (err === 'too_frequent' || err === 'daily_limit') {
				var sec = Number(res.retry_after_sec) || 0;
				block(sec);
				var msg = res.message ? String(res.message)
					: (err === 'daily_limit' ? _('You have sent the maximum number of reports for today.')
						: _('You have just sent a report. Wait a little before sending another one.'));
				if (sec > 0)
					msg += ' ' + _('(You can try again in %s.)').format(gg.formatDuration(sec));
				close();
				ui.addNotification(null, E('p', {}, [ msg ]), 'warning');
				return;
			}

			restore();
			if (err === 'network' || err === 'daemon_down' || !err)
				showErr(_('Couldn\'t send, try again.'));
			else
				showErr(gg.errorText(res));
		});
	});

	dlgOpen = true;
	update();

	ui.showModal(_('Report a problem'), [
		E('div', { 'class': 'gg-report-dlg' }, [
			E('label', { 'class': 'gg-rl', 'for': 'gg-report-note' }, [ _('What happened?') ]),
			note,
			count,
			E('label', { 'class': 'gg-rl' }, [ _('When did it happen?') ]),
			whenBox,
			info,
			errBox,
			E('div', { 'class': 'right', 'style': 'margin-top:1em' }, [ cancelBtn, ' ', sendBtn ])
		])
	]);
	note.focus();
}

function mount() {
	if (mounted || document.getElementById('gg-report-btn'))
		return;
	mounted = true;
	injectStyle();

	btnLabel = E('span', {}, [ _('Report a problem') ]);
	btn = E('button', {
		'type': 'button',
		'id': 'gg-report-btn',
		'class': 'btn cbi-button cbi-button-action gg-report-btn',
		'style': 'display:none',
		'aria-haspopup': 'dialog'
	}, [ E('span', { 'class': 'gg-report-ico', 'aria-hidden': 'true' }, [ '⚑' ]), btnLabel ]);
	btn.addEventListener('click', function(ev) {
		ev.preventDefault();
		openDialog();
	});
	document.body.appendChild(btn);

	refresh();
	poll.add(refresh, POLL_SEC);
}

/* fn(status) after every status poll (e.g. the Log page's investigation line) */
function onStatus(fn) {
	if (typeof fn !== 'function')
		return;
	listeners.push(fn);
	if (lastStatus)
		try { fn(lastStatus); } catch (e) {}
}

return baseclass.extend({
	mount: mount,
	onStatus: onStatus,
	refresh: refresh
});
