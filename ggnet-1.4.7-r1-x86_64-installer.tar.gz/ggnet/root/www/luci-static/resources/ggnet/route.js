'use strict';
'require baseclass';
'require ggnet.common as gg';

/*
 * Aggressive-mode route picture (the Windows client's AggrRouteView, as SVG):
 * the player on the left, one line per lane (the copies on path 0 plus the
 * shortcut path, as the session gives them) that leave side by side, spread
 * apart, run straight and meet again at the exit node — shown with its flag,
 * name and latency. Copies on the same route are knotted together at every node
 * they pass ("two lines, ONE route"); a separate path (multipath) is its own
 * line. Bright lights run along working lines while the tunnel carries traffic.
 * Names and flags only, never addresses.
 *
 *   var r = route.create();  parent.appendChild(r.node);
 *   r.update(lanes, flowing, exitName, exitCc, latencyMs, caption);
 *   lane = { label, state: 0 working | 1 waiting | 2 not reachable, nodes: [{name, cc}], group }
 */

var NS = 'http://www.w3.org/2000/svg';
var OK = '#19E3C0', WAIT = '#8b98a8', DOWN = '#E04848';
var LANE_GAP = 24, PARALLEL_GAP = 4, TOP = 10, W = 640, LABEL_W = 132;

var styleDone = false;
function injectStyle() {
	if (styleDone || !document.head)
		return;
	styleDone = true;
	document.head.appendChild(E('style', { 'type': 'text/css' }, [
		'@keyframes gg-route-run{to{stroke-dashoffset:-28}}' +
		'.gg-route-lights{animation:gg-route-run 1.7s linear infinite}' +
		'@media (prefers-reduced-motion:reduce){.gg-route-lights{animation:none}}' +
		'.gg-route svg{width:100%;height:auto;max-width:760px;display:block;overflow:visible}' +
		'.gg-route text{font-family:inherit}'
	]));
}

function el(name, attrs, kids) {
	var n = document.createElementNS(NS, name);
	for (var k in attrs)
		if (attrs[k] != null)
			n.setAttribute(k, String(attrs[k]));
	(kids || []).forEach(function(c) { n.appendChild(typeof c === 'string' ? document.createTextNode(c) : c); });
	return n;
}

function color(state) { return state === 0 ? OK : (state === 2 ? DOWN : WAIT); }

function flagImg(cc, x, y, w, h) {
	if (!gg.isCountry(cc))
		return null;
	return el('image', { 'href': gg.flagUrl(cc), 'x': x, 'y': y, 'width': w, 'height': h, 'preserveAspectRatio': 'xMidYMid meet' });
}

/* a tag "[flag] name", centred on x */
function nodeTag(name, cc, x, y, c) {
	var g = el('g');
	var tw = Math.min(110, String(name).length * 5.6);
	var hasFlag = gg.isCountry(cc);
	var total = tw + (hasFlag ? 17 : 0);
	var left = x - total / 2;
	if (hasFlag)
		g.appendChild(flagImg(cc, left, y - 9, 14, 10));
	g.appendChild(el('text', { 'x': left + (hasFlag ? 17 : 0), 'y': y, 'font-size': '9.5', 'fill': c }, [ String(name) ]));
	return g;
}

var RouteView = baseclass.extend({
	__init__: function() {
		injectStyle();
		this.svg = el('svg', { 'viewBox': '0 0 ' + W + ' 84', 'role': 'img', 'aria-label': _('Aggressive mode route') });
		this.caption = E('div', { 'style': 'font-size:85%;opacity:.75;margin-top:.15em;display:none' });
		this.node = E('div', { 'class': 'gg-route', 'style': 'margin:.4em 0 .2em' }, [ this.svg, this.caption ]);
		this.sig = '';
	},

	update: function(lanes, flowing, exitName, exitCc, latencyMs, caption) {
		lanes = (lanes && lanes.length) ? lanes : [ { label: '', state: 1, nodes: [], group: 0 } ];
		this.caption.textContent = caption || '';
		this.caption.style.display = caption ? '' : 'none';
		var lat = latencyMs != null ? Math.round(latencyMs) + ' ms' : (flowing ? '… ms' : '');
		var sig = JSON.stringify([ lanes, !!flowing, exitName, exitCc, lat ]);
		if (sig === this.sig)
			return;
		this.sig = sig;
		this.draw(lanes, !!flowing, exitName, exitCc, lat);
	},

	draw: function(lanes, flowing, exitName, exitCc, lat) {
		var svg = this.svg;
		while (svg.firstChild)
			svg.removeChild(svg.firstChild);

		var n = lanes.length;
		var anyNodes = lanes.some(function(l) { return l.nodes && l.nodes.length; });
		var h = Math.max(anyNodes ? 84 : 64, (n - 1) * LANE_GAP + 2 * TOP + 22 + (anyNodes ? 20 : 0));
		svg.setAttribute('viewBox', '0 0 ' + W + ' ' + h);
		var cy = h / 2;

		/* x landmarks: PC | side-by-side run | spread | straight | merge | exit | exit label */
		var xStart = 50, xExit = W - LABEL_W - 12;
		var span = Math.max(120, xExit - xStart - 10);
		var x1 = xStart + span * 0.16, x2 = x1 + span * 0.16, x4 = xExit - 10, x3 = x4 - span * 0.20;

		/* defs: a soft glow for the lights and the exit ring */
		svg.appendChild(el('defs', {}, [
			el('filter', { 'id': 'gg-glow', 'x': '-50%', 'y': '-50%', 'width': '200%', 'height': '200%' }, [
				el('feGaussianBlur', { 'stdDeviation': '2.2', 'result': 'b' }),
				el('feMerge', {}, [ el('feMergeNode', { 'in': 'b' }), el('feMergeNode', { 'in': 'SourceGraphic' }) ])
			])
		]));

		/* the player: a small monitor on a stand, "You" underneath */
		svg.appendChild(el('rect', { 'x': 5, 'y': cy - 14, 'width': 26, 'height': 18, 'rx': 2.5, 'fill': 'rgba(25,227,192,.25)', 'stroke': OK, 'stroke-width': 2 }));
		svg.appendChild(el('rect', { 'x': 16.5, 'y': cy + 4, 'width': 3, 'height': 4, 'fill': OK }));
		svg.appendChild(el('rect', { 'x': 11, 'y': cy + 8, 'width': 14, 'height': 2.5, 'rx': 1, 'fill': OK }));
		svg.appendChild(el('text', { 'x': 9, 'y': cy + 21, 'font-size': '10', 'fill': WAIT }, [ _('You') ]));

		/* lanes of the same group = copies on one route: knotted at each node */
		var groups = {};
		lanes.forEach(function(l, i) { (groups[l.group || 0] = groups[l.group || 0] || []).push(i); });
		var drawnGroup = {};

		lanes.forEach(function(lane, i) {
			var k = i - (n - 1) / 2;
			var yp = cy + k * PARALLEL_GAP, ys = cy + k * LANE_GAP;
			var members = groups[lane.group || 0];
			var groupNodes = [];
			members.forEach(function(m) { if (!groupNodes.length && lanes[m].nodes && lanes[m].nodes.length) groupNodes = lanes[m].nodes; });
			var knotted = members.length > 1 && groupNodes.length > 0;
			var yc = cy + members.reduce(function(a, m) { return a + (m - (n - 1) / 2); }, 0) / members.length * LANE_GAP;

			var d = 'M' + xStart + ' ' + yp + ' L' + x1 + ' ' + yp +
				' C' + (x1 + x2) / 2 + ' ' + yp + ' ' + (x1 + x2) / 2 + ' ' + ys + ' ' + x2 + ' ' + ys;
			if (knotted) {
				var xa = x2, m2 = groupNodes.length;
				for (var j = 0; j < m2; j++) {
					var xk = x2 + (x3 - x2) * (j + 1) / (m2 + 1);
					var xNext = j + 1 < m2 ? x2 + (x3 - x2) * (j + 2) / (m2 + 1) : x3;
					var xm = (xk + xNext) / 2;
					d += ' C' + (xa + xk) / 2 + ' ' + ys + ' ' + (xa + xk) / 2 + ' ' + yc + ' ' + xk + ' ' + yc;
					d += ' C' + (xk + xm) / 2 + ' ' + yc + ' ' + (xk + xm) / 2 + ' ' + ys + ' ' + xm + ' ' + ys;
					xa = xm;
				}
			}
			d += ' L' + x3 + ' ' + ys + ' C' + (x3 + x4) / 2 + ' ' + ys + ' ' + (x3 + x4) / 2 + ' ' + yp + ' ' + x4 + ' ' + yp;

			var c = color(lane.state);
			svg.appendChild(el('path', { 'd': d, 'fill': 'none', 'stroke': c, 'stroke-opacity': lane.state === 0 ? 0.45 : 0.6,
				'stroke-width': 2.2, 'stroke-linecap': 'round', 'stroke-dasharray': lane.state === 2 ? '3 3' : null }));

			/* moving lights while the tunnel carries traffic, each lane a little out of step */
			if (flowing && lane.state === 0)
				svg.appendChild(el('path', { 'class': 'gg-route-lights', 'd': d, 'fill': 'none', 'stroke': '#E8FFFA', 'stroke-width': 3.6,
					'stroke-linecap': 'round', 'stroke-dasharray': '0.01 7', 'filter': 'url(#gg-glow)',
					'style': 'animation-delay:' + (-i * 0.26) + 's' }));

			/* the nodes before the exit, spread along the straight part */
			var nodes = knotted ? (drawnGroup[lane.group || 0] ? [] : groupNodes) : (lane.nodes || []);
			if (knotted)
				drawnGroup[lane.group || 0] = true;
			var groupTop = knotted ? cy + (Math.min.apply(null, members) - (n - 1) / 2) * LANE_GAP : ys;
			var above = k < 0 || n === 1;
			nodes.forEach(function(nd, j) {
				var x = x2 + (x3 - x2) * (j + 1) / (nodes.length + 1);
				var yN = knotted ? yc : ys;
				svg.appendChild(knotted
					? el('circle', { 'cx': x, 'cy': yN, 'r': 5.5, 'fill': c, 'fill-opacity': 0.25, 'stroke': c, 'stroke-width': 2 })
					: el('circle', { 'cx': x, 'cy': yN, 'r': 3.5, 'fill': c }));
				svg.appendChild(nodeTag(nd.name, nd.cc, x, knotted ? groupTop - 9 : (above ? ys - 7 : ys + 14), c));
			});
			/* otherwise a tiny label on the straight part (copy 2 / shortcut) */
			if (!knotted && !nodes.length && lane.label && n > 1)
				svg.appendChild(el('text', { 'x': x2 + 6, 'y': ys + (k < 0 ? -4 : 11), 'font-size': '9.5', 'fill': c, 'opacity': 0.9 }, [ String(lane.label) ]));
		});

		/* the exit: a ringed dot where the lanes meet, then flag + name + latency */
		svg.appendChild(el('circle', { 'cx': xExit, 'cy': cy, 'r': 7, 'fill': 'none', 'stroke': OK, 'stroke-width': 2.5,
			'filter': flowing ? 'url(#gg-glow)' : null }));
		var lx = xExit + 12;
		var f = flagImg(exitCc, lx, cy - 15, 20, 14);
		if (f)
			svg.appendChild(f);
		svg.appendChild(el('text', { 'x': lx + (f ? 25 : 0), 'y': cy - 4, 'font-size': '12.5', 'font-weight': '600', 'fill': 'currentColor' },
			[ String(exitName || _('Exit node')) ]));
		if (lat)
			svg.appendChild(el('text', { 'x': lx, 'y': cy + 13, 'font-size': '13', 'font-weight': 'bold', 'fill': OK }, [ lat ]));
	}
});

return baseclass.extend({
	RouteView: RouteView,
	create: function() { return new RouteView(); }
});
