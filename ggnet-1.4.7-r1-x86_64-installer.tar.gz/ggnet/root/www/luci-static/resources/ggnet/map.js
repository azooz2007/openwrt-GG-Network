'use strict';
'require baseclass';
'require dom';
'require ggnet.common as gg';

/*
 * GG Network world map for the combo builder (port of the Windows
 * GGamersComboMap / GeoWorld). Country outlines are decoded once from the
 * bundled TopoJSON (ggnet/geo/countries-110m.json) and projected
 * equirectangular into a W×H box; node data always comes live from
 * combo_nodes. Node addresses are never shown.
 *
 *   ggmap.load()                 -> Promise<geo>   (cached)
 *   var m = ggmap.create({ onPick: function(nodeId) {} });
 *   m.node                       -> DOM element to insert
 *   m.setNodes(nodes, links)
 *   m.setPicked(ids, targetCc)
 *   m.highlightInvalid(ids)
 *   m.resetView()
 */

var W = 960, H = 480;     /* projection box */
var VH = 420;             /* visible height (crops most of Antarctica) */
var NS = 'http://www.w3.org/2000/svg';

var C = {
	accent: '#3fb950',
	gold:   '#e3b341',
	down:   '#e04848',
	muted:  '#8b98a8'
};

/* Small states missing from the 1:110m polygons: centroid-only (lon, lat). */
var MISSING_SMALL = [
	[ 'BH',   50.58,  26.07 ], [ 'SG',  103.82,   1.35 ], [ 'HK', 114.17,  22.32 ],
	[ 'MO',  113.55,  22.20 ], [ 'MT',   14.42,  35.90 ], [ 'MV',  73.51,   4.18 ],
	[ 'MU',   57.55, -20.35 ], [ 'SC',   55.49,  -4.62 ], [ 'BN', 114.73,   4.54 ],
	[ 'BB',  -59.54,  13.19 ], [ 'GI',   -5.35,  36.14 ], [ 'AD',   1.52,  42.51 ],
	[ 'LI',    9.55,  47.17 ], [ 'SM',   12.46,  43.94 ], [ 'MC',   7.42,  43.74 ],
	[ 'VA',   12.45,  41.90 ], [ 'CV',  -23.51,  15.12 ], [ 'KM',  43.33, -11.65 ],
	[ 'ST',    6.61,   0.19 ], [ 'WS', -172.10, -13.76 ], [ 'TO', -175.20, -21.18 ]
];

function project(lon, lat) {
	return [ (lon + 180) / 360 * W, (90 - lat) / 180 * H ];
}

function signedArea(r) {
	var a = 0;
	for (var i = 0, j = r.length - 1; i < r.length; j = i++)
		a += (r[j][0] + r[i][0]) * (r[j][1] - r[i][1]);
	return a / 2;
}

function polygonCentroid(r) {
	var a = 0, cx = 0, cy = 0;
	for (var i = 0, j = r.length - 1; i < r.length; j = i++) {
		var cross = r[j][0] * r[i][1] - r[i][0] * r[j][1];
		a += cross;
		cx += (r[j][0] + r[i][0]) * cross;
		cy += (r[j][1] + r[i][1]) * cross;
	}
	if (Math.abs(a) < 1e-9) {
		var mx = 0, my = 0;
		r.forEach(function(p) { mx += p[0]; my += p[1]; });
		return [ mx / r.length, my / r.length ];
	}
	a *= 0.5;
	return [ cx / (6 * a), cy / (6 * a) ];
}

function f1(v) { return Math.round(v * 10) / 10; }

/* One ring → pieces, split wherever it jumps across the antimeridian. */
function ringPieces(ring) {
	var out = [], start = 0;
	var piece = function(s, e) {
		if (e - s < 2)
			return;
		var minX = Infinity, maxX = -Infinity;
		for (var k = s; k < e; k++) {
			if (ring[k][0] < minX) minX = ring[k][0];
			if (ring[k][0] > maxX) maxX = ring[k][0];
		}
		if (maxX - minX > W * 0.95)
			return;
		out.push(ring.slice(s, e));
	};
	for (var i = 1; i <= ring.length; i++) {
		var wrap = i < ring.length && Math.abs(ring[i][0] - ring[i - 1][0]) > W / 2;
		if (i === ring.length || wrap) {
			piece(start, i);
			start = i;
		}
	}
	return out;
}

function piecePath(pc) {
	var d = 'M' + f1(pc[0][0]) + ' ' + f1(pc[0][1]);
	for (var k = 1; k < pc.length; k++)
		d += 'L' + f1(pc[k][0]) + ' ' + f1(pc[k][1]);
	return d + 'Z';
}

function buildGeo(topo, info) {
	var idToCc = {};
	Object.keys(info || {}).forEach(function(cc) {
		var v = info[cc] || {};
		if (v.id != null)
			idToCc[String(parseInt(v.id, 10))] = cc.toUpperCase();
	});

	var tr = topo.transform, q = !!tr;
	var sx = q ? tr.scale[0] : 1, sy = q ? tr.scale[1] : 1,
	    tx = q ? tr.translate[0] : 0, ty = q ? tr.translate[1] : 0;

	var arcs = (topo.arcs || []).map(function(arc) {
		var x = 0, y = 0;
		return arc.map(function(p) {
			if (q) {
				x += p[0]; y += p[1];
				return project(x * sx + tx, y * sy + ty);
			}
			return project(p[0], p[1]);
		});
	});

	var addPolygon = function(rings, poly) {
		(poly || []).forEach(function(ring) {
			var pts = [];
			ring.forEach(function(i) {
				var arc = i >= 0 ? arcs[i] : arcs[~i].slice().reverse();
				for (var k = pts.length ? 1 : 0; k < arc.length; k++)
					pts.push(arc[k]);
			});
			if (pts.length >= 3)
				rings.push(pts);
		});
	};

	var countries = [], byCc = {};
	var geoms = ((topo.objects || {}).countries || {}).geometries || [];
	geoms.forEach(function(g) {
		var rings = [];
		if (g.type === 'Polygon')
			addPolygon(rings, g.arcs);
		else if (g.type === 'MultiPolygon')
			(g.arcs || []).forEach(function(p) { addPolygon(rings, p); });
		if (!rings.length)
			return;

		var cc = g.id != null ? (idToCc[String(parseInt(g.id, 10))] || '') : '';
		var name = cc && info[cc] ? info[cc].n : ((g.properties || {}).name || '');

		var pieces = [];
		rings.forEach(function(r) { pieces.push.apply(pieces, ringPieces(r)); });
		if (!pieces.length)
			return;

		/* centroid of the largest piece (never of a ring that wraps the map) */
		var best = pieces[0], bestA = -1;
		pieces.forEach(function(r) { var a = Math.abs(signedArea(r)); if (a > bestA) { bestA = a; best = r; } });

		var c = {
			cc: cc,
			name: name,
			d: pieces.map(piecePath).join(''),
			centroid: polygonCentroid(best)
		};
		countries.push(c);
		if (cc)
			byCc[cc] = c;
	});

	MISSING_SMALL.forEach(function(m) {
		if (byCc[m[0]])
			return;
		var c = { cc: m[0], name: info[m[0]] ? info[m[0]].n : m[0], d: '', centroid: project(m[1], m[2]) };
		countries.push(c);
		byCc[m[0]] = c;
	});

	var list = Object.keys(info || {}).map(function(cc) {
		return { code: cc.toUpperCase(), name: String(info[cc].n || cc), continent: info[cc].c || '' };
	}).sort(function(a, b) { return a.name.localeCompare(b.name); });

	return { countries: countries, byCc: byCc, info: info, list: list };
}

function getJSON(path) {
	var url = L.resource(path);
	return fetch(url, { credentials: 'same-origin' }).then(function(r) {
		if (!r.ok)
			throw new Error('HTTP ' + r.status + ' for ' + path);
		return r.json();
	});
}

var geoPromise = null, geoCache = null;

function load() {
	if (!geoPromise)
		geoPromise = Promise.all([
			getJSON('ggnet/geo/countries-110m.json'),
			getJSON('ggnet/geo/countries.json')
		]).then(function(r) {
			geoCache = buildGeo(r[0], r[1]);
			return geoCache;
		}).catch(function(err) {
			geoPromise = null;
			throw err;
		});
	return geoPromise;
}

/* ------------------------------------------------------------------ */

function S(tag, attrs, children) {
	var el = document.createElementNS(NS, tag);
	for (var k in (attrs || {}))
		if (attrs[k] != null)
			el.setAttribute(k, attrs[k]);
	(children || []).forEach(function(c) { if (c) el.appendChild(c); });
	return el;
}

function T(tag, attrs, text) {
	var el = S(tag, attrs);
	el.textContent = text;
	return el;
}

/* SVG <image> of a country flag (local PNG, 40×27) or null */
function flagImage(cc, x, y, h) {
	var url = gg.flagUrl(cc);
	if (!url)
		return null;
	var w = h * 40 / 27;
	var img = S('image', { 'x': f1(x), 'y': f1(y), 'width': f1(w), 'height': f1(h), 'preserveAspectRatio': 'none', 'style': 'pointer-events:none' });
	img.setAttribute('href', url);
	try { img.setAttributeNS('http://www.w3.org/1999/xlink', 'xlink:href', url); } catch (e) {}
	return img;
}

var styleDone = false;
function injectStyle() {
	if (styleDone)
		return;
	styleDone = true;
	var css =
		'.ggmap{--sea:#0a1524;--land:#1b2b3d;--landn:#1f3a2c;--stroke:#2c4258;--txt:#e6edf3;--halo:#0a1524;' +
			'position:relative;border:1px solid var(--stroke);border-radius:10px;overflow:hidden;background:var(--sea);user-select:none;-webkit-user-select:none}' +
		'.ggmap.ggmap-light{--sea:#e4edf6;--land:#c6d2de;--landn:#b5dcc0;--stroke:#f7fafc;--txt:#1b2733;--halo:#ffffff}' +
		'.ggmap svg{display:block;width:100%;height:auto;cursor:grab}' +
		'.ggmap.drag svg{cursor:grabbing}' +
		'.ggmap .gc{fill:var(--land);stroke:var(--stroke);stroke-width:.5px;vector-effect:non-scaling-stroke;fill-rule:nonzero}' +
		'.ggmap .gc.n{fill:var(--landn)}' +
		'.ggmap .gc.t{stroke:' + C.gold + ';stroke-width:1.6px}' +
		'.ggmap .gl{fill:var(--txt);font:600 9px sans-serif;paint-order:stroke;stroke:var(--halo);stroke-width:2.5px;stroke-linejoin:round;pointer-events:none}' +
		'.ggmap .gn{font:bold 8px sans-serif;fill:var(--sea);text-anchor:middle;dominant-baseline:central;pointer-events:none}' +
		'.ggmap .gk{fill:var(--txt);font:600 9px sans-serif;text-anchor:middle;paint-order:stroke;stroke:var(--halo);stroke-width:3px;stroke-linejoin:round;pointer-events:none}' +
		'.ggmap .gp{cursor:pointer}' +
		'.ggmap .gp.off{cursor:not-allowed;opacity:.6}' +
		'.ggmap .gctl{position:absolute;top:6px;right:6px;display:flex;gap:4px}' +
		'.ggmap .gctl button{min-width:2em;padding:0 .5em;line-height:1.8em;height:auto;margin:0}' +
		'.ggmap .gmsg{position:absolute;left:8px;bottom:6px;font-size:85%;color:var(--txt);opacity:.85;pointer-events:none}' +
		'.ggmap-off{margin-top:.4em;font-size:90%}' +
		'.ggmap-off button{margin:.15em}';
	document.head.appendChild(E('style', { 'type': 'text/css' }, css));
}

/* light theme? → look at the nearest non-transparent page background */
function isLightTheme(el) {
	var n = el || document.body;
	while (n && n.nodeType === 1) {
		var bg = window.getComputedStyle(n).backgroundColor || '';
		var m = bg.match(/rgba?\(([\d.]+)[, ]+([\d.]+)[, ]+([\d.]+)(?:[, /]+([\d.]+))?/);
		if (m && (m[4] == null || Number(m[4]) > 0.5))
			return (0.2126 * m[1] + 0.7152 * m[2] + 0.0722 * m[3]) / 255 > 0.5;
		n = n.parentNode;
	}
	return true;
}

function MapView(opts) {
	opts = opts || {};
	injectStyle();

	var self = this;
	var onPick = typeof opts.onPick === 'function' ? opts.onPick : function() {};

	var geo = null;
	var nodes = [], links = {}, byId = {}, pos = {};
	var picked = [], target = '', invalid = {};
	var view = { k: 1, tx: 0, ty: 0 };
	var sizeK = 1;
	var countryEls = {};

	var gCountries = S('g');
	var gArcs = S('g');
	var gPins = S('g');
	var sea = S('rect', { 'x': 0, 'y': 0, 'width': W, 'height': VH, 'fill': 'var(--sea)' });
	var svg = S('svg', {
		'viewBox': '0 0 ' + W + ' ' + VH,
		'preserveAspectRatio': 'xMidYMid meet',
		'role': 'img'
	}, [ sea, gCountries, gArcs, gPins ]);

	var msg = E('div', { 'class': 'gmsg' }, _('Loading the map…'));
	var ctl = E('div', { 'class': 'gctl' }, [
		E('button', { 'class': 'btn cbi-button', 'title': _('Zoom in'), 'click': function(ev) { ev.preventDefault(); zoomAt(1.5, W / 2, VH / 2); } }, '+'),
		E('button', { 'class': 'btn cbi-button', 'title': _('Zoom out'), 'click': function(ev) { ev.preventDefault(); zoomAt(1 / 1.5, W / 2, VH / 2); } }, '−'),
		E('button', { 'class': 'btn cbi-button', 'click': function(ev) { ev.preventDefault(); self.resetView(); } }, _('Reset view'))
	]);
	var box = E('div', { 'class': 'ggmap' }, [ svg, ctl, msg ]);
	var offList = E('div', { 'class': 'ggmap-off', 'style': 'display:none' });

	this.node = E('div', {}, [ box, offList ]);

	/* -------- theme / sizing -------- */

	var applyTheme = function() {
		box.classList.toggle('ggmap-light', isLightTheme(box.isConnected ? box.parentNode : (document.querySelector('#maincontent') || document.body)));
	};

	var measure = function() {
		var w = svg.getBoundingClientRect().width;
		if (!w) return false;
		var ppu = w / W;
		var k2 = Math.min(2, Math.max(1, 0.85 / ppu));
		if (Math.abs(k2 - sizeK) > 0.01) {
			sizeK = k2;
			return true;
		}
		return false;
	};

	/* -------- geometry -------- */

	var scr = function(p) { return [ p[0] * view.k + view.tx, p[1] * view.k + view.ty ]; };

	var drawCountries = function() {
		var frag = document.createDocumentFragment();
		geo.countries.forEach(function(c) {
			if (!c.d)
				return;
			var p = S('path', { 'd': c.d, 'class': 'gc' }, [ T('title', {}, c.name || '') ]);
			if (c.cc)
				countryEls[c.cc] = p;
			frag.appendChild(p);
		});
		gCountries.appendChild(frag);
	};

	var place = function() {
		pos = {};
		if (!geo)
			return;
		var perCc = {};
		nodes.forEach(function(n) {
			var cc = String(n.cc || '').toUpperCase();
			if (!geo.byCc[cc])
				return;
			(perCc[cc] = perCc[cc] || []).push(n);
		});
		Object.keys(perCc).forEach(function(cc) {
			var list = perCc[cc], c = geo.byCc[cc].centroid;
			list.forEach(function(n, i) {
				var r = list.length > 1 ? 10 : 0, a = i / list.length * 2 * Math.PI - Math.PI / 2;
				pos[n.id] = [ c[0] + r * Math.cos(a), c[1] + r * Math.sin(a) ];
			});
		});
	};

	var nodeTitle = function(n) {
		var t = String(n.name || '?');
		if (n.country) t += ' · ' + n.country;
		if (!n.usable) t += ' · ' + String(n.why || _('unavailable'));
		return t;
	};

	var pinEls = {};

	var drawPins = function() {
		while (gPins.firstChild)
			gPins.removeChild(gPins.firstChild);
		pinEls = {};
		var frag = document.createDocumentFragment();
		var noPos = [];
		nodes.forEach(function(n) {
			if (!pos[n.id]) {
				noPos.push(n);
				return;
			}
			var idx = picked.indexOf(n.id);
			var bad = idx >= 0 && (invalid[n.id] || !n.usable);
			var r = (idx >= 0 ? 6.5 : 5.5) * sizeK;
			var stroke = bad ? C.down : (n.usable ? C.accent : C.muted);
			var fill = idx >= 0 ? (bad ? C.down : C.accent) : 'var(--sea)';
			var clickable = n.usable || idx >= 0;

			var fh = 7 * sizeK;
			var fimg = flagImage(n.cc, r + 3 * sizeK, -fh / 2, fh);
			var lx = r + 3 * sizeK + (fimg ? fh * 40 / 27 + 2 * sizeK : 0);
			var g = S('g', { 'class': 'gp' + (clickable ? '' : ' off') }, [
				T('title', {}, nodeTitle(n) + (bad ? ' · ' + _('remove it and pick another node') : '')),
				S('circle', { 'r': r + 4 * sizeK, 'fill': 'transparent' }),
				S('circle', { 'r': r, 'fill': fill, 'stroke': stroke, 'stroke-width': 2 * sizeK }),
				idx >= 0 ? T('text', { 'class': 'gn', 'style': 'font-size:' + (8 * sizeK) + 'px' }, String(idx + 1)) : null,
				fimg && !n.usable ? S('g', { 'opacity': '.6' }, [ fimg ]) : fimg,
				T('text', { 'class': 'gl', 'x': f1(lx), 'y': 3 * sizeK,
					'style': 'font-size:' + (9 * sizeK) + 'px' + (bad ? ';fill:' + C.down : (n.usable ? '' : ';opacity:.7')) }, String(n.name || '?'))
			]);
			if (clickable)
				g.addEventListener('click', function(ev) {
					if (drag.moved) return;
					ev.preventDefault();
					ev.stopPropagation();
					onPick(n.id);
				});
			pinEls[n.id] = g;
			frag.appendChild(g);
		});
		gPins.appendChild(frag);
		positionPins();
		drawOffList(noPos);
	};

	var positionPins = function() {
		Object.keys(pinEls).forEach(function(id) {
			var p = scr(pos[id]);
			pinEls[id].setAttribute('transform', 'translate(' + f1(p[0]) + ' ' + f1(p[1]) + ')');
		});
	};

	/* nodes whose country isn't on the map (or no map at all) */
	var drawOffList = function(list) {
		if (!list.length) {
			offList.style.display = 'none';
			return;
		}
		offList.style.display = '';
		var items = [ E('span', { 'style': 'opacity:.75' }, geo ? _('Not on the map:') + ' ' : _('Nodes:') + ' ') ];
		list.forEach(function(n) {
			var idx = picked.indexOf(n.id);
			var bad = idx >= 0 && (invalid[n.id] || !n.usable);
			var label = [];
			if (idx >= 0) label.push((idx + 1) + '. ');
			var fl = gg.flag(n.cc);
			if (fl) label.push(fl, ' ');
			label.push(String(n.name || '?'));
			items.push(E('button', {
				'class': 'btn cbi-button' + (idx >= 0 ? ' cbi-button-action' : ''),
				'disabled': (n.usable || idx >= 0) ? null : true,
				'title': nodeTitle(n),
				'style': bad ? 'color:' + C.down + ';border-color:' + C.down : null,
				'click': function(ev) { ev.preventDefault(); onPick(n.id); }
			}, label));
		});
		dom.content(offList, items);
	};

	var linkMs = function(a, b) {
		var v = links[a + '-' + b];
		if (v == null) v = links[b + '-' + a];
		return (v == null || !isFinite(v) || v < 0) ? null : v;
	};

	var arcPath = function(a, b) {
		var dx = b[0] - a[0], dy = b[1] - a[1];
		var d = Math.sqrt(dx * dx + dy * dy), lift = Math.min(80, d * 0.3 + 8);
		var c = [ (a[0] + b[0]) / 2, (a[1] + b[1]) / 2 - lift ];
		var A = scr(a), B = scr(b), Cc = scr(c);
		return {
			d: 'M' + f1(A[0]) + ' ' + f1(A[1]) + 'Q' + f1(Cc[0]) + ' ' + f1(Cc[1]) + ' ' + f1(B[0]) + ' ' + f1(B[1]),
			mid: [ 0.25 * A[0] + 0.5 * Cc[0] + 0.25 * B[0], 0.25 * A[1] + 0.5 * Cc[1] + 0.25 * B[1] ]
		};
	};

	var drawArcs = function() {
		while (gArcs.firstChild)
			gArcs.removeChild(gArcs.firstChild);
		var ids = picked.filter(function(id) { return pos[id]; });
		var labels = [];
		for (var i = 1; i < ids.length; i++) {
			var bad = invalid[ids[i]] || invalid[ids[i - 1]] ||
				(byId[ids[i]] && !byId[ids[i]].usable) || (byId[ids[i - 1]] && !byId[ids[i - 1]].usable);
			var ap = arcPath(pos[ids[i - 1]], pos[ids[i]]);
			gArcs.appendChild(S('path', { 'd': ap.d, 'fill': 'none', 'stroke': bad ? C.down : C.accent, 'stroke-width': 2 * sizeK, 'stroke-linecap': 'round' }));
			var l = linkMs(ids[i - 1], ids[i]);
			if (l != null)
				labels.push(T('text', { 'class': 'gk', 'x': f1(ap.mid[0]), 'y': f1(ap.mid[1] - 3 * sizeK), 'style': 'font-size:' + (9 * sizeK) + 'px' }, Math.round(l) + ' ms'));
		}
		var tc = target && geo ? geo.byCc[target] : null;
		if (tc) {
			var tp = scr(tc.centroid);
			if (ids.length) {
				var fa = arcPath(pos[ids[ids.length - 1]], tc.centroid);
				gArcs.appendChild(S('path', { 'd': fa.d, 'fill': 'none', 'stroke': C.gold, 'stroke-width': 2 * sizeK, 'stroke-dasharray': (4 * sizeK) + ' ' + (3 * sizeK) }));
			}
			gArcs.appendChild(S('circle', { 'cx': f1(tp[0]), 'cy': f1(tp[1]), 'r': 5 * sizeK, 'fill': C.gold, 'stroke': 'var(--sea)', 'stroke-width': 1.5 * sizeK },
				[ T('title', {}, tc.name || target) ]));
			var th = 11 * sizeK, tw = th * 40 / 27;
			var timg = flagImage(target, tp[0] - tw / 2, tp[1] - 7 * sizeK - th, th);
			if (timg) {
				gArcs.appendChild(S('rect', { 'x': f1(tp[0] - tw / 2 - sizeK), 'y': f1(tp[1] - 7 * sizeK - th - sizeK), 'width': f1(tw + 2 * sizeK), 'height': f1(th + 2 * sizeK),
					'rx': f1(1.5 * sizeK), 'fill': C.gold, 'style': 'pointer-events:none' }));
				gArcs.appendChild(timg);
			}
		}
		labels.forEach(function(t) { gArcs.appendChild(t); });
	};

	var styleCountries = function() {
		var nodeCc = {};
		nodes.forEach(function(n) { nodeCc[String(n.cc || '').toUpperCase()] = true; });
		Object.keys(countryEls).forEach(function(cc) {
			var el = countryEls[cc];
			el.classList.toggle('n', !!nodeCc[cc]);
			el.classList.toggle('t', cc === target);
		});
	};

	var applyView = function() {
		gCountries.setAttribute('transform', 'translate(' + f1(view.tx) + ' ' + f1(view.ty) + ') scale(' + view.k + ')');
		svg.style.touchAction = view.k > 1.001 ? 'none' : '';
		positionPins();
		drawArcs();
	};

	var redraw = function() {
		measure();
		styleCountries();
		drawPins();
		drawArcs();
	};

	/* -------- zoom & pan -------- */

	var clamp = function() {
		view.k = Math.max(1, Math.min(8, view.k));
		view.tx = Math.min(0, Math.max(W - W * view.k, view.tx));
		view.ty = Math.min(0, Math.max(VH - VH * view.k, view.ty));
	};

	var toSvg = function(clientX, clientY) {
		var r = svg.getBoundingClientRect();
		return [ (clientX - r.left) / (r.width || 1) * W, (clientY - r.top) / (r.height || 1) * VH ];
	};

	var zoomAt = function(factor, px, py) {
		var k0 = view.k;
		var k1 = Math.max(1, Math.min(8, k0 * factor));
		if (k1 === k0)
			return;
		view.tx = px - (px - view.tx) * (k1 / k0);
		view.ty = py - (py - view.ty) * (k1 / k0);
		view.k = k1;
		clamp();
		applyView();
	};

	svg.addEventListener('wheel', function(ev) {
		if (ev.deltaY > 0 && view.k <= 1.001)
			return;   /* fully zoomed out: let the page scroll */
		ev.preventDefault();
		var p = toSvg(ev.clientX, ev.clientY);
		zoomAt(ev.deltaY < 0 ? 1.2 : 1 / 1.2, p[0], p[1]);
	}, { passive: false });

	var drag = { on: false, moved: false, x: 0, y: 0, tx: 0, ty: 0, id: null };

	svg.addEventListener('pointerdown', function(ev) {
		if (ev.button !== 0)
			return;
		drag.on = true;
		drag.moved = false;
		drag.x = ev.clientX; drag.y = ev.clientY;
		drag.tx = view.tx; drag.ty = view.ty;
		drag.id = ev.pointerId;
	});

	svg.addEventListener('pointermove', function(ev) {
		if (!drag.on || ev.pointerId !== drag.id)
			return;
		var dx = ev.clientX - drag.x, dy = ev.clientY - drag.y;
		if (!drag.moved) {
			if (Math.abs(dx) + Math.abs(dy) < 4 || view.k <= 1.001)
				return;
			drag.moved = true;
			box.classList.add('drag');
			try { svg.setPointerCapture(ev.pointerId); } catch (e) {}
		}
		var r = svg.getBoundingClientRect(), u = W / (r.width || W);
		view.tx = drag.tx + dx * u;
		view.ty = drag.ty + dy * u;
		clamp();
		applyView();
	});

	var endDrag = function(ev) {
		if (!drag.on || (ev && ev.pointerId !== drag.id))
			return;
		drag.on = false;
		box.classList.remove('drag');
		try { svg.releasePointerCapture(drag.id); } catch (e) {}
		/* keep "moved" through the click that follows this pointerup */
		window.setTimeout(function() { drag.moved = false; }, 0);
	};
	svg.addEventListener('pointerup', endDrag);
	svg.addEventListener('pointercancel', endDrag);

	if (window.ResizeObserver)
		new ResizeObserver(function() { applyTheme(); if (measure()) redraw(); }).observe(svg);
	else
		window.addEventListener('resize', function() { if (measure()) redraw(); });

	/* -------- public API -------- */

	this.resetView = function() {
		view.k = 1; view.tx = 0; view.ty = 0;
		applyView();
	};

	this.setNodes = function(list, linkList) {
		nodes = Array.isArray(list) ? list.slice() : [];
		byId = {};
		nodes.forEach(function(n) { byId[n.id] = n; });
		links = {};
		(Array.isArray(linkList) ? linkList : []).forEach(function(l) {
			var v = Number(l.ms);
			if (l.ms != null && l.ms !== '' && isFinite(v))
				links[l.from + '-' + l.to] = v;
		});
		place();
		redraw();
	};

	this.setPicked = function(ids, targetCc) {
		picked = Array.isArray(ids) ? ids.slice() : [];
		target = targetCc ? String(targetCc).toUpperCase() : '';
		redraw();
	};

	this.highlightInvalid = function(ids) {
		invalid = {};
		(ids || []).forEach(function(id) { invalid[id] = true; });
		redraw();
	};

	this.ready = load().then(function(g) {
		geo = g;
		drawCountries();
		msg.style.display = 'none';
		applyTheme();
		place();
		applyView();
		redraw();
		return self;
	}).catch(function(err) {
		msg.textContent = _('The world map could not be loaded (%s). Pick the nodes from the list below.').format(String(err && err.message || err));
		redraw();
		return self;
	});

	window.requestAnimationFrame(function() { applyTheme(); if (measure()) redraw(); });
}

return baseclass.extend({
	W: W,
	H: H,
	load: load,
	flagUrl: gg.flagUrl,
	geo: function() { return geoCache; },
	create: function(opts) { return new MapView(opts); }
});
