'use strict';
'require baseclass';
'require poll';
'require dom';
'require ui';
'require ggnet.common as gg';

/*
 * Live chat panel (GGamers spec §6), embeddable in any view.
 * All user text is rendered as plain text (E() text nodes).
 *
 *   var c = chat.create({ height: '45vh' });
 *   parent.appendChild(c.render());   // starts its own 2 s poll
 *   c.stop();  c.start();             // pause / resume polling
 *
 * 1.34: click a name to reply (@name), messages that mention you are
 * highlighted, staff edit messages ("(edited)"), pins outlive deleted messages,
 * an emoji picker. Staff menu: Reply, Edit, Delete, Pin, Mute, Ban (the server
 * checks every command; the menu only hides what the rank rules forbid).
 */

var FILTERED_TEXT = '🚫 ' + _('Message removed by anti-bad-words protection');

var CHAT_ERRORS = {
	empty:          _('Type a message first.'),
	too_long:       _('The message is too long.'),
	too_many_lines: _('The message has too many lines (8 at most).'),
	slow_down:      _('Slow down a little.'),
	duplicate:      _('You just sent the same text.'),
	slow_mode:      _('Slow mode is on: wait a few seconds.'),
	daily_limit:    _('You have used all your messages for today.'),
	read_only:      _('You can\'t send messages right now.'),
	muted:          _('You are muted.'),
	banned:         _('You are banned from the chat.'),
	pin_limit:      _('Already 3 pinned messages: unpin one first.'),
	forbidden:      _('You can\'t do that.'),
	not_found:      _('That message or user doesn\'t exist any more.'),
	too_many_connections: _('5 chat connections are already open. Try again later.')
};

var PLACEHOLDER = _('Message… (click a name to reply)');

function show(el, on) { el.style.display = on ? '' : 'none'; }

/* online list: highest rank first; unknown roles rank like "active" */
var ONLINE_MAX = 40;
var ROLE_RANK = { administrator: 0, admin: 1, moderator: 2, ambassador: 3, active: 4, inactive: 5 };

function roleRank(role) {
	var r = ROLE_RANK[String(role || '').toLowerCase()];
	return r != null ? r : ROLE_RANK.active;
}

function isStaffRole(r) { return r === 'administrator' || r === 'admin' || r === 'moderator'; }

/* §6 "Limits and who can do what" — only to hide menu items; the server decides. */
function canDelete(me, m) {
	if (!me || !me.can_moderate) return false;
	var mine = String(me.role || ''), theirs = String(m.role || '');
	if (mine === 'administrator') return true;
	if (mine === 'admin') return theirs !== 'administrator';
	if (mine === 'moderator') return !isStaffRole(theirs) || sameUser(me, m.user);
	return false;
}
function canEdit(me, m) { return !!(me && me.can_edit) && canDelete(me, m); }
function canSanction(me, role) {
	if (!me || !me.can_moderate) return false;
	var mine = String(me.role || ''), theirs = String(role || '');
	if (theirs === 'administrator' || theirs === 'admin') return false;
	if (theirs === 'moderator') return mine === 'administrator' || mine === 'admin';
	return true;
}
function sameUser(me, user) {
	return !!(me && me.user) && String(me.user).toLowerCase() === String(user || '').toLowerCase();
}

function escapeRe(s) { return String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }

/* "@name" followed by a space, punctuation or the end — not a letter, digit or "_" (1.34) */
function mentions(text, user) {
	if (!text || !user)
		return false;
	try {
		return new RegExp('@' + escapeRe(user) + '(?![\\p{L}\\p{N}_])', 'iu').test(String(text));
	}
	catch (e) {
		return new RegExp('@' + escapeRe(user) + '(?![A-Za-z0-9_])', 'i').test(String(text));
	}
}

/* emoji picker: a small set per category (joined emojis are sent as they are) */
var EMOJI = [
	[ '😀', '😀😃😄😁😆😅😂🤣😊😇🙂🙃😉😌😍🥰😘😋😛😜🤪😎🤩🥳😏😒😞😔😟😕🙁😣😖😫😩🥺😢😭😤😠😡🤬🤯😳🥵🥶😱😨😰😥😓🤗🤔🤭🤫🤥😶😐😑😬🙄😯😦😧😮😲🥱😴🤤😪😵🤐🥴🤢🤮🤧😷🤒🤕🤑🤠😈👿👻💀☠️👽🤖💩' ],
	[ '👍', '👍👎👌✌️🤞🤟🤘🤙👈👉👆👇☝️✋🤚🖐️🖖👋🤝🙏💪👏🙌👐🤲✍️💅🤳👀👁️🧠🫡' ],
	[ '❤️', '❤️🧡💛💚💙💜🖤🤍🤎💔❣️💕💞💓💗💖💘💝💯💢💥💫💦💨🕳️💬💭💤🔥✨⭐🌟⚡' ],
	[ '🎮', '🎮🕹️🎯🎲🏆🥇🥈🥉🏅⚽🏀🏈⚾🎾🏐🏉🎱🏓🏸🥊🥋⛳🎳🏹🎣🛹🏁🚩' ],
	[ '🍕', '🍕🍔🍟🌭🥪🌮🌯🥙🍿🧂🥓🍳🥞🧇🍗🍖🍝🍜🍣🍱🍩🍪🎂🍰🧁🍫🍬🍭☕🍵🧃🥤🧋' ],
	[ '🐱', '🐶🐱🐭🐹🐰🦊🐻🐼🐨🐯🦁🐮🐷🐸🐵🙈🙉🙊🐔🐧🐦🦅🦉🐺🐗🐴🦄🐝🦋🐌🐢🐍🦖🐙🦈🐬🐳' ],
	[ '🌍', '🌍🌎🌏🌙☀️⛅🌧️⛈️❄️☃️🌈🌊🏔️🏝️🏜️🌋🗻🏟️🕌🕋🏰🗼🚀✈️🚗🏎️🏍️🚲⏰⌛📱💻⌨️🖥️🎧🎤📷💡🔑🔒🛡️⚔️💣' ]
];


/* opts.fill: the panel fills its (flex) parent's height; the message list
 * takes the free space and scrolls inside. One column (< 900 px): fixed height. */
var fillStyleDone = false;
function injectFillStyle() {
	if (fillStyleDone || !document.head)
		return;
	fillStyleDone = true;
	document.head.appendChild(E('style', { 'type': 'text/css' }, [
		'.gg-chat-fill{display:flex;flex-direction:column;flex:1 1 auto;min-height:0}' +
		'.gg-chat-fill>*{flex:none}' +
		'.gg-chat-fill>.gg-chat-scroll{flex:1 1 0;min-height:18em;height:auto}' +
		'@media (max-width:900px){.gg-chat-fill>.gg-chat-scroll{flex:none;height:50vh;min-height:16em}}' +
		'.gg-msg{position:relative;padding:.25em .3em;border-bottom:1px solid rgba(128,128,128,.15)}' +
		'.gg-msg.gg-mention{background:rgba(63,185,80,.16);border-left:3px solid #3fb950;padding-left:.5em}' +
		'.gg-msg.gg-mention:hover{background:rgba(63,185,80,.26)}' +
		'.gg-msg .gg-acts{display:none;position:absolute;top:.1em;right:.2em}' +
		'.gg-msg:hover .gg-acts{display:block}' +
		'.gg-acts button{padding:0 .4em;margin-left:.15em;font-size:90%;line-height:1.5;min-height:0}' +
		'.gg-name{cursor:pointer}.gg-name.gg-self{cursor:default}' +
		'.gg-emoji-pop{border:1px solid rgba(128,128,128,.4);border-radius:6px;padding:.3em;margin-top:.3em;max-height:14em;overflow:auto}' +
		'.gg-emoji-tabs button{padding:0 .4em;margin:0 .1em .2em 0;min-height:0}' +
		'.gg-emoji-grid span{display:inline-block;width:1.8em;text-align:center;font-size:1.25em;cursor:pointer;border-radius:4px}' +
		'.gg-emoji-grid span:hover{background:rgba(128,128,128,.25)}'
	]));
}

function isOld(ts) {
	var d = gg.toDate(ts);
	if (!d) return false;
	return d.toDateString() !== new Date().toDateString();
}

/* a short tone for a new message from someone else (muted with the box under the chat) */
var audioCtx = null;
function beep() {
	try {
		audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
		var o = audioCtx.createOscillator(), g = audioCtx.createGain(), t = audioCtx.currentTime;
		o.type = 'sine';
		o.frequency.setValueAtTime(880, t);
		o.frequency.setValueAtTime(1320, t + 0.07);
		g.gain.setValueAtTime(0.0001, t);
		g.gain.exponentialRampToValueAtTime(0.12, t + 0.01);
		g.gain.exponentialRampToValueAtTime(0.0001, t + 0.18);
		o.connect(g); g.connect(audioCtx.destination);
		o.start(t); o.stop(t + 0.2);
	}
	catch (e) {}
}

var ChatPanel = baseclass.extend({
	__init__: function(opts) {
		this.opts = opts || {};
		this.rev = null;
		this.sending = false;
		this.olderPending = false;
		this.running = false;
		this.root = null;
		this.editing = null;     /* { id, draft } while staff edit a message */
		this.lastId = null;      /* newest message seen (for the tone) */
		this.toastTs = 0;
		var self = this;
		this.pollFn = function() { return self.refresh(); };
	},

	render: function() {
		if (this.root)
			return this.root;
		var self = this;
		var height = this.opts.height || '45vh';
		injectFillStyle();

		this.errBox = E('div', { 'class': 'alert-message warning', 'style': 'display:none' });
		this.connBox = E('span', { 'style': 'font-size:85%;opacity:.75;font-weight:normal;margin-left:.6em' });
		this.flushBtn = E('button', {
			'class': 'btn cbi-button cbi-button-negative', 'style': 'display:none;float:right;font-size:80%',
			'click': function(ev) { ev.preventDefault(); self.confirmFlush(); }
		}, _('Clear chat…'));
		this.pinBox = E('div', { 'style': 'display:none;border:2px solid #e3b341;border-radius:6px;padding:.5em .8em;margin-bottom:.6em' });
		this.olderBtn = E('button', {
			'class': 'btn cbi-button',
			'style': 'display:none;margin:.3em auto',
			'click': function(ev) { ev.preventDefault(); self.loadOlder(); }
		}, _('Load older'));
		this.listEl = E('div');
		var fill = !!this.opts.fill;
		this.scrollEl = E('div', {
			'class': fill ? 'gg-chat-scroll' : null,
			'style': (fill ? '' : 'height:' + height + ';min-height:16em;') + 'overflow-y:auto;border:1px solid rgba(128,128,128,.35);border-radius:4px;padding:.3em .6em'
		}, [
			E('div', { 'style': 'text-align:center' }, this.olderBtn),
			this.listEl
		]);
		this.noticeBox = E('div', { 'style': 'font-size:85%;opacity:.8;margin:.4em 0' });
		this.onlineBox = E('div', { 'style': 'margin:.4em 0' });

		this.input = E('textarea', {
			'class': 'cbi-input-textarea',
			'rows': '2',
			'style': 'width:100%;box-sizing:border-box;resize:vertical',
			'placeholder': PLACEHOLDER,
			'keydown': function(ev) {
				if (ev.key === 'Enter' && !ev.shiftKey) { ev.preventDefault(); self.send(); }
				else if (ev.key === 'Escape' && self.editing) { ev.preventDefault(); self.cancelEdit(); }
			},
			'input': function() { self.updateCounter(); }
		});
		this.sendBtn = E('button', {
			'class': 'btn cbi-button cbi-button-action',
			'click': function(ev) { ev.preventDefault(); self.send(); }
		}, _('Send'));
		this.emojiPop = E('div', { 'class': 'gg-emoji-pop', 'style': 'display:none' });
		this.emojiBtn = E('button', {
			'class': 'btn cbi-button', 'title': _('Emoji'),
			'click': function(ev) { ev.preventDefault(); self.toggleEmoji(); }
		}, [ gg.emojiImg('😀', 1.1) ]);
		this.editLine = E('div', { 'style': 'display:none;font-size:85%;color:#d29922' }, [
			'✎ ' + _('Editing a message — Enter saves, Esc cancels') + ' ',
			E('a', { 'href': '#', 'click': function(ev) { ev.preventDefault(); self.cancelEdit(); } }, _('Cancel'))
		]);
		this.hint = E('div', { 'class': 'cbi-value-description', 'style': 'min-height:1.2em' });
		this.meLine = E('div', { 'style': 'font-size:85%;opacity:.75' });
		this.counter = E('span', { 'style': 'float:right;font-size:85%;opacity:.6' });
		this.muted = String(gg.storeGet('chat_mute', 'false')) === 'true';
		this.muteBox = E('input', {
			'type': 'checkbox', 'id': 'gg-chat-mute', 'checked': this.muted ? 'checked' : null,
			'change': function() { self.muted = this.checked; gg.storeSet('chat_mute', self.muted); }
		});

		this.root = E('div', { 'class': 'ggnet-chat' + (fill ? ' gg-chat-fill' : '') }, [
			E('h3', {}, [ _('Live chat'), this.connBox, this.flushBtn ]),
			this.errBox,
			this.pinBox,
			this.scrollEl,
			this.noticeBox,
			E('div', { 'style': 'margin-top:.5em' }, [
				this.editLine,
				this.input,
				E('div', { 'style': 'margin-top:.3em' }, [ this.sendBtn, ' ', this.emojiBtn, ' ', this.counter ]),
				this.emojiPop,
				this.hint,
				this.meLine,
				E('div', { 'style': 'font-size:85%;opacity:.75' }, [ this.muteBox, ' ',
					E('label', { 'for': 'gg-chat-mute' }, _('Mute new-message sound')) ])
			]),
			E('h4', {}, _('Online')),
			this.onlineBox
		]);

		this.setInputState(null);
		this.start();
		return this.root;
	},

	start: function() {
		if (this.running)
			return;
		this.running = true;
		this.rev = null;
		poll.add(this.pollFn, 2);
		this.refresh();
	},

	stop: function() {
		if (!this.running)
			return;
		this.running = false;
		poll.remove(this.pollFn);
	},

	refresh: function() {
		var self = this;
		return gg.call('chat').then(function(res) {
			if (self.running)
				self.update(res);
		});
	},

	update: function(res) {
		if (!res.ok) {
			this.errBox.textContent = gg.errorText(res);
			show(this.errBox, true);
			this.setInputState(null);
			this.rev = null;
			return;
		}
		show(this.errBox, !!res.error);
		if (res.error)
			this.errBox.textContent = CHAT_ERRORS[res.error] || String(res.error);

		this.connBox.textContent = res.connected ? '● ' + _('Connected') : '○ ' + _('Connecting to the chat…');
		this.connBox.style.color = res.connected ? '#3fb950' : '';

		var t = res.toast;
		if (t && t.ts && t.ts !== this.toastTs) {
			if (this.toastTs)
				this.setHint(t.text ? String(t.text) : (CHAT_ERRORS[t.code] || String(t.code)), true);
			this.toastTs = t.ts;
		}

		if (res.rev != null && res.rev === this.rev)
			return;
		var first = this.rev == null;
		this.rev = res.rev;
		this.me = res.me || {};

		var msgs = res.messages || [];
		this.ring(msgs, first);
		show(this.flushBtn, !!this.me.can_flush);
		this.renderPinned(res.pinned || []);
		this.renderMessages(msgs, !!res.more, first);
		this.renderNotices(res.notices || []);
		this.renderOnline(res.online || []);
		this.setInputState(this.me);
	},

	/* the tone: a newer message from someone else (not on the first load) */
	ring: function(msgs, first) {
		var newest = msgs.length ? Number(msgs[msgs.length - 1].id) : null;
		if (!first && !this.muted && newest != null && this.lastId != null && newest > this.lastId) {
			var me = this.me, last = this.lastId;
			if (msgs.some(function(m) { return Number(m.id) > last && !sameUser(me, m.user); }))
				beep();
		}
		if (newest != null)
			this.lastId = Math.max(this.lastId || 0, newest);
	},

	nameEl: function(user, role) {
		var self = this, mine = sameUser(this.me, user);
		var parts = [ E('strong', {
			'class': 'gg-name' + (mine ? ' gg-self' : ''),
			'style': 'color:' + gg.roleColor(role),
			'title': mine ? '' : _('Reply'),
			'click': mine ? null : function(ev) { ev.preventDefault(); self.replyTo(user); }
		}, [ String(user || '?') ]) ];
		var b = gg.roleBadge(role);
		if (b)
			parts.push(gg.badgeEl(b, gg.roleColor(role)));
		return parts;
	},

	msgEl: function(m, pinned) {
		var self = this, me = this.me || {};
		var mention = !m.filtered && !sameUser(me, m.user) && mentions(m.text, me.user);
		var text = m.filtered
			? E('div', { 'style': 'font-style:italic;opacity:.65' }, [ FILTERED_TEXT ])
			: E('div', { 'style': 'white-space:pre-wrap;word-break:break-word' }, gg.emojiText(m.text).concat([
				m.edited_at ? E('span', { 'style': 'margin-left:.4em;font-size:80%;opacity:.6' }, [ _('(edited)') ]) : '' ]));

		var acts = [];
		if (pinned) {
			if (me.can_pin)
				acts.push(E('button', { 'class': 'btn cbi-button', 'title': _('Unpin'),
					'click': function(ev) { ev.preventDefault(); self.cmd({ type: 'unpin', id: m.id }); } }, '✕'));
		}
		else if (me.can_moderate || me.can_pin) {
			if (canEdit(me, m) && !m.filtered)
				acts.push(E('button', { 'class': 'btn cbi-button', 'title': _('Edit'),
					'click': function(ev) { ev.preventDefault(); self.startEdit(m); } }, '✎'));
			acts.push(E('button', { 'class': 'btn cbi-button', 'title': _('More'),
				'click': function(ev) { ev.preventDefault(); self.menu(m); } }, '⋯'));
		}

		return E('div', {
			'class': 'gg-msg' + (mention ? ' gg-mention' : ''),
			'data-id': String(m.id),
			'title': mention ? _('Reply to you') : null
		}, [
			acts.length ? E('div', { 'class': 'gg-acts' }, acts) : '',
			E('div', {}, this.nameEl(m.user, m.role).concat([
				E('span', { 'style': 'margin-left:.6em;font-size:80%;opacity:.6' }, [ gg.formatTime(m.ts, !isOld(m.ts)) ])
			])),
			text
		]);
	},

	renderPinned: function(pins) {
		var self = this;
		if (!pins.length) {
			show(this.pinBox, false);
			return;
		}
		dom.content(this.pinBox, [ E('div', { 'style': 'font-weight:bold;color:#e3b341;margin-bottom:.2em' }, '📌 ' + _('Pinned')) ]
			.concat(pins.map(function(p) { return self.msgEl(p, true); })));
		show(this.pinBox, true);
	},

	renderMessages: function(msgs, more, first) {
		var self = this;
		var sc = this.scrollEl;
		var atBottom = first || sc.scrollHeight - sc.scrollTop - sc.clientHeight < 40;
		var fromBottom = sc.scrollHeight - sc.scrollTop;
		var oldTop = sc.scrollTop;
		var firstId = this.firstId;

		dom.content(this.listEl, msgs.length ? msgs.map(function(m) { return self.msgEl(m, false); })
			: E('p', { 'style': 'opacity:.6' }, _('No messages yet.')));
		this.firstId = msgs.length ? msgs[0].id : null;
		this.oldestId = this.firstId;

		show(this.olderBtn, more);
		this.olderBtn.disabled = false;

		var olderArrived = this.olderPending && firstId !== this.firstId;
		if (olderArrived)
			sc.scrollTop = sc.scrollHeight - fromBottom;   /* keep the same messages in view */
		else if (atBottom)
			sc.scrollTop = sc.scrollHeight;
		else
			sc.scrollTop = oldTop;

		if (olderArrived)
			this.olderPending = false;

		/* the panel may not be laid out yet on the first render */
		if (first)
			window.requestAnimationFrame(function() { sc.scrollTop = sc.scrollHeight; });
	},

	renderNotices: function(list) {
		dom.content(this.noticeBox, list.slice(-5).map(function(n) {
			return E('div', { 'style': 'white-space:pre-wrap' }, [
				E('span', { 'style': 'opacity:.6' }, [ gg.formatTime(n.ts, true) + '  ' ]),
				'ℹ️ ' + String(n.text || '')
			]);
		}));
	},

	/* at most ONLINE_MAX users, highest rank first, then alphabetical; "+N more" */
	renderOnline: function(list) {
		var self = this, me = this.me || {};
		if (!list.length) {
			dom.content(this.onlineBox, E('span', { 'style': 'opacity:.6' }, _('Nobody is online.')));
			return;
		}
		var sorted = list.slice().sort(function(a, b) {
			var r = roleRank(a.role) - roleRank(b.role);
			if (r)
				return r;
			return String(a.user || '').toLowerCase().localeCompare(String(b.user || '').toLowerCase());
		});
		var kids = sorted.slice(0, ONLINE_MAX).map(function(u) {
			var c = gg.roleColor(u.role), mine = sameUser(me, u.user);
			return E('span', {
				'style': 'display:inline-block;margin:.15em;padding:.1em .6em;border-radius:12px;border:1px solid ' + c + ';color:' + c +
					(mine ? '' : ';cursor:pointer'),
				'title': mine ? '' : (canSanction(me, u.role) ? _('Click to reply, right-click for moderation') : _('Reply')),
				'click': mine ? null : function(ev) { ev.preventDefault(); self.replyTo(u.user); },
				'contextmenu': (mine || !canSanction(me, u.role)) ? null : function(ev) { ev.preventDefault(); self.menu({ user: u.user, role: u.role }); }
			}, [ String(u.user || '?') ].concat(gg.roleBadge(u.role) ? [ gg.badgeEl(gg.roleBadge(u.role), c) ] : []));
		});
		if (sorted.length > ONLINE_MAX)
			kids.push(E('span', { 'style': 'display:inline-block;margin:.15em .3em;opacity:.6' },
				[ _('+%d more').format(sorted.length - ONLINE_MAX) ]));
		dom.content(this.onlineBox, kids);
	},

	setInputState: function(me) {
		var why = '', placeholder = PLACEHOLDER;
		var lines = [];

		if (!me) {
			why = _('Chat unavailable.');
		}
		else {
			var muted = me.muted_until ? gg.toDate(me.muted_until) : null;
			if (me.read_only) {
				why = String(me.read_only);
				placeholder = why;
			}
			else if (muted && muted.getTime() > Date.now()) {
				why = _('You are muted until %s.').format(muted.toLocaleString());
				placeholder = why;
			}
			else if (Number(me.daily_limit) > 0 && Number(me.remaining) === 0) {
				why = _('You have used all your messages for today.');
				placeholder = why;
			}

			if (me.locked)
				lines.push('🔒 ' + _('locked'));
			if (Number(me.slow_sec) > 2)
				lines.push(_('slow mode: 1 message / %d s').format(Number(me.slow_sec)));
			if (Number(me.daily_limit) > 0 && Number(me.remaining) >= 0)
				lines.push(_('%d of %d messages left today').format(Number(me.remaining), Number(me.daily_limit)));
			if (me.user)
				lines.push(_('You appear as %s').format(me.user));

			if (Number(me.max_length) > 0)
				this.input.setAttribute('maxlength', String(me.max_length));
		}
		if (this.editing)
			why = '';   /* staff editing are never limited by these */

		this.input.disabled = !!why;
		this.sendBtn.disabled = !!why || this.sending;
		this.emojiBtn.disabled = !!why;
		this.input.placeholder = placeholder;
		this.meLine.textContent = lines.join(' · ');
		this.updateCounter();
	},

	updateCounter: function() {
		var max = Number((this.me || {}).max_length) || 0;
		this.counter.textContent = max ? '%d/%d'.format(this.input.value.length, max) : '';
	},

	setHint: function(text, bad) {
		this.hint.textContent = text || '';
		this.hint.style.color = bad ? '#c33' : '';
	},

	/* 1.34: "@name " at the start of the input (replacing one already there), focused */
	replyTo: function(user) {
		if (!user || sameUser(this.me, user) || this.input.disabled)
			return;
		var v = this.input.value.replace(/^@\S+\s*/, '');
		this.input.value = '@' + String(user) + ' ' + v;
		this.input.focus();
		var end = this.input.value.length;
		try { this.input.setSelectionRange(end, end); } catch (e) {}
		this.updateCounter();
	},

	startEdit: function(m) {
		if (!this.editing)
			this.editing = { id: m.id, draft: this.input.value };
		else
			this.editing.id = m.id;
		this.input.value = String(m.text || '');
		show(this.editLine, true);
		this.sendBtn.textContent = _('Save');
		this.setInputState(this.me);
		this.input.focus();
		this.updateCounter();
	},

	cancelEdit: function() {
		if (!this.editing)
			return;
		this.input.value = this.editing.draft || '';
		this.editing = null;
		show(this.editLine, false);
		this.sendBtn.textContent = _('Send');
		this.setInputState(this.me);
		this.updateCounter();
	},

	cmd: function(c) {
		var self = this;
		return gg.call('chat_command', { cmd: c }).then(function(res) {
			if (!res.ok)
				self.setHint(res.message ? String(res.message) : (CHAT_ERRORS[res.error] || gg.errorText(res)), true);
			else
				self.refresh();
			return res;
		});
	},

	/* staff menu: Reply first, then what the rank allows */
	menu: function(m) {
		var self = this, me = this.me || {};
		var close = function() { ui.hideModal(); };
		var item = function(label, fn, cls) {
			return E('button', { 'class': 'btn cbi-button ' + (cls || ''), 'style': 'display:block;width:100%;margin:.2em 0;text-align:left',
				'click': function(ev) { ev.preventDefault(); close(); fn(); } }, label);
		};
		var items = [];
		if (!sameUser(me, m.user))
			items.push(item(_('Reply'), function() { self.replyTo(m.user); }));
		if (m.id != null) {
			if (canEdit(me, m) && !m.filtered)
				items.push(item('✎ ' + _('Edit'), function() { self.startEdit(m); }));
			if (canDelete(me, m))
				items.push(item('🗑 ' + _('Delete'), function() {
					if (window.confirm(_('Delete this message?')))
						self.cmd({ type: 'delete', id: m.id });
				}, 'cbi-button-negative'));
			if (me.can_pin)
				items.push(item('📌 ' + _('Pin'), function() { self.cmd({ type: 'pin', id: m.id }); }));
		}
		if (!sameUser(me, m.user) && canSanction(me, m.role)) {
			items.push(item('🔇 ' + _('Mute…'), function() { self.sanction('mute', m.user); }));
			items.push(item('🔈 ' + _('Unmute'), function() { self.cmd({ type: 'unmute', user: m.user }); }));
			items.push(item('⛔ ' + _('Ban from chat…'), function() { self.sanction('ban', m.user); }, 'cbi-button-negative'));
			items.push(item('✅ ' + _('Unban'), function() { self.cmd({ type: 'unban', user: m.user }); }));
		}
		ui.showModal(String(m.user || ''), items.concat([
			E('div', { 'class': 'right' }, [ E('button', { 'class': 'btn', 'click': close }, _('Close')) ])
		]));
	},

	sanction: function(kind, user) {
		var self = this;
		var opts = kind === 'mute'
			? [ [ 10, _('10 minutes') ], [ 60, _('1 hour') ], [ 1440, _('1 day') ], [ 10080, _('7 days') ], [ 43200, _('30 days') ] ]
			: [ [ 1, _('1 day') ], [ 7, _('7 days') ], [ 30, _('30 days') ], [ 0, _('Permanent') ] ];
		var sel = E('select', { 'class': 'cbi-input-select' }, opts.map(function(o) { return E('option', { 'value': String(o[0]) }, o[1]); }));
		var reason = E('input', { 'type': 'text', 'class': 'cbi-input-text', 'maxlength': '200', 'placeholder': _('Reason (optional)'), 'style': 'width:100%' });
		ui.showModal(kind === 'mute' ? _('Mute %s').format(user) : _('Ban %s from the chat').format(user), [
			E('div', {}, [ sel ]),
			E('div', { 'style': 'margin-top:.5em' }, [ reason ]),
			E('div', { 'class': 'right', 'style': 'margin-top:.8em' }, [
				E('button', { 'class': 'btn', 'click': ui.hideModal }, _('Cancel')), ' ',
				E('button', { 'class': 'btn cbi-button-negative', 'click': function() {
					var c = { type: kind, user: user, reason: reason.value.trim() };
					c[kind === 'mute' ? 'minutes' : 'days'] = Number(sel.value);
					ui.hideModal();
					self.cmd(c);
				} }, kind === 'mute' ? _('Mute') : _('Ban'))
			])
		]);
	},

	confirmFlush: function() {
		if (window.confirm(_('Clear the whole chat for everyone? Pinned messages are removed too.')))
			this.cmd({ type: 'flush' });
	},

	toggleEmoji: function() {
		var self = this;
		if (this.emojiPop.style.display !== 'none') {
			show(this.emojiPop, false);
			return;
		}
		var grid = E('div', { 'class': 'gg-emoji-grid' });
		var showCat = function(i) {
			dom.content(grid, gg.graphemes(EMOJI[i][1]).map(function(e) {
				return E('span', { 'title': e, 'click': function() { self.insert(e); } }, [ gg.emojiImg(e, 1.15) ]);
			}));
		};
		dom.content(this.emojiPop, [
			E('div', { 'class': 'gg-emoji-tabs' }, EMOJI.map(function(c, i) {
				return E('button', { 'class': 'btn cbi-button', 'click': function(ev) { ev.preventDefault(); showCat(i); } }, [ gg.emojiImg(c[0], 1.1) ]);
			})),
			grid
		]);
		showCat(0);
		show(this.emojiPop, true);
	},

	insert: function(text) {
		var el = this.input, s = el.selectionStart, e = el.selectionEnd;
		if (s == null) { el.value += text; }
		else {
			el.value = el.value.slice(0, s) + text + el.value.slice(e);
			el.selectionStart = el.selectionEnd = s + text.length;
		}
		el.focus();
		this.updateCounter();
	},

	send: function() {
		var self = this;
		var text = gg.stripEmoji(this.input.value).replace(/\s+$/, '');
		if (this.sending || this.input.disabled)
			return;
		if (!text.trim())
			return this.setHint(CHAT_ERRORS.empty, true);
		var max = Number((this.me || {}).max_length) || 500;
		if (text.length > max)
			return this.setHint(CHAT_ERRORS.too_long, true);
		if (text.split('\n').length > 8)
			return this.setHint(CHAT_ERRORS.too_many_lines, true);

		this.sending = true;
		this.sendBtn.disabled = true;
		this.setHint('');
		var p = this.editing
			? gg.call('chat_command', { cmd: { type: 'edit', id: this.editing.id, text: text } })
			: gg.call('chat_send', { text: text });
		p.then(function(res) {
			self.sending = false;
			self.sendBtn.disabled = self.input.disabled;
			if (res.ok) {
				if (self.editing) {
					var draft = self.editing.draft || '';
					self.editing = null;
					show(self.editLine, false);
					self.sendBtn.textContent = _('Send');
					self.input.value = draft;
				}
				else
					self.input.value = '';
				show(self.emojiPop, false);
				self.updateCounter();
				self.scrollEl.scrollTop = self.scrollEl.scrollHeight;
				self.refresh();
				return;
			}
			self.setHint(res.message ? String(res.message) : (CHAT_ERRORS[res.error] || gg.errorText(res)), true);
		});
	},

	loadOlder: function() {
		var self = this;
		if (this.oldestId == null)
			return;
		this.olderBtn.disabled = true;
		this.olderPending = true;
		gg.call('chat_history', { before: this.oldestId }).then(function(res) {
			if (!res.ok) {
				self.olderBtn.disabled = false;
				self.olderPending = false;
				self.setHint(_('Load older') + ': ' + gg.errorText(res), true);
			}
		});
	}
});

return baseclass.extend({
	ChatPanel: ChatPanel,
	create: function(opts) { return new ChatPanel(opts); },
	CHAT_ERRORS: CHAT_ERRORS
});
