'use strict';
'require baseclass';
'require ggnet.common as gg';

/*
 * Live bandwidth "wave" graph (like the Windows app's BandwidthGraph):
 * download is drawn upward from the middle line, upload downward, both as
 * smooth filled areas. Input = the `traffic` RPC result (samples are bytes/s,
 * one every 2 s, oldest first). Labels are HTML on top of the SVG so they
 * don't stretch with the drawing.
 *
 *   var g = graph.create({ height: 160, window: 300 });
 *   container.appendChild(g.node);
 *   g.update(trafficResult);
 */

var SVGNS = 'http://www.w3.org/2000/svg';
var VW = 1000, VH = 200;               /* viewBox units */

/* mid-saturation colours readable on light and dark themes */
var COLOR_DOWN = '#2f81f7';
var COLOR_UP = '#3fb950';

function svg(tag, attrs) {
	var el = document.createElementNS(SVGNS, tag);
	for (var k in attrs)
		if (attrs[k] != null)
			el.setAttribute(k, String(attrs[k]));
	return el;
}

/* smallest 1/2/5 × 10^k (bytes/s) >= v, at least 1 KB/s */
function niceMax(v) {
	v = Math.max(Number(v) || 0, 1024);
	var p = Math.pow(10, Math.floor(Math.log10(v)));
	var steps = [ 1, 2, 5, 10 ];
	for (var i = 0; i < steps.length; i++)
		if (steps[i] * p >= v)
			return steps[i] * p;
	return 10 * p;
}

/* smooth path through points using quadratic segments between midpoints
 * (never overshoots the points, so the area never crosses the baseline) */
function smoothLine(pts) {
	if (!pts.length)
		return '';
	var d = 'M' + pts[0][0].toFixed(1) + ',' + pts[0][1].toFixed(1);
	if (pts.length === 1)
		return d;
	for (var i = 1; i < pts.length - 1; i++) {
		var mx = (pts[i][0] + pts[i + 1][0]) / 2, my = (pts[i][1] + pts[i + 1][1]) / 2;
		d += ' Q' + pts[i][0].toFixed(1) + ',' + pts[i][1].toFixed(1) + ' ' + mx.toFixed(1) + ',' + my.toFixed(1);
	}
	var last = pts[pts.length - 1];
	d += ' L' + last[0].toFixed(1) + ',' + last[1].toFixed(1);
	return d;
}

function label(style, color) {
	return E('div', {
		'style': 'position:absolute;font-size:80%;line-height:1.2;white-space:nowrap;pointer-events:none;' +
			'padding:0 .3em;border-radius:3px;' + (color ? 'color:' + color + ';font-weight:bold;' : 'opacity:.7;') + style
	});
}

var Graph = baseclass.extend({
	__init__: function(opts) {
		opts = opts || {};
		this.height = Number(opts.height) || 160;
		this.windowSec = Number(opts.window) || 300;

		this.svg = svg('svg', {
			'viewBox': '0 0 ' + VW + ' ' + VH,
			'preserveAspectRatio': 'none',
			'width': '100%',
			'height': this.height,
			'style': 'display:block'
		});

		var mid = VH / 2;
		[ 0.25, 0.75 ].forEach(function(f) {
			this.svg.appendChild(svg('line', {
				'x1': 0, 'x2': VW, 'y1': VH * f, 'y2': VH * f,
				'stroke': 'currentColor', 'stroke-opacity': '.12', 'stroke-dasharray': '4 4',
				'vector-effect': 'non-scaling-stroke'
			}));
		}, this);

		this.areaDown = svg('path', { 'fill': COLOR_DOWN, 'fill-opacity': '.35', 'stroke': 'none' });
		this.areaUp = svg('path', { 'fill': COLOR_UP, 'fill-opacity': '.35', 'stroke': 'none' });
		this.lineDown = svg('path', { 'fill': 'none', 'stroke': COLOR_DOWN, 'stroke-width': '1.6', 'vector-effect': 'non-scaling-stroke' });
		this.lineUp = svg('path', { 'fill': 'none', 'stroke': COLOR_UP, 'stroke-width': '1.6', 'vector-effect': 'non-scaling-stroke' });
		[ this.areaDown, this.areaUp, this.lineDown, this.lineUp ].forEach(function(p) { this.svg.appendChild(p); }, this);

		this.svg.appendChild(svg('line', {
			'x1': 0, 'x2': VW, 'y1': mid, 'y2': mid,
			'stroke': 'currentColor', 'stroke-opacity': '.35', 'vector-effect': 'non-scaling-stroke'
		}));

		this.lblScaleTop = label('top:2px;left:2px');
		this.lblScaleBottom = label('bottom:2px;left:2px');
		this.lblZero = label('top:50%;left:2px;transform:translateY(-50%)');
		this.lblDown = label('top:2px;right:2px', COLOR_DOWN);
		this.lblUp = label('bottom:2px;right:2px', COLOR_UP);
		this.lblEmpty = label('top:50%;left:50%;transform:translate(-50%,-110%)');
		this.lblZero.textContent = '0';

		this.node = E('div', {}, [
			E('div', {
				'style': 'position:relative;border:1px solid rgba(128,128,128,.35);border-radius:4px;overflow:hidden;' +
					'background:rgba(128,128,128,.06)'
			}, [ this.svg, this.lblScaleTop, this.lblZero, this.lblScaleBottom, this.lblDown, this.lblUp, this.lblEmpty ]),
			E('div', { 'style': 'display:flex;justify-content:space-between;font-size:75%;opacity:.6;margin-top:.15em' }, [
				E('span', {}, _('−%d min').format(Math.round(this.windowSec / 60))),
				E('span', {}, [
					E('span', { 'style': 'color:' + COLOR_DOWN }, '▼ ' + _('download')), '  ',
					E('span', { 'style': 'color:' + COLOR_UP }, '▲ ' + _('upload'))
				]),
				E('span', {}, _('now'))
			])
		]);

		this.update(null);
	},

	update: function(res) {
		var samples = (res && Array.isArray(res.samples)) ? res.samples : [];
		var rate = (res && res.rate) || {};
		var mid = VH / 2, amp = mid - 6;

		var tEnd = samples.length ? Number(samples[samples.length - 1].t) : Date.now() / 1000;
		var tStart = tEnd - this.windowSec;
		var pts = samples.filter(function(s) { return Number(s.t) >= tStart; });

		var max = 0;
		pts.forEach(function(s) { max = Math.max(max, Number(s.down) || 0, Number(s.up) || 0); });
		max = niceMax(max);

		var xs = pts.map(function(s) { return (Number(s.t) - tStart) / this.windowSec * VW; }, this);
		var down = pts.map(function(s, i) { return [ xs[i], mid - Math.min(1, (Number(s.down) || 0) / max) * amp ]; });
		var up = pts.map(function(s, i) { return [ xs[i], mid + Math.min(1, (Number(s.up) || 0) / max) * amp ]; });

		var area = function(line, p) {
			if (p.length < 2) return '';
			return line + ' L' + p[p.length - 1][0].toFixed(1) + ',' + mid + ' L' + p[0][0].toFixed(1) + ',' + mid + ' Z';
		};
		var ld = pts.length >= 2 ? smoothLine(down) : '', lu = pts.length >= 2 ? smoothLine(up) : '';
		this.lineDown.setAttribute('d', ld);
		this.lineUp.setAttribute('d', lu);
		this.areaDown.setAttribute('d', area(ld, down));
		this.areaUp.setAttribute('d', area(lu, up));

		this.lblScaleTop.textContent = '▼ ' + gg.formatRate(max);
		this.lblScaleBottom.textContent = '▲ ' + gg.formatRate(max);
		this.lblDown.textContent = '▼ ' + gg.formatRate(rate.down != null ? rate.down : 0);
		this.lblUp.textContent = '▲ ' + gg.formatRate(rate.up != null ? rate.up : 0);
		this.lblEmpty.textContent = pts.length >= 2 ? '' : ((res && res.running === false) ? _('The proxy isn\'t running.') : _('Waiting for data…'));
	}
});

return baseclass.extend({
	Graph: Graph,
	create: function(opts) { return new Graph(opts); },
	COLOR_DOWN: COLOR_DOWN,
	COLOR_UP: COLOR_UP
});
