'use strict';
'require view';
'require dom';
'require ggnet.common as gg';
'require ggnet.report as report';

/* About (like the Windows About tab). */

function ext(href, text) {
	return E('a', { 'href': href, 'target': '_blank', 'rel': 'noopener noreferrer' }, [ text ]);
}

function muted(text, extra) {
	return E('div', { 'style': 'opacity:.65;' + (extra || '') }, [ text ]);
}

return view.extend({
	load: function() {
		return gg.call('status');
	},

	render: function(st) {
		report.mount();
		st = st || {};
		var version = st.ok && st.version ? 'v' + String(st.version) : '';
		var base = gg.safeUrl(st.server_base);

		var info = [
			[ _('GG Network service'), st.ok ? (version ? 'ggnetd ' + version : _('running')) : gg.errorText(st) ],
			[ _('GGamers address'), base ? ext(base, base) : '–' ],
			st.ok ? [ _('Signed in'), st.signed_in ? String(st.username || _('Yes')) : _('No') ] : null,
			st.ok ? [ _('Proxy'), st.running ? _('Running') : _('Stopped') ] : null
		].filter(function(r) { return r; });

		var card = E('div', { 'style': 'max-width:520px;margin:1em auto;text-align:center;line-height:1.5' }, [
			E('a', { 'href': 'https://GGamers.net', 'target': '_blank', 'rel': 'noopener noreferrer', 'title': 'https://GGamers.net' }, [
				E('img', { 'src': L.resource('ggnet/logo.png'), 'alt': 'GGamers', 'width': '96', 'height': '96', 'style': 'width:96px;height:96px' })
			]),
			E('div', { 'style': 'margin-top:.5em' }, [
				E('span', { 'style': 'font-size:1.6em;font-weight:bold' }, _('GG Network for OpenWrt')),
				version ? E('span', { 'style': 'margin-left:.5em;font-weight:600;color:#3fb950' }, [ version ]) : ''
			]),
			E('p', { 'style': 'margin:.6em auto 0;max-width:460px' },
				_('Route your games through GGamers servers and combos from your router — every device on your network, TCP and UDP, with Aggressive mode.')),

			muted(_('Created by'), 'margin-top:1.2em'),
			E('div', { 'style': 'font-size:1.2em;font-weight:bold;color:#3fb950' }, 'Yakuza'),

			muted(_('Contact'), 'margin-top:.9em'),
			E('div', {}, [ '✈ ', ext('https://t.me/Yakuza4', 'Telegram @Yakuza4') ]),
			E('div', {}, [ '👻 ', ext('https://www.snapchat.com/add/yakuuo', 'Snapchat @yakuuo') ]),

			muted(_('Special thanks to'), 'margin-top:.9em'),
			E('div', {}, 'RebootIQ · RebootSA'),

			muted(_('Website'), 'margin-top:.9em'),
			E('div', {}, [ ext('https://GGamers.net', 'https://GGamers.net') ]),

			muted(_('Made by gamers for gamers ❤️'), 'margin-top:1.2em;font-size:90%'),
			muted(_('Free for personal use. The author is not responsible for any ToS violations resulting from proxy use in online services.'), 'margin:.3em auto 0;max-width:460px;font-size:85%')
		]);

		var router = E('div', { 'class': 'cbi-section', 'style': 'max-width:520px;margin:1.5em auto 0' }, [
			E('h4', {}, _('This router')),
			E('table', { 'class': 'table' }, info.map(function(r) {
				return E('tr', { 'class': 'tr' }, [
					E('td', { 'class': 'td left', 'style': 'width:40%;font-weight:bold' }, [ r[0] ]),
					E('td', { 'class': 'td left' }, [ r[1] ])
				]);
			}))
		]);

		return E('div', {}, [
			E('h2', {}, _('GG Network — About')),
			card,
			router,
			this.renderUpdates(st)
		]);
	},

	/* Updates from the GitHub releases: the package for this router's CPU and package manager */
	renderUpdates: function(st) {
		var box = E('div', {});
		var msg = E('div', { 'style': 'margin-top:.5em' });
		var paint = function(u) {
			u = u || {};
			var rows = [
				[ _('Installed'), 'v' + String(u.current || st.version || '?') ],
				[ _('Latest release'), u.latest ? 'v' + String(u.latest) + (u.prerelease ? ' ' + _('(pre-release)') : '') : (u.checked_at ? _('none found') : _('not checked yet')) ],
				[ _('This router'), u.arch ? String(u.pkg_manager === 'apk' ? '.apk' : '.ipk') + ' · ' + String(u.arch) : '–' ],
				[ _('Last check'), u.checked_at ? gg.formatTime(u.checked_at) : '–' ]
			];
			var btns = [
				E('button', { 'class': 'btn cbi-button', 'click': function(ev) {
					ev.preventDefault();
					ev.target.disabled = true;
					msg.textContent = _('Checking…');
					gg.call('update_check').then(function(r) { paint(r); });
				} }, _('Check for updates'))
			];
			if (u.available && u.can_install)
				btns.push(' ', E('button', { 'class': 'btn cbi-button cbi-button-action', 'disabled': u.installing ? 'disabled' : null, 'click': function(ev) {
					ev.preventDefault();
					ev.target.disabled = true;
					gg.act('update_install', {}, _('Update')).then(function(r) {
						msg.textContent = r.ok ? _('Installing %s… GG Network restarts and this page reconnects in about a minute.').format(String(r.version)) : '';
					});
				} }, _('Update to v%s').format(String(u.latest))));
			btns.push(' ', E('a', { 'href': gg.safeUrl(u.page || ''), 'target': '_blank', 'rel': 'noopener noreferrer' }, _('All releases')));
			var note = u.error ? String(u.error) : (u.available ? (u.no_file ? String(u.no_file) : '') : (u.latest ? _('GG Network is up to date.') : ''));
			dom.content(box, [
				E('h4', {}, _('Updates')),
				E('table', { 'class': 'table' }, rows.map(function(r) {
					return E('tr', { 'class': 'tr' }, [
						E('td', { 'class': 'td left', 'style': 'width:40%;font-weight:bold' }, [ r[0] ]),
						E('td', { 'class': 'td left' }, [ r[1] ])
					]);
				})),
				E('div', {}, btns),
				msg,
				u.notes && u.available ? E('pre', { 'style': 'white-space:pre-wrap;max-height:16em;overflow:auto;margin-top:.6em' }, [ String(u.notes) ]) : '',
				E('div', { 'class': 'cbi-value-description' },
					_('Automatic updates and the check are set in Settings → Updates. An automatic update waits until no game uses GG Network.'))
			]);
			msg.textContent = note;
		};
		paint(st.update);
		gg.call('update_check').then(function(r) { if (r && r.ok !== false) paint(r); });
		return E('div', { 'class': 'cbi-section', 'style': 'max-width:520px;margin:1.5em auto 0' }, [ box ]);
	},

	handleSave: null,
	handleSaveApply: null,
	handleReset: null
});
