'use strict';
'require view';
'require poll';
'require ui';
'require dom';
'require ggnet.common as gg';
'require ggnet.report as report';
'require ggnet.map as ggmap';

/* Never show node IPs, domains or ports anywhere on this page (spec §7).
 * The game server host/port the user types is their own input, not a node. */

/* a full dotted IPv4, an IPv6 or a name with a dot (1.34: ask geoip / gameprobe only then) */
function looksLikeHost(h) {
	h = String(h || '').trim();
	var m = h.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
	if (m)
		return m.slice(1).every(function(x) { return Number(x) <= 255; });
	if (/^\d[\d.]*$/.test(h))
		return false;   /* an IPv4 still being typed */
	if (h.indexOf(':') >= 0)
		return /^[0-9a-f:.]+$/i.test(h) && h.split(':').length >= 3;
	return /^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)*\.[a-z]{2,}$/i.test(h);
}

function num(v) {
	if (v == null || v === '')
		return null;
	var n = Number(v);
	return (isFinite(n) && n >= 0) ? n : null;
}

function ms(v) {
	var n = num(v);
	return n == null ? '–' : Math.round(n) + 'ms';
}

function show(el, on) { el.style.display = on ? '' : 'none'; }

var S = {
	card:    'border:1px solid rgba(128,128,128,.4);border-radius:6px;padding:.7em .9em;margin:.6em 0;position:relative',
	track:   'display:flex;flex-wrap:wrap;align-items:center;gap:.2em;margin:.5em 0',
	node:    'display:inline-block;padding:.15em .5em;border:1px solid rgba(128,128,128,.5);border-radius:12px;white-space:nowrap',
	nodeOff: 'display:inline-block;padding:.15em .5em;border:1px solid #c33;border-radius:12px;white-space:nowrap;color:#c33;text-decoration:line-through',
	leg:     'display:inline-flex;flex-direction:column;align-items:center;min-width:3.5em;font-size:80%;opacity:.85',
	legLine: 'display:block;width:100%;border-top:2px solid rgba(128,128,128,.6);margin-top:.15em',
	total:   'font-size:1.8em;font-weight:bold;line-height:1.1',
	chip:    'display:inline-block;margin:.2em;padding:.25em .6em;border-radius:12px;border:1px solid rgba(128,128,128,.5);cursor:pointer;background:transparent',
	chipOff: 'display:inline-block;margin:.2em;padding:.25em .6em;border-radius:12px;border:1px dashed rgba(128,128,128,.5);opacity:.45;cursor:not-allowed',
	chipSel: 'display:inline-block;margin:.2em;padding:.25em .6em;border-radius:12px;border:2px solid #58a6ff;background:rgba(88,166,255,.15)'
};

function leg(label) {
	return E('span', { 'style': S.leg }, [ E('span', {}, [ label ]), E('span', { 'style': S.legLine }) ]);
}

function hopEl(h) {
	return E('span', {
		'style': h.online === false ? S.nodeOff : S.node,
		'title': h.online === false ? _('unavailable right now') : (h.country || '')
	}, gg.ccLabel(h.cc, String(h.name || '?')));
}

/* web panel comparison (comboui.html paint()): diff = direct − via */
function compareEl(direct, via) {
	var diff = direct - via, r = Math.round(diff);
	var pct = Math.round(diff / direct * 100);
	var line;
	if (r === 0)
		line = E('div', { 'style': 'font-weight:bold' }, [ _('Same as going direct') ]);
	else if (r > 0)
		line = E('div', { 'style': 'font-weight:bold;color:#2ea043' }, [ '↓ ' + _('You lowered your ping by %d ms (%d%%)').format(r, pct) ]);
	else
		line = E('div', { 'style': 'font-weight:bold;color:#e04848' }, [ '↑ ' + _('Direct is faster by %d ms').format(-r) ]);
	return E('div', { 'style': 'margin:.2em 0' }, [
		line,
		E('div', { 'style': 'font-size:85%;opacity:.75' }, [
			_('Direct: %d ms · Via this combo: %d ms').format(Math.round(direct), Math.round(via))
		])
	]);
}

function downHops(c) {
	return (c.hops || []).filter(function(h) { return h.online === false; }).map(function(h) { return h.name; });
}

return view.extend({
	data: null,
	nodes: null,
	tested: {},
	testing: {},
	market: { continent: '', country: '', q: '', page: 1, res: null, timer: null },
	targetManual: false,    /* the user picked the target country by hand */
	geoHost: '',
	geoSeq: 0,
	geoTimer: null,
	geoState: null,
	picked: [],
	probeMs: null,
	probing: false,
	lastProbe: 0,
	probeTimer: null,
	running: false,         /* status.running: Connect buttons are locked */
	direct: null,           /* builder: router → game server directly {host, port, ms, method} | {host, port, err} */
	directBusy: false,
	directSeq: 0,
	directTimer: null,
	lastDirect: 0,

	load: function() {
		return Promise.all([
			gg.call('combos'),
			gg.call('combo_nodes'),
			ggmap.load().catch(function() { return null; }),
			gg.call('status')
		]);
	},

	/* -------------------------------------------------------------- */
	/* Card                                                            */
	/* -------------------------------------------------------------- */

	renderCard: function(c, market) {
		var self = this;
		var hops = Array.isArray(c.hops) ? c.hops : [];
		var links = Array.isArray(c.links_ms) ? c.links_ms : [];
		var tested = market ? this.tested[c.id] : undefined;
		var showNums = !market || tested !== undefined;

		var yourPing = market ? (tested != null ? num(tested) : null) : num(c.live_ping_ms);
		var gamePing = num(c.game_ping_ms);
		var hasGame = gamePing != null || (c.game_host && !market);

		/* route track: You → nodes → target flag → 🎮 */
		var track = [ E('span', { 'style': S.node }, '🧑 ' + _('You')), leg(showNums ? ms(yourPing) : '–') ];
		hops.forEach(function(h, i) {
			track.push(hopEl(h));
			if (i < hops.length - 1)
				track.push(leg(showNums ? ms(links[i]) : '–'));
		});
		track.push(leg('→'));
		track.push(E('span', { 'style': S.node, 'title': String(c.target_name || gg.countryName(c.target_country) || '') },
			gg.ccLabel(c.target_country, String(c.target_name || gg.countryName(c.target_country) || ''))));
		if (hasGame) {
			track.push(leg(showNums ? ms(gamePing) : '–'));
			track.push(E('span', { 'style': S.node }, '🎮 ' + _('game server')));
		}

		/* total */
		var approx = c.links_complete === false;
		var totalBox;
		var compare = null;
		if (showNums && yourPing != null) {
			var linksTotal = num(c.links_total_ms) || 0;
			if (gamePing != null) {
				var inGame = yourPing + linksTotal + gamePing;
				totalBox = E('div', { 'style': 'text-align:right' }, [
					E('div', { 'style': 'font-size:80%;opacity:.8' }, _('Your ping in game')),
					E('div', { 'style': S.total }, (approx ? '≈' : '') + Math.round(inGame) + 'ms')
				]);
				/* like the web panel: lowered = direct − (your ping + links + exit→game),
				 * only with every link measured and your live ping known */
				var direct = num(c.direct_ms);
				if (direct == null)
					direct = num(c.my_direct_ping_ms);
				if (!market && direct != null && direct > 0 && c.links_complete !== false)
					compare = compareEl(direct, inGame);
			}
			else {
				totalBox = E('div', { 'style': 'text-align:right' }, [
					E('div', { 'style': 'font-size:80%;opacity:.8' }, _('You\'ll leave with')),
					E('div', { 'style': S.total }, [ (approx ? '≈' : '') + Math.round(yourPing + linksTotal) + 'ms ', gg.flag(c.target_country, { size: 20 }) ])
				]);
			}
		}
		else {
			totalBox = E('div', { 'style': 'text-align:right' }, [
				E('div', { 'style': 'font-size:80%;opacity:.8' }, gamePing != null ? _('Your ping in game') : _('You\'ll leave with')),
				E('div', { 'style': S.total }, '–')
			]);
		}

		/* header */
		var meta = [];
		if (c.owner && !c.official) meta.push(_('by %s').format(c.owner));
		if (c.connection_type_name) meta.push(String(c.connection_type_name));
		if (c.isp) meta.push(String(c.isp));
		if (c.attaches != null) meta.push(_('%d attached').format(Number(c.attaches) || 0));

		var head = E('div', {}, [
			E('strong', { 'style': 'font-size:110%' }, [ String(c.name || '?') ]),
			c.official ? gg.badgeEl(_('Official'), '#e3b341') : '',
			c.mine && market ? gg.badgeEl(_('Yours'), '#58a6ff') : '',
			c.attached && market ? gg.badgeEl(_('Attached'), '#3fb950') : '',
			E('div', { 'style': 'font-size:85%;opacity:.75' }, [ meta.join(' · ') ])
		]);

		/* buttons */
		var btns = [];
		if (market) {
			btns.push(E('button', {
				'class': 'btn cbi-button',
				'disabled': this.testing[c.id] ? true : null,
				'click': function(ev) { ev.preventDefault(); self.doTest(c); }
			}, this.testing[c.id] ? _('Testing…') : _('Test')));
			if (c.attached)
				btns.push(E('button', { 'class': 'btn cbi-button cbi-button-negative', 'click': function(ev) { ev.preventDefault(); self.doAction('combo_detach', c, _('Detach')); } }, _('Detach')));
			else if (!c.mine)
				btns.push(E('button', { 'class': 'btn cbi-button cbi-button-action', 'click': function(ev) { ev.preventDefault(); self.doAction('combo_attach', c, _('Attach')); } }, _('Attach')));
		}
		else {
			btns.push(E('button', {
				'class': 'btn cbi-button cbi-button-positive',
				'disabled': (c.available === false || this.running) ? true : null,
				'title': this.running ? _('Reconnects through this combo.') : null,
				'click': function(ev) { ev.preventDefault(); self.doConnect(c); }
			}, _('Connect')));
			if (c.mine)
				btns.push(E('button', { 'class': 'btn cbi-button cbi-button-negative', 'click': function(ev) {
					ev.preventDefault();
					if (confirm(_('Delete the combo "%s"? It is also removed for everyone who attached it.').format(c.name)))
						self.doAction('combo_delete', c, _('Delete'));
				} }, _('Delete')));
			else
				btns.push(E('button', { 'class': 'btn cbi-button cbi-button-negative', 'click': function(ev) { ev.preventDefault(); self.doAction('combo_detach', c, _('Detach')); } }, _('Detach')));
		}

		var body = [
			E('div', { 'style': 'display:flex;justify-content:space-between;gap:1em;align-items:flex-start' }, [
				head,
				E('div', { 'style': 'display:flex;gap:1em;align-items:flex-start' }, [
					totalBox,
					market ? E('div', {}, btns[0]) : ''
				])
			]),
			E('div', { 'style': S.track }, track)
		];

		if (compare)
			body.push(compare);
		if (market && num(c.user_ping_ms) != null)
			body.push(E('div', { 'style': 'font-size:85%;opacity:.75' },
				_('The sharer\'s own ping to the first node (from their ISP): %s').format(ms(c.user_ping_ms))));
		if (market && !showNums)
			body.push(E('div', { 'style': 'font-size:85%;opacity:.75' }, _('Press Test to measure your ping to this combo.')));
		if (!market && yourPing == null)
			body.push(E('div', { 'style': 'font-size:85%;opacity:.75' }, _('Measuring your ping to the first node…')));

		if (c.available === false) {
			var down = downHops(c);
			body.push(E('div', { 'class': 'alert-message warning', 'style': 'margin:.4em 0' },
				[ down.length ? _('This combo has a node that is unavailable right now (%s). Try another combo.').format(down.join(', '))
				              : _('This combo is unavailable right now. Try another combo.') ]));
		}

		body.push(E('div', { 'style': 'margin-top:.4em' }, market ? btns.slice(1) : btns.reduce(function(a, b) { a.push(b, ' '); return a; }, [])));

		return E('div', { 'style': S.card + (c.available === false ? ';opacity:.55' : '') }, body);
	},

	/* -------------------------------------------------------------- */
	/* Mine + attached                                                 */
	/* -------------------------------------------------------------- */

	renderOwn: function() {
		var self = this, d = this.data || {};
		var mine = d.mine || [], att = d.attached || [];
		var lim = d.limits || {};

		var parts = [];
		if (this.running)
			parts.push(E('div', { 'class': 'alert-message info', 'style': 'margin:.4em 0' }, [
				'🔒 ' + _('Stop the connection to switch server or combo.') + ' ',
				E('a', { 'href': L.url('admin/services/ggnet/network') }, [ _('Connection page →') ])
			]));
		parts.push(E('h3', {}, _('My combos') + (lim.max_combos ? ' (%d/%d)'.format(mine.length, lim.max_combos) : '')));
		if (!mine.length)
			parts.push(E('p', { 'class': 'cbi-section-descr' }, _('You have no combos yet. Build one in the "Build a combo" tab.')));
		mine.forEach(function(c) { parts.push(self.renderCard(c, false)); });

		parts.push(E('h3', {}, _('Attached combos') + (lim.max_attached ? ' (%d/%d)'.format(att.length, lim.max_attached) : '')));
		if (!att.length)
			parts.push(E('p', { 'class': 'cbi-section-descr' }, _('No attached combos. Find some in the Marketplace.')));
		att.forEach(function(c) { parts.push(self.renderCard(c, false)); });

		dom.content(this.ownBox, parts);
	},

	loadCombos: function() {
		var self = this;
		return gg.call('combos').then(function(res) { self.setData(res); });
	},

	setData: function(res) {
		if (!res.ok) {
			this.errBox.textContent = gg.errorText(res);
			show(this.errBox, true);
			return;
		}
		show(this.errBox, false);
		this.data = res;

		if (res.enabled === false) {
			this.errBox.textContent = _('Combos are turned off by GGamers right now.');
			show(this.errBox, true);
		}
		if (this.marketTabBtn)
			show(this.marketTabBtn, res.marketplace !== false);
		this.renderOwn();
		if (this.builderReady)
			this.renderBuilder();
	},

	doConnect: function(c) {
		var self = this;
		gg.call('status').then(function(st) {
			if (!st.ok) return gg.notify(st);
			if (!st.signed_in) return gg.notify({ error: 'not_signed_in' });
			var stop = st.running ? gg.call('stop') : Promise.resolve({ ok: true });
			return stop.then(function() {
				self.setRunning(false);
				return gg.call('select', { target: 'combo:' + c.id });
			}).then(function(r) {
				if (!r.ok) {
					/* error "running": show the daemon's own message */
					if (r.error === 'running')
						self.setRunning(true);
					return gg.notify(r, r.error === 'running' ? null : _('Select'));
				}
				return gg.act('start', {}, _('Start')).then(function(r2) {
					if (r2.ok)
						ui.addNotification(null, E('p', {}, [ _('Connecting through "%s".').format(c.name) ]), 'info');
				});
			});
		}).then(function() { return self.loadCombos(); });
	},

	/* the target is locked while connected: Connect buttons follow status.running */
	setRunning: function(on) {
		on = !!on;
		if (on === this.running)
			return;
		this.running = on;
		if (this.data)
			this.renderOwn();
	},

	pollRunning: function() {
		var self = this;
		return gg.call('status').then(function(st) {
			if (st.ok)
				self.setRunning(!!(st.signed_in && st.running));
		});
	},

	doAction: function(method, c, label) {
		var self = this;
		return gg.act(method, { id: c.id }, label).then(function(res) {
			if (!res.ok) return;
			return Promise.all([ self.loadCombos(), self.market.res ? self.fetchMarket() : null ]);
		});
	},

	/* -------------------------------------------------------------- */
	/* Marketplace                                                     */
	/* -------------------------------------------------------------- */

	buildMarket: function() {
		var self = this;
		var debounced = function() { self.market.page = 1; self.scheduleMarket(); };

		this.mRegion = E('select', { 'class': 'cbi-input-select', 'change': function() {
			self.market.continent = this.value;
			self.fillCountries();
			debounced();
		} }, [ E('option', { 'value': '' }, _('Any region')) ]);
		this.mCountry = gg.picker({
			placeholder: _('Any country'),
			searchPlaceholder: _('Search country…'),
			items: [ { value: '', label: _('Any country') } ],
			value: '',
			style: 'min-width:14em',
			onChange: function(v) {
				self.market.country = v;
				debounced();
			}
		});
		this.mSearch = E('input', { 'type': 'search', 'class': 'cbi-input-text', 'placeholder': _('Search name, ISP, owner, country, type…'), 'input': function() {
			self.market.q = this.value.trim();
			debounced();
		} });
		this.mList = E('div', {}, E('p', {}, _('Loading…')));
		this.mPager = E('div', { 'style': 'margin:.6em 0' });
		this.mInfo = E('div', { 'style': 'font-size:85%;opacity:.75' });

		return E('div', {}, [
			E('div', { 'style': 'display:flex;flex-wrap:wrap;gap:.5em;align-items:center' }, [
				E('label', {}, [ _('Region') + ' ', this.mRegion ]),
				E('span', { 'style': 'display:inline-flex;align-items:center;gap:.4em' }, [ _('Target country'), this.mCountry.node ]),
				this.mSearch
			]),
			this.mInfo,
			this.mList,
			this.mPager
		]);
	},

	fillCountries: function() {
		var res = this.market.res || {};
		var region = this.market.continent;
		var list = (res.countries || []).filter(function(c) { return !region || c.continent === region; });
		var cur = this.market.country;
		if (cur && !list.some(function(c) { return String(c.code).toUpperCase() === String(cur).toUpperCase(); }))
			this.market.country = cur = '';
		this.mCountry.setItems([ { value: '', label: _('Any country') } ].concat(list.map(function(c) {
			var code = String(c.code || '');
			return {
				value: code,
				cc: code,
				label: String(c.name || gg.countryName(code) || code),
				sub: c.count != null ? '(' + Number(c.count) + ')' : ''
			};
		})));
		this.mCountry.setValue(cur);
	},

	scheduleMarket: function() {
		var self = this;
		if (this.market.timer)
			window.clearTimeout(this.market.timer);
		this.market.timer = window.setTimeout(function() {
			self.market.timer = null;
			self.fetchMarket();
		}, 1500);
	},

	fetchMarket: function() {
		var self = this, m = this.market;
		var seq = (this.mSeq = (this.mSeq || 0) + 1);
		return gg.call('marketplace', { continent: m.continent, country: m.country, q: m.q, page: m.page }).then(function(res) {
			if (seq !== self.mSeq)
				return;
			if (!res.ok) {
				dom.content(self.mList, E('div', { 'class': 'alert-message warning' }, [ gg.errorText(res) ]));
				dom.content(self.mPager, []);
				return;
			}
			m.res = res;

			/* regions */
			if (document.activeElement !== self.mRegion) {
				dom.content(self.mRegion, [ E('option', { 'value': '' }, _('Any region')) ].concat((res.continents || []).map(function(c) {
					return E('option', { 'value': c.code }, [ String(c.name || c.code) ]);
				})));
				self.mRegion.value = m.continent;
			}
			if (!self.mCountry.isOpen())
				self.fillCountries();

			self.renderMarketList();
		});
	},

	renderMarketList: function() {
		var self = this, res = this.market.res || {};
		var list = res.combos || [];
		this.mInfo.textContent = _('%d combos found. Official combos first, then the most attached.').format(Number(res.total) || 0);
		dom.content(this.mList, list.length ? list.map(function(c) { return self.renderCard(c, true); })
			: E('p', {}, _('No combos match.')));

		var pages = Number(res.pages) || 1, page = Number(res.page) || 1;
		var btns = [];
		if (pages > 1) {
			var add = function(p, label) {
				btns.push(E('button', {
					'class': 'btn cbi-button' + (p === page ? ' cbi-button-action' : ''),
					'disabled': (p < 1 || p > pages || p === page) ? true : null,
					'style': 'margin:0 .15em',
					'click': function(ev) { ev.preventDefault(); self.market.page = p; self.fetchMarket(); }
				}, label));
			};
			add(page - 1, '‹');
			var from = Math.max(1, page - 4), to = Math.min(pages, from + 8);
			for (var p = from; p <= to; p++)
				add(p, String(p));
			add(page + 1, '›');
		}
		dom.content(this.mPager, btns);
	},

	doTest: function(c) {
		var self = this;
		var first = (c.hops || [])[0];
		if (!first)
			return;
		this.testing[c.id] = true;
		this.renderMarketList();
		gg.call('combo_probe', { node_id: first.id }).then(function(res) {
			delete self.testing[c.id];
			if (res.ok)
				self.tested[c.id] = res.ms;
			else {
				gg.notify(res, _('Test'));
				self.tested[c.id] = null;
			}
			/* re-read the page for fresh link / game numbers, then render */
			return self.fetchMarket();
		});
	},

	/* -------------------------------------------------------------- */
	/* Builder (world map, like the Windows app)                       */
	/* -------------------------------------------------------------- */

	nodeById: function(id) {
		var n = ((this.nodes || {}).nodes || []);
		for (var i = 0; i < n.length; i++)
			if (n[i].id === id) return n[i];
		return null;
	},

	linkMs: function(a, b) {
		var l = ((this.nodes || {}).links || []);
		var rev = null;
		for (var i = 0; i < l.length; i++) {
			if (l[i].from === a && l[i].to === b && num(l[i].ms) != null) return num(l[i].ms);
			if (l[i].from === b && l[i].to === a && num(l[i].ms) != null) rev = num(l[i].ms);
		}
		return rev;
	},

	limits: function() {
		var lim = (this.data || {}).limits || {};
		return { min: Number(lim.min_hops) || 2, max: Number(lim.max_hops) || 3 };
	},

	targetList: function() {
		var g = ggmap.geo();
		return (g && g.list && g.list.length) ? g.list : gg.countries();
	},

	targetName: function(cc) {
		if (!cc) return '';
		var g = ggmap.geo();
		var i = g && g.info ? g.info[String(cc).toUpperCase()] : null;
		return i && i.n ? String(i.n) : gg.countryName(cc);
	},

	builderOpen: function() {
		if (!this.buildPane || document.hidden)
			return false;
		var a = this.buildPane.getAttribute('data-tab-active');
		return a ? a === 'true' : this.buildPane.offsetParent !== null;
	},

	buildBuilder: function() {
		var self = this;
		var smallBtn = 'padding:0 .4em;margin:0 0 0 .2em;min-width:0;height:auto;line-height:1.5em';
		this.smallBtn = smallBtn;

		this.map = ggmap.create({ onPick: function(id) { self.togglePick(id); } });

		this.bHint = E('div', { 'style': 'margin:.4em 0;opacity:.85' });
		this.bChips = E('div', { 'style': S.track });
		this.bPickWarn = E('div', { 'class': 'alert-message warning', 'style': 'display:none;white-space:pre-wrap' });
		this.bEquation = E('div', { 'style': 'margin:.3em 0;font-size:110%;font-weight:bold' });
		this.bEqNote = E('div', { 'style': 'font-size:85%;opacity:.75' });

		this.bCountry = gg.picker({
			placeholder: _('— target country —'),
			searchPlaceholder: _('Search country…'),
			style: 'min-width:16em;max-width:100%',
			onChange: function(v) {
				self.targetManual = !!v;
				self.renderBuilder();
				self.renderGeoHint();
			}
		});
		this.bGameHost = E('input', { 'type': 'text', 'class': 'cbi-input-text', 'placeholder': _('Game server IP (optional)'), 'style': 'width:12em', 'autocapitalize': 'off', 'spellcheck': 'false', 'input': function() { self.renderEquation(); self.onGameHostInput(); } });
		this.bGeoHint = E('div', { 'style': 'display:none;font-size:90%;margin-top:.35em' });
		this.bGamePort = E('input', { 'type': 'number', 'class': 'cbi-input-text', 'placeholder': _('Port'), 'min': '0', 'max': '65535', 'style': 'width:6em', 'input': function() {
			if (self.bGameHost.value.trim()) {
				self.renderEquation();
				self.scheduleDirect();
			}
		} });
		this.bDirectBox = E('div', { 'style': 'display:none;margin:.3em 0;padding:.4em .7em;border-left:3px solid rgba(88,166,255,.6);background:rgba(88,166,255,.06);border-radius:3px' });
		this.bConnType = E('select', { 'class': 'cbi-input-select' });
		this.bIsp = E('input', { 'type': 'text', 'class': 'cbi-input-text', 'maxlength': '60', 'placeholder': _('e.g. STC Fiber') });
		this.bName = E('input', { 'type': 'text', 'class': 'cbi-input-text', 'maxlength': '40', 'placeholder': _('e.g. Aion EU low ping') });
		this.bProbeBtn = E('button', { 'class': 'btn cbi-button', 'click': function(ev) {
			ev.preventDefault();
			self.doProbe(false);
			if (self.bGameHost.value.trim())
				self.doDirect(false);
		} }, _('Measure my ping'));
		this.bProbeOut = E('span', { 'style': 'margin-left:.6em' });
		this.bMsg = E('div', { 'class': 'alert-message warning', 'style': 'display:none;white-space:pre-wrap' });
		this.bSave = E('button', { 'class': 'btn cbi-button cbi-button-save important', 'click': function(ev) { ev.preventDefault(); self.doCreate(); } }, _('Save combo'));

		this.fillTargetCountries();

		var r = function(label, w, descr) {
			return E('div', { 'class': 'cbi-value' }, [
				E('label', { 'class': 'cbi-value-title' }, label),
				E('div', { 'class': 'cbi-value-field' }, descr ? [ E('div', {}, w), E('div', { 'class': 'cbi-value-description' }, descr) ] : w)
			]);
		};

		this.builderReady = true;
		return E('div', {}, [
			E('p', { 'class': 'cbi-section-descr' },
				_('Click the nodes on the map in order: the first one is where your router connects, the last one is where your traffic leaves to the internet. Then choose the country you play in from the list. Scroll to zoom, drag to move the map.')),
			this.map.node,
			this.bHint,
			this.bChips,
			this.bPickWarn,
			E('div', { 'style': 'font-size:85%;opacity:.75;margin-top:.4em' }, _('Final expected latency')),
			this.bEquation,
			this.bEqNote,
			this.bDirectBox,
			E('div', { 'class': 'cbi-section-node' }, [
				r(_('Target country'), E('div', { 'style': 'display:flex;flex-wrap:wrap;gap:.4em;align-items:center' }, [
					this.bCountry.node,
					E('span', { 'style': 'margin-left:.6em' }, _('Game IP / host')), this.bGameHost,
					E('span', {}, _('Port')), this.bGamePort
				]), [ this.bGeoHint, E('div', {}, _('The country you play in — set automatically from the game server IP when you type one. The game server is optional: add it to see your in-game ping and the gain vs. going direct on the saved combo.')) ]),
				r(_('Your ping'), [ this.bProbeBtn, this.bProbeOut ], _('Latency from this router to the first node, and directly to the game server when you typed one. Measured again every 10 seconds while this tab is open.')),
				r(_('Connection type'), this.bConnType),
				r(_('ISP'), this.bIsp),
				r(_('Name'), this.bName)
			]),
			this.bMsg,
			E('div', { 'style': 'margin-top:.6em' }, [ this.bSave ])
		]);
	},

	fillTargetCountries: function() {
		if (!this.bCountry)
			return;
		this.bCountry.setItems(this.targetList().map(function(c) {
			return { value: c.code, cc: c.code, label: String(c.name || c.code) };
		}));
	},

	/* game server host typed → country by geoip (unless picked by hand) */
	onGameHostInput: function(delay) {
		var self = this;
		var host = this.bGameHost.value.trim();
		if (this.geoTimer) {
			window.clearTimeout(this.geoTimer);
			this.geoTimer = null;
		}
		if (!host) {
			this.geoSeq++;
			this.geoHost = '';
			this.geoState = null;
			this.targetManual = false;
			this.renderGeoHint();
			if (this.directTimer) {
				window.clearTimeout(this.directTimer);
				this.directTimer = null;
			}
			this.doDirect(false);       /* clears the direct ping */
			return;
		}
		/* direct ping to the typed game server (debounced) */
		this.scheduleDirect(delay != null ? delay : 900);
		if (host === this.geoHost)
			return;
		/* ask once the address looks complete (1.34), not on every key press */
		if (!looksLikeHost(host)) {
			this.geoSeq++;
			this.geoHost = '';
			this.geoState = null;
			this.renderGeoHint();
			return;
		}
		this.geoTimer = window.setTimeout(function() {
			self.geoTimer = null;
			self.lookupGeo(host);
		}, delay != null ? delay : 800);
	},

	lookupGeo: function(host) {
		var self = this;
		var seq = ++this.geoSeq;
		this.geoHost = host;
		this.geoState = { busy: true };
		this.renderGeoHint();
		return gg.call('geoip', { host: host }).then(function(res) {
			if (seq !== self.geoSeq || self.bGameHost.value.trim() !== host)
				return;
			var cc = res.ok ? String(res.cc || '').toUpperCase() : '';
			if (!res.ok || !gg.isCountry(cc)) {
				self.geoState = { err: res.ok ? { error: 'not_found' } : res };
				/* allow a retry of the same host */
				self.geoHost = '';
				self.renderGeoHint();
				return;
			}
			self.geoState = { cc: cc, ip: String(res.ip || '') };
			if (!self.targetManual && self.bCountry.getValue() !== cc) {
				self.bCountry.setValue(cc);
				self.renderBuilder();
			}
			self.renderGeoHint();
		});
	},

	renderGeoHint: function() {
		if (!this.bGeoHint)
			return;
		var g = this.geoState;
		if (!g || !this.bGameHost.value.trim()) {
			show(this.bGeoHint, false);
			return;
		}
		var kids;
		if (g.busy)
			kids = [ E('span', { 'style': 'opacity:.75' }, [ '📍 ' + _('Locating the game server…') ]) ];
		else if (g.err) {
			var e = g.err, txt;
			if (e.message)
				txt = String(e.message);
			else if (e.error === 'private')
				txt = _('This is a private (LAN) address — pick the target country by hand.');
			else if (e.error === 'not_found')
				txt = _('Couldn\'t find the country of this game server — pick the target country by hand.');
			else
				txt = gg.errorText(e);
			kids = [ E('span', { 'style': 'color:#d29922' }, [ '📍 ' + txt ]) ];
		}
		else {
			kids = [ '📍 ' + _('Located in') + ' ' ].concat(gg.ccLabel(g.cc));
			if (g.ip && g.ip !== this.bGameHost.value.trim())
				kids.push(E('span', { 'style': 'opacity:.65;margin-left:.4em' }, [ '(' + g.ip + ')' ]));
			if (this.targetManual && this.bCountry.getValue() && this.bCountry.getValue() !== g.cc)
				kids.push(E('span', { 'style': 'opacity:.75;margin-left:.4em' }, [ '· ' + _('your chosen target country is kept') ]));
		}
		dom.content(this.bGeoHint, kids);
		show(this.bGeoHint, true);
	},

	/* which picked nodes can't be used right now */
	badPicked: function() {
		var self = this;
		return this.picked.filter(function(id) {
			var n = self.nodeById(id);
			return !n || !n.usable;
		});
	},

	renderBuilder: function() {
		if (!this.bChips)
			return;
		var self = this;
		var nd = this.nodes || {};
		var nodes = nd.nodes || [];
		var lim = this.limits();
		var cc = this.bCountry.getValue();

		/* connection types (keep selection) */
		var types = nd.connection_types || [];
		var sigT = JSON.stringify(types);
		if (sigT !== this.typesSig && document.activeElement !== this.bConnType) {
			this.typesSig = sigT;
			var cur = this.bConnType.value;
			dom.content(this.bConnType, [ E('option', { 'value': '' }, _('— your connection —')) ].concat(types.map(function(t) {
				return E('option', { 'value': t.code }, [ String(t.name || t.code) ]);
			})));
			this.bConnType.value = cur;
		}

		/* map */
		var bad = this.badPicked();
		this.map.highlightInvalid(bad);
		this.map.setPicked(this.picked, cc);

		/* route chips: You → nodes (↑ ↓ ✕) → target */
		var chips = [];
		if (this.picked.length) {
			chips.push(E('span', { 'style': S.node }, '🧑 ' + _('You')));
			this.picked.forEach(function(id, i) {
				var n = self.nodeById(id) || { id: id, name: '#' + id, usable: false };
				chips.push(leg(i === 0 ? ms(self.probeMs) : ms(self.linkMs(self.picked[i - 1], id))));
				var ctl = gg.ccLabel(n.cc, (i + 1) + '. ' + String(n.name || '?'));
				ctl.push(E('button', {
					'class': 'btn cbi-button', 'style': self.smallBtn, 'title': _('Move up'),
					'disabled': i === 0 ? true : null,
					'click': function(ev) { ev.preventDefault(); self.movePick(i, -1); }
				}, '↑'));
				ctl.push(E('button', {
					'class': 'btn cbi-button', 'style': self.smallBtn, 'title': _('Move down'),
					'disabled': i === self.picked.length - 1 ? true : null,
					'click': function(ev) { ev.preventDefault(); self.movePick(i, 1); }
				}, '↓'));
				ctl.push(E('button', {
					'class': 'btn cbi-button', 'style': self.smallBtn, 'title': _('Remove'),
					'click': function(ev) { ev.preventDefault(); self.unpick(id); }
				}, '✕'));
				chips.push(E('span', {
					'style': (n.usable ? S.node : S.nodeOff.replace('text-decoration:line-through', '')) + ';display:inline-flex;align-items:center',
					'title': n.usable ? String(n.country || '') : String(n.why || _('unavailable'))
				}, ctl));
			});
			if (cc) {
				chips.push(leg('→'));
				chips.push(E('span', { 'style': S.node + ';border-color:#e3b341;display:inline-flex;align-items:center;gap:.2em' },
					gg.ccLabel(cc, this.targetName(cc)).concat([
						E('button', {
							'class': 'btn cbi-button', 'style': this.smallBtn, 'title': _('Remove'),
							'click': function(ev) {
								ev.preventDefault();
								self.bCountry.setValue('');
								self.targetManual = false;
								self.renderBuilder();
								self.renderGeoHint();
							}
						}, '✕')
					])));
			}
		}
		dom.content(this.bChips, chips);

		/* unusable picked nodes */
		var badNames = bad.map(function(id) { return (self.nodeById(id) || {}).name || ('#' + id); });
		this.bPickWarn.textContent = badNames.map(function(n) {
			return _('%s is unavailable right now: remove it and pick another node').format(n);
		}).join('\n');
		show(this.bPickWarn, bad.length > 0);
		this.pickBad = bad.length > 0;

		/* hint */
		var hint;
		if (!nodes.some(function(n) { return n.usable; }))
			hint = _('No nodes are available for combos right now.');
		else if (!this.picked.length)
			hint = _('① Click the node your router should connect to first.');
		else if (this.picked.length < lim.min)
			hint = _('② Add %d more node(s), in order (each node once, up to %d).').format(lim.min - this.picked.length, lim.max);
		else if (!cc)
			hint = _('③ Choose the country you play in from the Target country list, then name and save the combo.');
		else
			hint = _('Ready: name the combo and save it.');
		if (this.picked.length >= lim.max && !this.pickBad)
			hint += ' ' + _('(%d nodes is the maximum.)').format(lim.max);
		this.bHint.textContent = hint;

		this.renderEquation();
	},

	/* "You (23 ms) → riyadh-1 (41 ms) → frankfurt → [FR flag] = ≈ 64 ms" */
	renderEquation: function() {
		if (!this.bEquation)
			return;
		var self = this;
		var cc = this.bCountry.getValue();
		if (!this.picked.length) {
			this.bEquation.textContent = '—';
			this.bEqNote.textContent = '';
			this.renderDirect(0, true);
			return;
		}
		var sum = this.probeMs != null ? Number(this.probeMs) : 0;
		var linksSum = 0, linksAll = true;
		var parts = [ _('You') + ' (' + (this.probeMs != null ? Math.round(this.probeMs) + ' ms' : '? ms') + ')' ];
		this.picked.forEach(function(id, i) {
			var n = self.nodeById(id) || { name: '#' + id };
			var s = String(n.name || '?');
			if (i < self.picked.length - 1) {
				var l = self.linkMs(id, self.picked[i + 1]);
				s += ' (' + (l != null ? Math.round(l) + ' ms' : '? ms') + ')';
				if (l != null) { sum += l; linksSum += l; }
				else linksAll = false;
			}
			parts.push(s);
		});
		this.renderDirect(linksSum, linksAll);
		var eq = [ parts.join(' → ') ];
		if (cc) {
			var fl = gg.flag(cc, { size: 16 });
			eq.push(' → ', fl || this.targetName(cc));
		}
		var hasGame = this.bGameHost.value.trim() !== '';
		if (this.probeMs != null)
			eq.push(' = ≈ ' + Math.round(sum) + ' ms');
		dom.content(this.bEquation, eq);

		var note;
		if (this.probeMs == null)
			note = this.probing ? _('Measuring your ping to the first node…') : _('Your ping to the first node is measured automatically.');
		else if (hasGame)
			note = '';
		else
			note = _('You\'ll leave with about this ping in the target country.');
		this.bEqNote.textContent = note;
	},

	/* "Direct to game server: N ms (icmp)" / "Via this route to the exit: …" / note */
	renderDirect: function(linksSum, linksAll) {
		if (!this.bDirectBox)
			return;
		var host = this.bGameHost.value.trim();
		if (!host) {
			show(this.bDirectBox, false);
			return;
		}
		var d = this.direct, dTxt, dColor = '';
		if (!d || d.host !== host || d.port !== this.gamePort() || d.busy)
			dTxt = _('measuring…');
		else if (d.err) {
			dTxt = gg.errorText(d.err);
			dColor = '#d29922';
		}
		else
			dTxt = _('%d ms (%s)').format(Math.round(d.ms), d.method || '?');

		var lines = [
			E('div', {}, [
				_('Direct to game server:') + ' ',
				E('strong', { 'style': dColor ? 'color:' + dColor : '' }, [ dTxt ])
			])
		];
		if (this.picked.length) {
			var via = this.probeMs != null
				? (linksAll ? '' : '≈ ') + Math.round(Number(this.probeMs) + linksSum) + ' ms'
				: '? ms';
			lines.push(E('div', {}, [
				_('Via this route to the exit: your ping + links =') + ' ',
				E('strong', {}, [ via ])
			]));
		}
		/* 1.34: the last picked node measures the game server → "your ping in game" */
		this.scheduleGameProbe();
		var g = this.gp, last = this.picked.length ? this.picked[this.picked.length - 1] : 0;
		if (last && looksLikeHost(host)) {
			/* like the Windows builder: your ping in game = you → first node + the links + LAST NODE → GAME SERVER */
			var lastName = String((this.nodeById(last) || {}).name || '#' + last);
			var approx = linksAll ? '' : '≈ ';
			var known = this.probeMs != null ? Number(this.probeMs) + linksSum : null;
			var cur = g && g.key === last + '|' + host + '|' + this.gamePort();
			if (!cur || g.busy) {
				/* waiting for the real number: no partial total that could be taken for the answer */
				lines.push(E('div', { 'style': 'margin-top:.3em;font-weight:bold;color:#3fb950' }, [ _('Your ping in game: measuring…') ]));
				lines.push(E('div', { 'style': 'font-size:85%;opacity:.75' }, [ (g && g.waiting)
					? _('Waiting a few seconds — the panel allows one game server test every ~5 s.')
					: _('%s is testing the game server — the total appears in a few seconds.').format(lastName) ]));
			}
			else if (g.err) {
				lines.push(E('div', { 'style': 'margin-top:.3em;font-weight:bold;color:#d29922' }, [ _('Your ping in game: couldn\'t be measured') ]));
				lines.push(E('div', { 'style': 'font-size:85%;opacity:.75' }, [ String(g.err) ]));
				if (known != null)
					lines.push(E('div', { 'style': 'font-size:85%;opacity:.75' }, [
						_('Without the game server: you\'ll leave %s with %s').format(lastName, approx + Math.round(known) + ' ms') ]));
			}
			else if (known == null) {
				lines.push(E('div', { 'style': 'margin-top:.3em;font-weight:bold;color:#3fb950' }, [ _('Your ping in game: measuring…') ]));
				lines.push(E('div', { 'style': 'font-size:85%;opacity:.75' }, [ _('Measuring your ping to the first node…') ]));
			}
			else {
				var total = known + g.ms;
				var cc = this.bCountry.getValue();
				lines.push(E('div', { 'style': 'margin-top:.3em;font-weight:bold;color:#3fb950;font-size:110%' },
					[ _('Your ping in game %s').format(approx + Math.round(total) + ' ms') + ' ' ].concat(cc ? [ gg.flag(cc, { size: 16 }) ] : [])));
				lines.push(E('div', { 'style': 'font-size:85%;opacity:.75' }, [
					_('you %d + links %d + %s → game %d ms (%s)').format(Math.round(this.probeMs), Math.round(linksSum), lastName, Math.round(g.ms), String(g.method || '?')) ]));
				var dm = (d && d.host === host && d.port === this.gamePort() && !d.busy && !d.err) ? d.ms : null;
				if (dm != null) {
					var save = dm - total, pct = dm > 0 ? Math.abs(save) / dm * 100 : 0;
					if (save >= 1)
						lines.push(E('div', { 'style': 'font-weight:bold;color:#2ea043' },
							[ _('▼ You lowered your ping by %d ms (%d%%)').format(Math.round(save), Math.round(pct)) ]));
					else if (save <= -1)
						lines.push(E('div', { 'style': 'font-weight:bold;color:#d29922' },
							[ _('▲ Your ping increased by %d ms (%d%%)').format(Math.round(-save), Math.round(pct)) ]));
					else
						lines.push(E('div', { 'style': 'opacity:.75' }, [ _('About the same as going direct') ]));
				}
				else if (!d || d.busy)
					lines.push(E('div', { 'style': 'font-size:85%;opacity:.75' }, [ _('Measuring your direct ping to the game server…') ]));
			}
		}
		else if (!this.picked.length)
			lines.push(E('div', { 'style': 'font-size:85%;opacity:.75;margin-top:.2em' }, [
				_('Pick the nodes: the last one measures the game server, so you see your ping in game before saving.') ]));
		dom.content(this.bDirectBox, lines);
		show(this.bDirectBox, true);
	},

	/* debounced: 1.1 s after the route or the game server changed; too_frequent → wait 5.2 s, up to 12 tries */
	scheduleGameProbe: function() {
		var self = this;
		var host = this.bGameHost.value.trim();
		var last = this.picked.length ? this.picked[this.picked.length - 1] : 0;
		if (!last || !looksLikeHost(host))
			return;
		var key = last + '|' + host + '|' + this.gamePort();
		if (this.gp && this.gp.key === key)
			return;   /* done, running or waiting for this route */
		if (this.gpTimer)
			window.clearTimeout(this.gpTimer);
		this.gp = { key: key, busy: true };
		var tries = 0;
		var run = function() {
			self.gpTimer = null;
			if (!self.gp || self.gp.key !== key)
				return;
			gg.call('combo_gameprobe', { node_id: last, host: host, port: self.gamePort() }).then(function(res) {
				if (!self.gp || self.gp.key !== key)
					return;
				var busy = !res.ok && (res.error === 'too_frequent' || res.error === 'rate_limited');
				if (busy && ++tries < 12) {
					self.gp = { key: key, busy: true, waiting: true };
					self.gpTimer = window.setTimeout(run, 5200);
					self.renderEquation();
					return;
				}
				if (res.ok && num(res.ms) != null)
					self.gp = { key: key, ms: Number(res.ms), method: String(res.method || ''), node: String(res.node || '') };
				else if (busy)
					self.gp = { key: key, err: _('The game server test is busy right now, try again in a minute.') };
				else
					self.gp = { key: key, err: res.message ? String(res.message) : gg.errorText(res) };
				self.renderEquation();
			});
		};
		this.gpTimer = window.setTimeout(run, 1100);
	},

	/* debounced direct ping after the game host / port changed */
	scheduleDirect: function(delay) {
		var self = this;
		if (this.directTimer)
			window.clearTimeout(this.directTimer);
		this.directTimer = window.setTimeout(function() {
			self.directTimer = null;
			self.doDirect(false);
		}, delay != null ? delay : 900);
	},

	gamePort: function() {
		var p = parseInt(this.bGamePort.value.trim(), 10);
		return (p > 0 && p <= 65535) ? p : 0;
	},

	/* router → typed game server directly (never through the tunnel) */
	doDirect: function(auto) {
		var self = this;
		var host = this.bGameHost.value.trim();
		var port = this.gamePort();
		if (!host) {
			this.directSeq++;
			this.direct = null;
			this.directKey = null;
			this.renderEquation();
			return Promise.resolve();
		}
		var key = host + '|' + port;
		if (this.directKey === key)              /* same request already running */
			return Promise.resolve();
		if (auto && Date.now() - (this.lastDirect || 0) < 8000)
			return Promise.resolve();
		var seq = ++this.directSeq;
		this.directKey = key;
		this.lastDirect = Date.now();
		if (!this.direct || this.direct.host !== host || this.direct.port !== port)
			this.direct = { host: host, port: port, busy: true };
		this.renderEquation();
		return gg.call('direct_ping', { host: host, port: port }).then(function(res) {
			if (seq !== self.directSeq)
				return;
			self.directKey = null;
			if (self.bGameHost.value.trim() !== host || self.gamePort() !== port)
				return;
			if (res.ok && num(res.ms) != null)
				self.direct = { host: host, port: port, ms: Number(res.ms), method: String(res.method || '') };
			else
				self.direct = { host: host, port: port, err: res };
			self.renderEquation();
		});
	},

	togglePick: function(id) {
		if (this.picked.indexOf(id) >= 0)
			return this.unpick(id);
		var n = this.nodeById(id);
		var lim = this.limits();
		if (!n || !n.usable || this.picked.length >= lim.max)
			return;
		var oldFirst = this.picked[0];
		this.picked.push(id);
		this.afterRouteChange(oldFirst);
	},

	unpick: function(id) {
		var i = this.picked.indexOf(id);
		if (i < 0) return;
		var oldFirst = this.picked[0];
		this.picked.splice(i, 1);
		this.afterRouteChange(oldFirst);
	},

	movePick: function(i, dir) {
		var j = i + dir;
		if (j < 0 || j >= this.picked.length) return;
		var oldFirst = this.picked[0];
		var t = this.picked[i];
		this.picked[i] = this.picked[j];
		this.picked[j] = t;
		this.afterRouteChange(oldFirst);
	},

	/* only re-measure when the FIRST node changed */
	afterRouteChange: function(oldFirst) {
		var changed = this.picked[0] !== oldFirst;
		if (changed) {
			this.probeMs = null;
			this.bProbeOut.textContent = '';
		}
		this.renderBuilder();
		if (changed && this.picked.length)
			this.scheduleProbe();
	},

	/* probe soon, respecting the ~5 s rate limit */
	scheduleProbe: function() {
		var self = this;
		if (this.probeTimer)
			window.clearTimeout(this.probeTimer);
		var wait = Math.max(0, 5200 - (Date.now() - (this.lastProbe || 0)));
		this.probeTimer = window.setTimeout(function() {
			self.probeTimer = null;
			self.doProbe(true);
		}, wait);
	},

	doProbe: function(auto) {
		var self = this;
		if (!this.picked.length) {
			if (!auto)
				this.bProbeOut.textContent = _('Pick the first node first.');
			return Promise.resolve();
		}
		if (this.probing || (Date.now() - (this.lastProbe || 0)) < 5000) {
			if (!auto)
				this.scheduleProbe();
			return Promise.resolve();
		}
		var first = this.picked[0];
		this.probing = true;
		this.lastProbe = Date.now();
		this.bProbeBtn.disabled = true;
		if (this.probeMs == null)
			this.bProbeOut.textContent = _('Measuring…');
		this.renderEquation();
		return gg.call('combo_probe', { node_id: first }).then(function(res) {
			self.probing = false;
			window.setTimeout(function() { self.bProbeBtn.disabled = false; }, 5000);
			if (self.picked[0] !== first)
				return;
			if (res.ok && num(res.ms) != null) {
				self.probeMs = Number(res.ms);
				self.bProbeOut.textContent = _('%s to %s').format(ms(res.ms), (self.nodeById(first) || {}).name || '');
			}
			else if (!(auto && (res.error === 'too_frequent' || res.error === 'rate_limited')))
				self.bProbeOut.textContent = gg.errorText(res);
			self.renderBuilder();
		});
	},

	setBuildMsg: function(text, sev) {
		this.bMsg.className = 'alert-message ' + (sev || 'warning');
		this.bMsg.textContent = text || '';
		show(this.bMsg, !!text);
	},

	doCreate: function() {
		var self = this;
		var lim = this.limits();
		var name = this.bName.value.trim();
		var host = this.bGameHost.value.trim();
		var portTxt = this.bGamePort.value.trim();
		var port = (portTxt === '' || !host) ? 0 : parseInt(portTxt, 10);
		var errs = [];

		if (this.picked.length < lim.min || this.picked.length > lim.max)
			errs.push(_('Pick %d to %d nodes.').format(lim.min, lim.max));
		if (this.pickBad)
			this.badPicked().forEach(function(id) {
				errs.push(_('%s is unavailable right now: remove it and pick another node').format((self.nodeById(id) || {}).name || ('#' + id)));
			});
		if (!this.bCountry.getValue())
			errs.push(_('Pick the target country.'));
		if (!this.bConnType.value)
			errs.push(_('Pick your connection type.'));
		if (name.length < 1 || name.length > 40)
			errs.push(_('The name must be 1 to 40 characters.'));
		if (isNaN(port) || port < 0 || port > 65535)
			errs.push(_('The game server port must be 0 to 65535.'));

		if (errs.length)
			return this.setBuildMsg(errs.join('\n'), 'warning');

		var args = {
			name: name,
			hops: this.picked.slice(),
			isp: this.bIsp.value.trim(),
			target_country: this.bCountry.getValue().toUpperCase(),
			connection_type: this.bConnType.value,
			game_host: host,
			game_port: port
		};
		if (this.probeMs != null)
			args.user_ping_ms = Math.min(2000, Math.round(this.probeMs * 10) / 10);

		this.setBuildMsg('');
		this.bSave.disabled = true;
		gg.call('combo_create', args).then(function(res) {
			self.bSave.disabled = false;
			if (!res.ok)
				return self.setBuildMsg(gg.errorText(res), 'danger');
			self.setBuildMsg(_('Saved "%s". It is in "My combos" and shared on the marketplace.').format((res.combo || {}).name || name), 'info');
			self.picked = [];
			self.probeMs = null;
			self.bName.value = '';
			self.bProbeOut.textContent = '';
			self.renderBuilder();
			return self.loadCombos();
		});
	},

	loadNodes: function() {
		var self = this;
		return gg.call('combo_nodes').then(function(res) {
			if (res.ok)
				self.setNodes(res);
		});
	},

	setNodes: function(res) {
		this.nodes = res;
		if (this.map)
			this.map.setNodes(res.nodes || [], res.links || []);
		this.renderBuilder();
	},

	/* "…#game=HOST:PORT" from the Connections page (port 0 = leave blank) */
	applyHashPrefill: function() {
		var m = String(location.hash || '').match(/(?:^#|[#&?])game=([^&]*)/);
		if (!m)
			return false;
		var v = '';
		try { v = decodeURIComponent(m[1]); } catch (e) { v = m[1]; }
		var host = v, port = 0;
		var b = v.match(/^\[([^\]]+)\](?::(\d+))?$/);           /* [v6]:port */
		if (b) { host = b[1]; port = parseInt(b[2] || '0', 10); }
		else if ((v.match(/:/g) || []).length === 1) {           /* host:port */
			host = v.slice(0, v.indexOf(':'));
			port = parseInt(v.slice(v.indexOf(':') + 1), 10) || 0;
		}
		host = host.trim();
		if (!host)
			return false;
		this.bGameHost.value = host;
		this.bGamePort.value = (port > 0 && port <= 65535) ? String(port) : '';
		this.targetManual = false;
		this.geoHost = '';
		this.onGameHostInput(0);
		try { history.replaceState(null, '', location.pathname + location.search); } catch (e) {}
		this.openBuilderTab();
		this.renderEquation();
		return true;
	},

	openBuilderTab: function() {
		var self = this;
		window.requestAnimationFrame(function() {
			var a = self.root && self.root.querySelector('.cbi-tabmenu li[data-tab="build"] a');
			if (a) a.click();
			if (self.buildPane && self.buildPane.scrollIntoView)
				self.buildPane.scrollIntoView({ block: 'start' });
		});
	},

	/* -------------------------------------------------------------- */

	render: function(data) {
		report.mount();
		var self = this;

		this.errBox = E('div', { 'class': 'alert-message warning', 'style': 'display:none' });
		this.ownBox = E('div');
		this.buildPane = E('div', { 'data-tab': 'build', 'data-tab-title': _('Build a combo') }, [ this.buildBuilder() ]);

		var tabs = E('div', {}, [
			E('div', { 'data-tab': 'own', 'data-tab-title': _('My combos') }, [ this.ownBox ]),
			E('div', { 'data-tab': 'market', 'data-tab-title': _('Marketplace') }, [ this.buildMarket() ]),
			this.buildPane
		]);

		var root = E('div', {}, [
			E('h2', {}, _('Combos')),
			E('div', { 'class': 'cbi-map-descr' },
				_('A combo is a chain of GGamers nodes: your router connects to the first one and your traffic leaves from the last one.')),
			this.errBox,
			E('div', { 'class': 'cbi-section' }, tabs)
		]);
		this.root = root;

		ui.tabs.initTabGroup(tabs.childNodes);

		/* target list may have been filled before the geo names were ready */
		this.fillTargetCountries();
		gg.loadCountries().then(function() {
			if (!ggmap.geo())
				self.fillTargetCountries();
		});
		if (data[1] && data[1].ok)
			this.setNodes(data[1]);
		this.running = !!(data[3] && data[3].ok && data[3].signed_in && data[3].running);
		this.setData(data[0]);
		this.renderBuilder();

		/* hide the marketplace tab when the feature is off */
		window.requestAnimationFrame(function() {
			var li = root.querySelector('.cbi-tabmenu li[data-tab="market"]');
			if (li) {
				self.marketTabBtn = li;
				show(li, !self.data || self.data.marketplace !== false);
			}
		});

		this.applyHashPrefill();
		window.addEventListener('hashchange', function() { self.applyHashPrefill(); });

		this.fetchMarket();

		poll.add(function() { return self.loadCombos(); }, 30);
		poll.add(function() { return self.loadNodes(); }, 15);
		poll.add(function() {
			var p = [];
			if (self.builderOpen() && self.picked.length)
				p.push(self.doProbe(true));
			if (self.builderOpen() && self.bGameHost.value.trim())
				p.push(self.doDirect(true));
			return Promise.all(p);
		}, 10);
		poll.add(function() { return self.pollRunning(); }, 3);

		return root;
	},

	handleSave: null,
	handleSaveApply: null,
	handleReset: null
});
