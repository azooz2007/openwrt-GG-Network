'use strict';
'require view';
'require poll';
'require dom';
'require ggnet.common as gg';
'require ggnet.report as report';

/* GGamers account details (moved here from the Connection page). */

var STATUS_TEXT = {
	active:         _('Active'),
	expired:        _('Expired'),
	quota_exceeded: _('Data quota used up'),
	disabled:       _('Disabled'),
	banned:         _('Banned')
};

function show(el, on) { el.style.display = on ? '' : 'none'; }

function kvTable(rows) {
	return E('table', { 'class': 'table' }, rows.filter(function(r) { return r; }).map(function(r) {
		return E('tr', { 'class': 'tr' }, [
			E('td', { 'class': 'td left', 'style': 'width:33%;font-weight:bold' }, [ r[0] ]),
			E('td', { 'class': 'td left' }, [ r[1] ])
		]);
	}));
}

return view.extend({
	st: null,
	sig: null,
	busy: false,

	load: function() {
		return gg.call('status');
	},

	renderInvites: function(sub) {
		var list = Array.isArray(sub.invites) ? sub.invites : [];
		return E('div', {}, [
			E('h4', {}, _('Invitation codes')),
			E('p', { 'class': 'cbi-section-descr' },
				_('Each code works once and creates a new account with free days. Share them with friends. Click a code to copy it.')),
			list.length ? E('div', { 'style': 'display:flex;flex-wrap:wrap;gap:.5em' }, list.map(function(inv) {
				if (inv.used)
					return E('div', {
						'style': 'padding:.4em .7em;border:2px dashed #8b98a8;border-radius:4px;opacity:.55;color:#8b98a8',
						'title': _('Used by %s at %s').format(String(inv.used_by || '?'), gg.formatTime(inv.used_at))
					}, [
						E('div', { 'style': 'font-family:monospace;font-size:120%;text-decoration:line-through' }, [ String(inv.code) ]),
						E('div', { 'style': 'font-size:85%' }, [ _('used by %s').format(String(inv.used_by || '?')) ])
					]);
				var note = E('div', { 'style': 'font-size:85%' }, _('available'));
				return E('div', {
					'style': 'padding:.4em .7em;border:2px solid #e3b341;border-radius:4px;cursor:pointer',
					'title': _('Copy'),
					'click': function() {
						gg.copyText(String(inv.code)).then(function(ok) {
							note.textContent = ok ? _('copied ✓') : _('available');
							window.setTimeout(function() { note.textContent = _('available'); }, 1500);
						});
					}
				}, [
					E('div', { 'style': 'font-family:monospace;font-size:120%;font-weight:bold;user-select:all;color:#e3b341' }, [ String(inv.code) ]),
					note
				]);
			})) : E('p', {}, _('No invitation codes right now.'))
		]);
	},

	update: function(st) {
		this.st = st;
		if (!st.ok) {
			this.errBox.textContent = gg.errorText(st);
			show(this.errBox, true);
			show(this.body, false);
			this.sig = null;
			return;
		}
		show(this.errBox, false);
		show(this.body, true);

		var sub = st.subscription || {};
		var sig = JSON.stringify([ st.signed_in, st.username, st.badge, st.staff, sub, new Date().toDateString() ]);
		if (sig === this.sig)
			return;
		this.sig = sig;

		if (!st.signed_in) {
			dom.content(this.body, E('div', { 'class': 'cbi-section' }, [
				E('p', {}, _('You are not signed in.')),
				E('p', {}, E('a', { 'class': 'btn cbi-button cbi-button-action', 'href': L.url('admin/services/ggnet/network') }, _('Sign in on the Connection page')))
			]));
			return;
		}

		var self = this;
		var role = sub.chat_role || (sub.active ? 'active' : 'inactive');
		var head = [ E('span', { 'style': 'color:' + gg.roleColor(role) }, [ String(st.username || sub.username || '') ]) ];
		if (gg.roleBadge(role))
			head.push(gg.badgeEl(gg.roleBadge(role), gg.roleColor(role)));
		if (st.badge && !st.staff)
			head.push(E('span', { 'style': 'margin-left:.6em;font-size:90%;font-weight:normal' }, [ String(st.badge) ]));

		var statusText = STATUS_TEXT[sub.status] || String(sub.status || '–');
		var statusColor = sub.active ? '#3fb950' : '#c33';
		var quota = Number(sub.quota_bytes) === 0 ? _('Unlimited') : gg.formatBytes(sub.quota_bytes);
		var expires = (sub.expires_at == null || Number(sub.days_left) === -1) ? _('Never') : gg.formatTime(sub.expires_at);
		var days = (sub.days_left == null || Number(sub.days_left) === -1) ? _('Never expires') : String(sub.days_left);
		var unl = function(v) { return Number(v) === 0 ? _('Unlimited') : String(v == null ? '–' : v); };

		var rows = [
			[ _('Status'), E('span', { 'style': 'font-weight:bold;color:' + statusColor }, [ statusText ]) ],
			[ _('Data used'), gg.formatBytes(sub.used_total) + ' / ' + quota ],
			[ _('Data remaining'), gg.formatBytes(sub.remaining_bytes) ],
			[ _('Days left'), days ],
			[ _('Expires'), expires ],
			[ _('Max IPs at once'), unl(sub.max_ips) ],
			[ _('Max devices'), unl(sub.max_devices) + (Number(sub.device_reset_hours) > 0 ? ' ' + _('(an unused device frees its place after %d h)').format(Number(sub.device_reset_hours)) : '') ],
			sub.online != null ? [ _('Online now'), sub.online ? _('Yes, %d connections').format(Number(sub.conns) || 0) : _('No') ] : null,
			sub.invited_by ? [ _('Invited by'), String(sub.invited_by) ] : null
		];

		var btnLogout = E('button', {
			'class': 'btn cbi-button cbi-button-negative',
			'click': function(ev) { ev.preventDefault(); self.doLogout(btnLogout); }
		}, _('Sign out'));

		var parts = [
			E('h3', {}, head),
			kvTable(rows)
		];
		/* the account's device list is intentionally not shown (checked on the website) */
		if (sub.ambassador)
			parts.push(this.renderInvites(sub));
		parts.push(E('div', { 'style': 'margin-top:1em' }, [ btnLogout ]));

		dom.content(this.body, E('div', { 'class': 'cbi-section' }, parts));
	},

	doLogout: function(btn) {
		var self = this;
		if (this.busy || !confirm(_('Sign out of GGamers on this router? The proxy stops.')))
			return;
		this.busy = true;
		btn.disabled = true;
		gg.act('logout', {}, _('Sign out')).then(function() {
			self.busy = false;
			self.sig = null;
			return self.poll();
		});
	},

	poll: function() {
		var self = this;
		return gg.call('status').then(function(st) { self.update(st); });
	},

	render: function(st) {
		report.mount();
		var self = this;
		this.errBox = E('div', { 'class': 'alert-message danger', 'style': 'display:none' });
		this.body = E('div');

		var root = E('div', {}, [
			E('h2', {}, _('GG Network — Account')),
			E('div', { 'class': 'cbi-map-descr' }, _('Your GGamers subscription. Manage devices and renewals on the GGamers website.')),
			this.errBox,
			this.body
		]);

		this.update(st);
		poll.add(function() { return self.poll(); }, 5);
		return root;
	},

	handleSave: null,
	handleSaveApply: null,
	handleReset: null
});
