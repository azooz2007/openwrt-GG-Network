'use strict';
'require view';
'require poll';
'require ui';
'require dom';
'require ggnet.common as gg';
'require ggnet.report as report';
'require ggnet.graph as graph';

var MAX_LINES = 3000;

function stat(label, valueEl) {
	return E('div', { 'style': 'flex:1 1 9em;min-width:8em;padding:.4em .6em;border:1px solid rgba(128,128,128,.3);border-radius:4px' }, [
		E('div', { 'style': 'font-size:80%;opacity:.7' }, label),
		E('div', { 'style': 'font-size:120%;font-weight:bold' }, valueEl)
	]);
}

return view.extend({
	since: 0,

	load: function() {
		return Promise.all([
			gg.call('log', { since: 0 }),
			gg.call('traffic')
		]);
	},

	buildUsage: function() {
		this.trafErr = E('div', { 'class': 'alert-message warning', 'style': 'display:none' });
		this.uSessUp = E('span', { 'style': 'color:' + graph.COLOR_UP }, '–');
		this.uSessDown = E('span', { 'style': 'color:' + graph.COLOR_DOWN }, '–');
		this.uSessTotal = E('span', {}, '–');
		this.uAcctUsed = E('span', {}, '–');
		this.uAcctLeft = E('span', {}, '–');
		this.uSince = E('div', { 'style': 'font-size:85%;opacity:.75;margin-top:.4em' });
		this.graph = graph.create({ height: 160, window: 300 });

		return E('div', { 'class': 'cbi-section' }, [
			E('h3', {}, _('Session usage')),
			this.trafErr,
			E('div', { 'style': 'display:flex;flex-wrap:wrap;gap:.5em' }, [
				stat('▲ ' + _('This session up'), this.uSessUp),
				stat('▼ ' + _('This session down'), this.uSessDown),
				stat(_('Session total'), this.uSessTotal),
				stat(_('Account used'), this.uAcctUsed),
				stat(_('Account remaining'), this.uAcctLeft)
			]),
			this.uSince,
			E('h4', { 'style': 'margin-top:.8em' }, _('Live bandwidth (last 5 minutes)')),
			this.graph.node
		]);
	},

	updateTraffic: function(res) {
		if (!res || !res.ok) {
			this.trafErr.textContent = gg.errorText(res);
			this.trafErr.style.display = '';
			this.graph.update(null);
			return;
		}
		this.trafErr.style.display = 'none';

		var s = res.session || {}, a = res.account || {};
		var up = Number(s.up) || 0, down = Number(s.down) || 0;
		this.uSessUp.textContent = gg.formatBytes(up);
		this.uSessDown.textContent = gg.formatBytes(down);
		this.uSessTotal.textContent = gg.formatBytes(up + down);

		var quota = Number(a.quota_bytes);
		this.uAcctUsed.textContent = a.used_total == null ? '–'
			: gg.formatBytes(a.used_total) + (quota > 0 ? ' / ' + gg.formatBytes(quota) : '');
		this.uAcctLeft.textContent = (quota === 0 || Number(a.remaining_bytes) === -1) ? _('Unlimited')
			: (a.remaining_bytes == null ? '–' : gg.formatBytes(a.remaining_bytes));

		this.uSince.textContent = (res.running && Number(s.since) > 0)
			? _('Since the proxy started at %s (%s ago).').format(gg.formatTime(s.since), gg.formatDuration(Date.now() / 1000 - Number(s.since)))
			: _('The proxy isn\'t running — session counters start when it does.');

		this.graph.update(res);
	},

	render: function(data) {
		report.mount();
		var self = this;
		var logData = data[0];

		this.errBox = E('div', { 'class': 'alert-message warning', 'style': 'display:none' });
		this.pre = E('pre', {
			'style': 'height:50vh;min-height:16em;overflow:auto;white-space:pre-wrap;word-break:break-all;font-size:85%;margin:0;padding:.5em;border:1px solid rgba(128,128,128,.35);border-radius:4px'
		});
		this.auto = E('input', { 'type': 'checkbox', 'id': 'ggnet-log-auto', 'checked': true });

		/* Investigation mode (GGamers 1.30): a small info line while it is on */
		var invLine = E('div', { 'class': 'alert-message info', 'style': 'display:none' }, [
			_('Investigation mode is on: GGamers is collecting problem details (incidents) to fix freezes and disconnects.')
		]);
		report.onStatus(function(st) {
			invLine.style.display = (st && st.investigation && st.investigation.enabled === true) ? '' : 'none';
		});

		var root = E('div', {}, [
			E('h2', {}, _('GG Network — Log')),
			invLine,
			this.buildUsage(),
			this.errBox,
			E('div', { 'class': 'cbi-section' }, [
				E('h3', {}, _('Log')),
				E('div', { 'style': 'margin-bottom:.5em' }, [
					E('button', {
						'class': 'btn cbi-button',
						'click': function(ev) { ev.preventDefault(); dom.content(self.pre, []); }
					}, _('Clear view')),
					' ',
					this.auto, ' ',
					E('label', { 'for': 'ggnet-log-auto' }, _('Auto-scroll'))
				]),
				this.pre
			])
		]);

		this.append(logData);
		this.updateTraffic(data[1]);
		poll.add(function() {
			return Promise.all([
				gg.call('log', { since: self.since }).then(function(res) { self.append(res); }),
				gg.call('traffic').then(function(res) { self.updateTraffic(res); })
			]);
		}, 2);

		window.requestAnimationFrame(function() { self.pre.scrollTop = self.pre.scrollHeight; });
		return root;
	},

	append: function(res) {
		if (!res.ok) {
			this.errBox.textContent = gg.errorText(res);
			this.errBox.style.display = '';
			return;
		}
		this.errBox.style.display = 'none';

		var lines = Array.isArray(res.lines) ? res.lines : [];
		var frag = document.createDocumentFragment();
		lines.forEach(function(l) {
			var d = gg.toDate(l.ts);
			var t = d ? d.toLocaleString() : '';
			frag.appendChild(document.createTextNode(t + '  ' + String(l.text == null ? '' : l.text) + '\n'));
		});
		if (lines.length)
			this.pre.appendChild(frag);

		while (this.pre.childNodes.length > MAX_LINES)
			this.pre.removeChild(this.pre.firstChild);

		if (res.next != null)
			this.since = Number(res.next) || this.since;
		else if (lines.length)
			this.since = Number(lines[lines.length - 1].n) + 1;

		if (lines.length && this.auto.checked)
			this.pre.scrollTop = this.pre.scrollHeight;
	},

	handleSave: null,
	handleSaveApply: null,
	handleReset: null
});
