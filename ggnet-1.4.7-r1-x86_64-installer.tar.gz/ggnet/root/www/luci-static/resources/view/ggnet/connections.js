'use strict';
'require view';
'require poll';
'require ui';
'require dom';
'require ggnet.common as gg';
'require ggnet.report as report';
'require ggnet.graph as graph';

/* Live connections (like the Windows app's Live tab). Data: `connections` + `traffic` RPCs. */

var STORE_DIRECT = 'ggnet.connections.direct';

var ROUTE = {
	aggressive: { text: '🔥 AGGR', title: _('Aggressive mode tunnel'), color: '#f0883e' },
	socks5:     { text: 'SOCKS5', title: _('SOCKS5 proxy'), color: '#1f6feb' },
	direct:     { text: 'DIRECT', title: _('Not through GG Network'), color: '#8b98a8' }
};

function show(el, on) { el.style.display = on ? '' : 'none'; }

function routeBadge(route) {
	var r = ROUTE[route] || { text: String(route || '?').toUpperCase(), color: '#8b98a8' };
	return E('span', {
		'title': r.title || '',
		'style': 'display:inline-block;padding:0 .4em;border-radius:3px;font-size:85%;font-weight:bold;white-space:nowrap;color:#fff;background:' + r.color
	}, [ r.text ]);
}

function hostPort(ip, port) {
	ip = String(ip || '');
	return (ip.indexOf(':') >= 0 ? '[' + ip + ']' : ip) + ':' + String(port == null ? '' : port);
}

var STORE_SORT = 'ggnet.connections.sort';

/* ---- BETA: "Program" column ----------------------------------------------------
 * Display only: names the game a connection most likely belongs to, from its port
 * (ggnet/games.json, built by tools/gamelist/build.py; icons are stored in the app
 * under ggnet/games/). It never changes how a connection is routed. */
var GAMES = null;      /* [{n, s, i, r, c}] */
var GAME_RULES = [];   /* [{u: bool (udp), lo, hi, g: index}] */

function loadGames() {
	if (GAMES)
		return Promise.resolve(GAMES);
	return fetch(L.resource('ggnet/games.json')).then(function(r) { return r.json(); }).then(function(j) {
		GAMES = (j && j.games) || [];
		GAMES.forEach(function(g, gi) {
			String(g.r || '').split(',').forEach(function(rule) {
				var m = rule.match(/^([ut])(\d+)(?:-(\d+))?$/);
				if (m)
					GAME_RULES.push({ u: m[1] === 'u', lo: +m[2], hi: m[3] ? +m[3] : +m[2], g: gi });
			});
		});
		return GAMES;
	}).catch(function() { GAMES = []; return GAMES; });
}

/* best guess for proto + port: the narrowest matching range, then the more popular game */
function gameFor(proto, port) {
	if (!GAMES || !port)
		return null;
	var udp = String(proto).toLowerCase() === 'udp';
	var hits = GAME_RULES.filter(function(r) { return r.u === udp && port >= r.lo && port <= r.hi; });
	if (!hits.length)
		return null;
	/* the more popular game first; very wide ranges (over 1000 ports) only when nothing else fits */
	hits.sort(function(a, b) { return ((a.hi - a.lo > 1000) - (b.hi - b.lo > 1000)) || a.g - b.g || (a.hi - a.lo) - (b.hi - b.lo); });
	var seen = {}, names = [];
	hits.forEach(function(h) {
		var g = GAMES[h.g], key = g.s || g.n;
		if (!seen[key]) { seen[key] = true; names.push(g.n); }
	});
	var best = GAMES[hits[0].g];
	return { game: best, others: names.slice(1), sure: names.length === 1 };
}

function programCell(cell, f) {
	var m = gameFor(f.proto, Number(f.dst_port));
	if (!m) {
		cell.textContent = '–';
		cell.title = '';
		return '';
	}
	var g = m.game, kids = [];
	if (g.i)
		kids.push(E('img', { 'src': L.resource('ggnet/games/' + g.i + '.png'), 'width': '16', 'height': '16', 'alt': '',
			'style': 'vertical-align:middle;margin-right:.3em;image-rendering:pixelated' }));
	kids.push(String(g.s || g.n) + (m.sure ? '' : ' ?'));
	dom.content(cell, kids);
	cell.title = g.n + ' · ' + String(f.proto).toUpperCase() + ' ' + f.dst_port +
		(m.others.length ? '\n' + _('Also used by: %s').format(m.others.slice(0, 6).join(', ')) : '') +
		'\n' + _('Guessed from the port (beta).');
	return String(g.s || g.n).toLowerCase();
}

/* sortable columns: key → value of a flow (numbers sort as numbers, text as text) */
var SORT_BY = {
	device:  function(f) { return String(f.device || f.src || '').toLowerCase(); },
	program: function(f) { var m = gameFor(f.proto, Number(f.dst_port)); return m ? String(m.game.s || m.game.n).toLowerCase() : '\uffff'; },
	proto:   function(f) { return String(f.proto || ''); },
	dst:     function(f) { return ipKey(f.dst_ip) * 65536 + (Number(f.dst_port) || 0); },
	route:   function(f) { return String(f.route || ''); },
	packets: function(f) { return (Number(f.pkts_up) || 0) + (Number(f.pkts_down) || 0); },
	up:      function(f) { return Number(f.up) || 0; },
	down:    function(f) { return Number(f.down) || 0; },
	started: function(f) { return Number(f.since) || 0; },
	dur:     function(f) { return -(Number(f.since) || 0); }   /* longest first = oldest start */
};

function ipKey(ip) {
	var m = String(ip || '').match(/^(\d+)\.(\d+)\.(\d+)\.(\d+)$/);
	return m ? ((+m[1] * 256 + +m[2]) * 256 + +m[3]) * 256 + +m[4] : 0;
}

function sortFlows(list, key, desc) {
	var get = SORT_BY[key] || SORT_BY.down;
	return list.slice().sort(function(a, b) {
		var x = get(a), y = get(b), d = 0;
		if (x < y) d = -1;
		else if (x > y) d = 1;
		if (desc) d = -d;
		if (d) return d;
		d = (Number(a.since) || 0) - (Number(b.since) || 0);   /* then oldest first, then id: stable */
		if (d) return d;
		return String(a.id) < String(b.id) ? -1 : (String(a.id) > String(b.id) ? 1 : 0);
	});
}

/* the connection's start time: "21:04:13", with the date when it isn't today */
function startedText(since) {
	var d = new Date(Number(since) * 1000);
	if (!since || isNaN(d.getTime())) return '–';
	var t = d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
	return d.toDateString() === new Date().toDateString() ? t : d.toLocaleDateString() + ' ' + t;
}

return view.extend({
	rows: null,          /* id → row record */
	direct: false,

	load: function() {
		this.direct = gg.storeGet(STORE_DIRECT, '0') === '1';
		return Promise.all([
			gg.call('connections', { direct: this.direct }),
			gg.call('traffic')
		]);
	},

	setMsg: function(text, severity) {
		this.msg.className = 'alert-message ' + (severity || 'info');
		this.msg.textContent = text || '';
		show(this.msg, !!text);
		window.clearTimeout(this.msgTimer);
		if (text && severity !== 'danger') {
			var self = this;
			this.msgTimer = window.setTimeout(function() { show(self.msg, false); }, 4000);
		}
	},

	copy: function(text) {
		var self = this;
		gg.copyText(text).then(function(ok) {
			if (ok)
				self.setMsg(_('Copied %s').format(text), 'success');
			else
				self.setMsg(_('Couldn\'t copy. Select it by hand: %s').format(text), 'warning');
		});
	},

	buildCombo: function(f) {
		var port = String(f.proto).toLowerCase() === 'udp' ? 0 : (Number(f.dst_port) || 0);
		window.location.href = L.url('admin/services/ggnet/combos') + '#game=' + String(f.dst_ip || '') + ':' + port;
	},

	terminate: function(rec) {
		var self = this;
		var f = rec.flow;
		if (!confirm(_('Terminate this connection to %s?').format(hostPort(f.dst_ip, f.dst_port))))
			return;
		rec.btnKill.disabled = true;
		gg.call('conn_close', { id: String(f.id) }).then(function(res) {
			rec.btnKill.disabled = false;
			if (res.ok) {
				self.setMsg(_('Connection terminated.'), 'success');
				self.refresh();
			}
			else {
				self.setMsg(_('Terminate') + ': ' + gg.errorText(res), 'danger');
			}
		});
	},

	makeRow: function(f) {
		var self = this;
		var rec = { flow: f, routeKey: null };
		var td = function(style) { return E('td', { 'class': 'td', 'style': style || '' }); };

		rec.cDevice = td('max-width:9em;overflow:hidden;text-overflow:ellipsis;white-space:nowrap');
		rec.cProto = td('text-transform:uppercase');
		rec.cDst = td('font-family:monospace;white-space:nowrap');
		rec.cProg = td('max-width:8em;overflow:hidden;text-overflow:ellipsis;white-space:nowrap');
		rec.cRoute = td();
		rec.cPkts = td('text-align:right;white-space:nowrap');
		rec.cUp = td('text-align:right;white-space:nowrap');
		rec.cDown = td('text-align:right;white-space:nowrap');
		rec.cDur = td('white-space:nowrap');
		rec.cStart = td('white-space:nowrap');

		/* small icon buttons (the full text is the tooltip) so the whole row fits without scrolling */
		var btn = function(text, title, fn, cls) {
			return E('button', {
				'class': 'btn cbi-button ' + (cls || ''),
				'style': 'padding:0 .35em;margin:0 1px;min-width:0;line-height:1.5',
				'title': title,
				'aria-label': title,
				'click': function(ev) { ev.preventDefault(); fn(); }
			}, text);
		};
		rec.btnKill = btn('✕', _('Terminate: close this tunneled connection'), function() { self.terminate(rec); }, 'cbi-button-negative');
		rec.cAct = E('td', { 'class': 'td', 'style': 'white-space:nowrap' }, [
			btn('IP', _('Copy the IP address'), function() { self.copy(String(rec.flow.dst_ip || '')); }),
			btn('IP:P', _('Copy IP and port'), function() { self.copy(hostPort(rec.flow.dst_ip, rec.flow.dst_port)); }),
			btn('⛓', _('Build a connection combo for this game server'), function() { self.buildCombo(rec.flow); }, 'cbi-button-action'),
			rec.btnKill
		]);

		rec.tr = E('tr', { 'class': 'tr' }, [
			rec.cDevice, rec.cProto, rec.cDst, rec.cProg, rec.cRoute, rec.cPkts, rec.cUp, rec.cDown, rec.cStart, rec.cDur, rec.cAct
		]);
		return rec;
	},

	updateRow: function(rec, f, now) {
		rec.flow = f;
		var isDirect = f.route === 'direct' || /^d/.test(String(f.id));
		var srcIp = String(f.src || '').replace(/:\d+$/, '');

		rec.cDevice.textContent = f.device ? String(f.device) : (srcIp || '?');
		rec.cDevice.title = f.src ? String(f.src) : '';
		rec.cProto.textContent = String(f.proto || '');
		rec.cDst.textContent = hostPort(f.dst_ip, f.dst_port);
		var pk = f.proto + '/' + f.dst_port + '/' + (GAMES ? 1 : 0);
		if (rec.progKey !== pk) {
			rec.progKey = pk;
			programCell(rec.cProg, f);
		}

		if (rec.routeKey !== f.route) {
			rec.routeKey = f.route;
			dom.content(rec.cRoute, routeBadge(f.route));
		}

		var pu = Number(f.pkts_up) || 0, pd = Number(f.pkts_down) || 0;
		var noAcct = isDirect && !pu && !pd && !Number(f.up) && !Number(f.down);
		rec.cPkts.textContent = noAcct ? '–' : gg.formatNum(pu + pd);
		rec.cPkts.title = noAcct ? _('No accounting for direct flows (conntrack accounting is off)') : _('↑ %s  ↓ %s').format(gg.formatNum(pu), gg.formatNum(pd));
		rec.cUp.textContent = noAcct ? '–' : gg.formatBytes(f.up || 0);
		rec.cDown.textContent = noAcct ? '–' : gg.formatBytes(f.down || 0);
		rec.cDur.textContent = Number(f.since) > 0 ? gg.formatDuration(now - Number(f.since)) : '–';
		if (rec.startKey !== f.since) {
			rec.startKey = f.since;
			rec.cStart.textContent = startedText(f.since);
			rec.cStart.title = Number(f.since) > 0 ? new Date(Number(f.since) * 1000).toString() : '';
		}
		rec.btnKill.style.display = isDirect ? 'none' : '';
	},

	paintSortHeads: function() {
		for (var k in this.sortHeads)
			this.sortHeads[k].textContent = k === this.sortKey ? (this.sortDesc ? '▼' : '▲') : '';
	},

	updateConnections: function(res) {
		this.lastRes = res;
		if (!res || !res.ok) {
			this.err.textContent = gg.errorText(res);
			show(this.err, true);
			return;
		}
		show(this.err, false);

		var sum = res.summary || {};
		var flows = Array.isArray(res.flows) ? res.flows : [];
		var parts = [
			_('%d flows (%d tunneled)').format(Number(sum.flows != null ? sum.flows : flows.length) || 0, Number(sum.tunneled) || 0),
			_('proxy ping %s').format(gg.formatMs(sum.proxy_ping_ms)),
			_('↑ %s  ↓ %s').format(gg.formatBytes(sum.bytes_up || 0), gg.formatBytes(sum.bytes_down || 0))
		];
		this.summary.textContent = parts.join('  ·  ');
		show(this.notRunning, res.running === false);

		var now = Date.now() / 1000;
		var seen = {};
		var self = this;
		sortFlows(flows, this.sortKey, this.sortDesc).forEach(function(f) {
			var id = String(f.id);
			seen[id] = true;
			var rec = self.rows[id];
			if (!rec)
				rec = self.rows[id] = self.makeRow(f);
			self.updateRow(rec, f, now);
			self.tbody.appendChild(rec.tr);   /* (re)orders without rebuilding */
		});
		Object.keys(this.rows).forEach(function(id) {
			if (!seen[id]) {
				var tr = self.rows[id].tr;
				if (tr.parentNode)
					tr.parentNode.removeChild(tr);
				delete self.rows[id];
			}
		});
		show(this.emptyRow, !flows.length);
		this.emptyCell.textContent = res.running === false && !this.direct
			? _('The proxy isn\'t running.')
			: _('No connections right now.');
	},

	refresh: function() {
		var self = this;
		return Promise.all([
			gg.call('connections', { direct: this.direct }).then(function(res) { self.updateConnections(res); }),
			gg.call('traffic').then(function(res) { self.graph.update(res && res.ok ? res : null); })
		]);
	},

	render: function(data) {
		report.mount();
		var self = this;
		this.rows = {};
		loadGames().then(function() { if (self.lastRes) self.updateConnections(self.lastRes); });

		this.err = E('div', { 'class': 'alert-message warning', 'style': 'display:none' });
		this.msg = E('div', { 'class': 'alert-message', 'style': 'display:none' });
		this.notRunning = E('div', { 'class': 'alert-message info', 'style': 'display:none' },
			_('The proxy isn\'t running. Start it on the "Connection" page.'));
		this.summary = E('div', { 'style': 'font-weight:bold;margin:.3em 0 .6em' }, '–');
		this.graph = graph.create({ height: 130, window: 300 });

		var cbDirect = E('input', {
			'type': 'checkbox',
			'id': 'ggnet-conn-direct',
			'change': function() {
				self.direct = !!this.checked;
				gg.storeSet(STORE_DIRECT, self.direct ? '1' : '0');
				self.refresh();
			}
		});
		cbDirect.checked = this.direct;

		/* click a title to sort by it, click again to reverse; remembered in this browser */
		var saved = String(gg.storeGet(STORE_SORT, 'down:1')).split(':');
		this.sortKey = SORT_BY[saved[0]] ? saved[0] : 'down';
		this.sortDesc = saved[1] !== '0';
		this.sortHeads = {};
		var th = function(text, key, right) {
			if (!key)
				return E('th', { 'class': 'th', 'style': right ? 'text-align:right' : '' }, text);
			var arrow = E('span', { 'style': 'margin-left:.25em;opacity:.8' });
			var h = E('th', {
				'class': 'th', 'style': 'cursor:pointer;user-select:none;white-space:nowrap' + (right ? ';text-align:right' : ''),
				'title': _('Sort by this column'),
				'click': function() {
					if (self.sortKey === key)
						self.sortDesc = !self.sortDesc;
					else {
						self.sortKey = key;
						/* numbers and times: biggest / newest first; text: A → Z */
						self.sortDesc = [ 'packets', 'up', 'down', 'started', 'dur' ].indexOf(key) >= 0;
					}
					gg.storeSet(STORE_SORT, self.sortKey + ':' + (self.sortDesc ? '1' : '0'));
					self.paintSortHeads();
					if (self.lastRes)
						self.updateConnections(self.lastRes);
				}
			}, [ text, arrow ]);
			self.sortHeads[key] = arrow;
			return h;
		};
		this.emptyCell = E('td', { 'class': 'td', 'colspan': '11', 'style': 'text-align:center;opacity:.65' }, _('No connections right now.'));
		this.emptyRow = E('tr', { 'class': 'tr' }, [ this.emptyCell ]);
		this.tbody = E('tbody');
		/* compact: smaller text and padding so all columns fit; scrolls only on a narrow screen */
		if (!document.getElementById('gg-conn-style'))
			document.head.appendChild(E('style', { 'id': 'gg-conn-style', 'type': 'text/css' }, [
				'.gg-conn{font-size:90%}' +
				'.gg-conn .th,.gg-conn .td{padding:.25em .4em !important}' +
				'.gg-conn-wrap{overflow-x:auto}'
			]));
		var table = E('table', { 'class': 'table cbi-section-table gg-conn' }, [
			E('thead', {}, E('tr', { 'class': 'tr table-titles' }, [
				th(_('Device'), 'device'), th(_('Proto'), 'proto'), th(_('Destination'), 'dst'), th(_('Program'), 'program'), th(_('Route'), 'route'),
				th(_('Pkts'), 'packets', true), th('↑', 'up', true), th('↓', 'down', true),
				th(_('Started'), 'started'), th(_('Time'), 'dur'), th('')
			])),
			E('tbody', {}, this.emptyRow),
			this.tbody
		]);

		this.paintSortHeads();

		var root = E('div', {}, [
			E('h2', {}, _('GG Network — Connections')),
			E('div', { 'class': 'cbi-map-descr' }, _('Live connections of the selected LAN devices and the way each one goes.')),
			this.err,
			this.notRunning,
			E('div', { 'class': 'cbi-section' }, [
				this.summary,
				this.graph.node
			]),
			E('div', { 'class': 'cbi-section' }, [
				E('div', { 'style': 'margin-bottom:.5em' }, [
					cbDirect, ' ',
					E('label', { 'for': 'ggnet-conn-direct' }, _('Show direct connections')),
					E('span', { 'class': 'cbi-value-description', 'style': 'margin-left:.8em' },
						_('(bypassed traffic such as web and LAN; read from conntrack)'))
				]),
				this.msg,
				E('div', { 'style': 'overflow-x:auto' }, table)
			])
		]);

		this.updateConnections(data[0]);
		this.graph.update(data[1] && data[1].ok ? data[1] : null);

		poll.add(function() { return self.refresh(); }, 2);
		return root;
	},

	handleSave: null,
	handleSaveApply: null,
	handleReset: null
});
