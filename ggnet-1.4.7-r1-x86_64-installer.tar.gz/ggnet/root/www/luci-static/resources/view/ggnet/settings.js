'use strict';
'require view';
'require form';
'require uci';
'require ui';
'require tools.widgets as widgets';
'require ggnet.common as gg';
'require ggnet.report as report';

/* device list entry: MAC, IPv4, IPv4 CIDR or a DHCP host name */
var RE_MAC = /^[0-9a-f]{2}([:-])[0-9a-f]{2}(\1[0-9a-f]{2}){4}$/i;
var RE_IP4 = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/;
var RE_NAME = /^[A-Za-z0-9_][A-Za-z0-9_.-]{0,62}$/;

function isIPv4(v) {
	var m = RE_IP4.exec(v);
	return !!m && m.slice(1).every(function(x) { return Number(x) <= 255; });
}

function deviceEntryValid(v) {
	v = String(v == null ? '' : v).trim();
	if (!v)
		return true;
	if (RE_MAC.test(v))
		return true;
	if (v.indexOf('/') >= 0) {
		var p = v.split('/');
		return p.length === 2 && isIPv4(p[0]) && /^\d{1,2}$/.test(p[1]) && Number(p[1]) <= 32;
	}
	if (/^[\d.]+$/.test(v))
		return isIPv4(v);          /* digits and dots only: must be a real IPv4 */
	return RE_NAME.test(v);
}

function uniq(list) {
	var seen = {}, out = [];
	list.forEach(function(v) {
		v = String(v == null ? '' : v).trim();
		var k = v.toLowerCase();
		if (v !== '' && !seen[k]) { seen[k] = true; out.push(v); }
	});
	return out;
}

return view.extend({
	load: function() {
		return Promise.all([
			gg.call('devices'),
			gg.call('settings_get'),
			uci.load('ggnet')
		]);
	},

	render: function(data) {
		report.mount();
		var devRes = data[0] || {}, setRes = data[1] || {};
		var m, s, o;

		m = new form.Map('ggnet', _('GG Network — Settings'),
			_('Router settings for the GG Network proxy. "Save & Apply" reloads the ggnet service.'));

		/* ------------------------------------------------------------ */
		s = m.section(form.NamedSection, 'main', 'ggnet', _('LAN devices'),
			_('Choose which devices on your network use GG Network.'));
		s.addremove = false;

		o = s.option(widgets.DeviceSelect, 'lan_ifaces', _('LAN interfaces'),
			_('Traffic from these network devices goes through GG Network.'));
		o.multiple = true;
		o.noaliases = true;
		o.nobridges = false;
		o.default = 'br-lan';
		o.rmempty = false;

		o = s.option(form.ListValue, 'device_mode', _('Which devices'));
		o.value('all', _('All LAN devices'));
		o.value('include', _('Only the devices below'));
		o.value('exclude', _('All except the devices below'));
		o.default = 'all';
		/* "Only the devices below" needs at least one device */
		o.validate = function(section_id, value) {
			if (value !== 'include')
				return true;
			var list = this.section.children.filter(function(c) { return c.option === 'device'; })[0];
			var v = list ? L.toArray(list.formvalue(section_id)) : [];
			return v.length ? true : _('Choose which devices use GG Network: pick a device from the list, or type its name, MAC address or IP address (Settings → Devices).');
		};

		o = s.option(form.DynamicList, 'device', _('Devices'),
			_('Pick a device from the list or type one of: a MAC address (aa:bb:cc:dd:ee:ff), an IPv4 address (192.168.1.20), a range in CIDR form (192.168.1.0/28) or a device name as shown in the DHCP leases (Ali-PC). Names are looked up while the proxy runs.'));
		o.depends('device_mode', 'include');
		o.depends('device_mode', 'exclude');
		o.retain = true;      /* keep the list when "All LAN devices" is chosen */
		o.validate = function(section_id, value) {
			return deviceEntryValid(value) ? true : _('Use a MAC address, an IPv4 address, a CIDR range or a device name.');
		};
		if (devRes.ok && Array.isArray(devRes.devices)) {
			devRes.devices.forEach(function(d) {
				var val = d.mac || d.ip;
				if (!val)
					return;
				var parts = [ d.name ? String(d.name) : _('(no name)') ];
				if (d.ip) parts.push(String(d.ip));
				if (d.mac) parts.push(String(d.mac));
				o.value(String(val), E('span', {}, [ parts.join(' — ') + ' (' + (d.online ? _('online') : _('offline')) + ')' ]));
			});
		}
		/* show legacy device_mac entries in the list too … */
		o.load = function(section_id) {
			var list = uniq(L.toArray(uci.get('ggnet', section_id, 'device'))
				.concat(L.toArray(uci.get('ggnet', section_id, 'device_mac'))));
			return list.length ? list : null;
		};
		/* … and move them to "device" on save */
		o.parse = function(section_id) {
			var self = this;
			return Promise.resolve(form.DynamicList.prototype.parse.call(this, section_id)).then(function() {
				if (uci.get('ggnet', section_id, 'device_mac') == null)
					return;
				var list = self.isActive(section_id) ? L.toArray(self.formvalue(section_id)) : L.toArray(self.load(section_id));
				list = uniq(list);
				if (list.length)
					uci.set('ggnet', section_id, 'device', list);
				else
					uci.unset('ggnet', section_id, 'device');
				uci.unset('ggnet', section_id, 'device_mac');
			});
		};

		if (!devRes.ok) {
			o = s.option(form.DummyValue, '_devices_err', ' ');
			o.cfgvalue = function() { return _('Couldn\'t load the device list: %s').format(gg.errorText(devRes)); };
			o.write = o.remove = function() {};
		}

		/* ------------------------------------------------------------ */
		s = m.section(form.NamedSection, 'main', 'ggnet', _('Protocol & bypass'),
			_('The same options as "⚙ Protocol & options" on the main page. "3× UDP redundancy" is only there because it lasts for the current session.'));
		s.addremove = false;

		o = s.option(form.ListValue, 'udp_mode', _('Protocol'));
		o.value('udp', _('Enable UDP relay (games)'));
		o.value('tcp_only', _('TCP only'));
		o.default = 'udp';
		o.widget = 'radio';
		o.orientation = 'vertical';

		o = s.option(form.Flag, 'block_udp', _('Block UDP while TCP-only'),
			_('Drops the selected devices\' internet UDP so games fall back to TCP.'));
		o.depends('udp_mode', 'tcp_only');
		o.rmempty = false;
		o.default = '0';

		o = s.option(form.Flag, 'bypass_web', _('Bypass web (HTTP/HTTPS/QUIC)'),
			_('Web traffic (TCP 80/443, UDP 443) goes direct — saves your data quota.'));
		o.rmempty = false;
		o.default = '1';

		o = s.option(form.Flag, 'bypass_voice', _('Bypass voice chat & remote tools'),
			_('Discord, TeamSpeak, Mumble, voice and video calls (WhatsApp, Teams, Zoom, Meet), ZeroTier, Tailscale, WireGuard, AnyDesk, TeamViewer and Parsec go direct, so they don\'t use GG Network\'s bandwidth. A router can\'t see which program sends, so they are recognised by their ports. Games that use Google\'s STUN port (19302) to find their NAT type then see your home connection.'));
		o.rmempty = false;
		o.default = '1';

		o = s.option(form.Flag, 'bypass_local', _('Bypass local / LAN'),
			_('Private and reserved address ranges are never tunneled.'));
		o.rmempty = false;
		o.default = '1';

		o = s.option(form.Flag, 'block_ipv6', _('Block IPv6 for tunneled devices'),
			_('Recommended. GG Network carries IPv4, so internet IPv6 from these devices is refused and apps use IPv4, which goes through GG Network. LAN IPv6 keeps working.'));
		o.rmempty = false;
		o.default = '1';

		o = s.option(form.Flag, 'tunnel_dns', _('Tunnel DNS (UDP/53)'),
			_('The devices\' DNS queries (also those sent to the router) go through GG Network to the DNS server below.'));
		o.rmempty = false;
		o.default = '0';

		o = s.option(form.Value, 'dns_server', _('DNS server'));
		o.datatype = 'ip4addr("nomask")';
		o.placeholder = '1.1.1.1';
		o.default = '1.1.1.1';
		o.depends('tunnel_dns', '1');

		/* ------------------------------------------------------------ */
		var presetOn = !!(setRes.ok && setRes.preset_applied);
		s = m.section(form.NamedSection, 'main', 'ggnet', _('Enhancements (router tuning)'),
			_('Low-latency tweaks the router applies to the connections GG Network makes to the servers. Nothing changes on your PC or console.'));
		s.addremove = false;

		o = s.option(form.Button, '_preset', _('Gaming preset'),
			presetOn ? _('The recommended preset is applied.')
				: _('Turns on QoS, quick ACK, keepalive (30 s), high priority and large buffers, and turns TCP Fast Open off. Unsaved changes on this page are lost.'));
		o.inputtitle = presetOn ? '🎮 ' + _('Gaming preset applied ✓') : '🎮 ' + _('Apply recommended gaming preset');
		o.inputstyle = 'action';
		o.readonly = presetOn;
		o.onclick = function(ev) {
			var btn = ev && ev.currentTarget;
			if (btn) btn.disabled = true;
			return gg.call('preset_apply').then(function(res) {
				if (!res.ok) {
					if (btn) btn.disabled = false;
					ui.addNotification(null, E('p', {}, [ _('Gaming preset') + ': ' + gg.errorText(res) ]), 'danger');
					return;
				}
				window.location.reload();
			});
		};
		o.write = o.remove = function() {};

		o = s.option(form.Flag, 'opt_qos', _('QoS low latency'),
			_('Marks upstream packets DSCP EF (expedited forwarding), so QoS-aware routers and ISPs treat them as real-time traffic.'));
		o.rmempty = false;
		o.default = '0';

		o = s.option(form.Flag, 'opt_quickack', _('TCP quick ACK'),
			_('Acknowledges TCP data at once on the upstream sockets (like Windows "TCP ACK frequency = 1"); lowers delay for TCP games.'));
		o.rmempty = false;
		o.default = '0';

		o = s.option(form.Flag, 'opt_keepalive', _('TCP keepalive'),
			_('Sends keepalive probes on idle upstream connections so NATs and firewalls don\'t drop them.'));
		o.rmempty = false;
		o.default = '0';

		o = s.option(form.Value, 'keepalive_idle', _('Keepalive after (seconds)'),
			_('Idle time before the first keepalive probe.'));
		o.datatype = 'range(5,7200)';
		o.placeholder = '30';
		o.default = '30';
		o.depends('opt_keepalive', '1');

		o = s.option(form.Flag, 'opt_fastfail', _('Fast fail'),
			_('Dead upstream connections are reset after about 8 s (TCP_USER_TIMEOUT) instead of minutes, so games reconnect sooner.'));
		o.rmempty = false;
		o.default = '0';

		o = s.option(form.Flag, 'opt_fastopen', _('TCP Fast Open (experimental)'),
			_('Sends data in the first packet when connecting to the server, saving one round trip. Some networks break it — turn it off if connecting fails.'));
		o.rmempty = false;
		o.default = '0';

		o = s.option(form.Flag, 'opt_priority', _('High CPU priority'),
			_('Runs ggnetd at high CPU priority (like Windows "realtime priority"). Changing it restarts the service.'));
		o.rmempty = false;
		o.default = '0';

		o = s.option(form.Flag, 'opt_buffers', _('Large socket buffers'),
			_('Uses large socket buffers and raises the router\'s net.core.rmem_max / wmem_max; helps with bursts of game traffic.'));
		o.rmempty = false;
		o.default = '0';

		o = s.option(form.Flag, 'opt_nodelay', _('TCP no delay'),
			_('Sends small game packets at once (TCP_NODELAY) on the connections to the server and to the device.'));
		o.rmempty = false;
		o.default = '1';

		o = s.option(form.Flag, 'opt_rescue', _('UDP silence rescue'),
			_('Re-opens a UDP relay that was answering and went quiet for 10 s while the game keeps sending (at most 3 times per game connection).'));
		o.rmempty = false;
		o.default = '1';

		o = s.option(form.Flag, 'opt_dontfrag', _('UDP don\'t fragment'),
			_('Sends UDP to the servers with the "don\'t fragment" bit, so oversized packets fail fast instead of being split on the way.'));
		o.rmempty = false;
		o.default = '0';

		/* §14: GGamers can force a switch on or off; the player's own choice stays saved and comes back
		 * when it is the player's choice again. */
		var locks = (setRes.ok && setRes.tuning_locks) || {};
		Object.keys(locks).forEach(function(opt) {
			var l = locks[opt] || {}, lo = s.children.filter(function(c) { return c.option === opt; })[0];
			if (!lo)
				return;
			var on = l.state === 'forced';
			lo.readonly = true;
			lo.cfgvalue = function() { return on ? '1' : '0'; };
			lo.write = lo.remove = function() {};
			lo.description = (on ? '🔒 ' : '⛔ ') + String(l.note || (on ? _('Enabled by developer') : _('Disabled by developer'))) +
				(lo.description ? ' — ' + lo.description : '');
		});

		/* ------------------------------------------------------------ */
		s = m.section(form.NamedSection, 'main', 'ggnet', _('General'));
		s.addremove = false;

		o = s.option(form.Flag, 'autostart', _('Start at boot'),
			_('Start the proxy at boot when signed in'));
		o.rmempty = false;
		o.default = '0';

		o = s.option(form.Flag, 'idle_stop', _('Auto-stop when idle'),
			_('Stop the proxy by itself when nothing has gone through GG Network for a while (no data and no open connection). Saves data and avoids staying connected for nothing. Turn off to keep it running all the time.'));
		o.rmempty = false;
		o.default = '1';

		o = s.option(form.Value, 'idle_minutes', _('Idle time before stopping'),
			_('Minutes without traffic (5 to 1440).'));
		o.datatype = 'range(5,1440)';
		o.default = '60';
		o.placeholder = '60';
		o.depends('idle_stop', '1');

		o = s.option(form.Value, 'server_url', _('GGamers address'),
			_('Leave empty for the built-in address.'));
		o.placeholder = 'https://login.ggamers.net';
		o.datatype = 'string';
		o.validate = function(section_id, value) {
			if (!value)
				return true;
			return /^https:\/\/[^\s\/]+(\/\S*)?$/.test(value) ? true : _('Use an https:// address.');
		};

		/* ------------------------------------------------------------ */
		s = m.section(form.NamedSection, 'main', 'ggnet', _('Updates'),
			_('New versions come from the GitHub releases of GG Network. The package for this router\'s CPU and package manager (.ipk or .apk) is picked by itself.'));
		s.addremove = false;

		o = s.option(form.Flag, 'update_check', _('Check for updates'),
			_('Look for a new release every 6 hours and show it on the Connection page.'));
		o.rmempty = false;
		o.default = '1';

		o = s.option(form.Flag, 'auto_update', _('Install updates automatically'),
			_('Installs a new release by itself, only while no game uses GG Network (the proxy is stopped, or nothing went through it for 10 minutes). The proxy reconnects after the update.'));
		o.rmempty = false;
		o.default = '1';
		o.depends('update_check', '1');

		o = s.option(form.Flag, 'update_beta', _('Include pre-releases'),
			_('Also offer test versions.'));
		o.rmempty = false;
		o.default = '0';
		o.depends('update_check', '1');

		s = m.section(form.NamedSection, 'main', 'ggnet', _('Advanced'));
		s.addremove = false;

		o = s.option(form.Value, 'tproxy_port', _('Transparent proxy port'),
			_('Local port used to catch LAN traffic. Change it only if another service uses it.'));
		o.datatype = 'port';
		o.default = '7893';
		o.placeholder = '7893';

		return m.render();
	}
});
