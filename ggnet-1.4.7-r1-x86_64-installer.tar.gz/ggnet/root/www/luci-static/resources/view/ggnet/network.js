'use strict';
'require view';
'require poll';
'require ui';
'require dom';
'require ggnet.common as gg';
'require ggnet.report as report';
'require ggnet.chat as chatmod';
'require ggnet.route as routemod';

var AGGR_OPTS = [
	[ 'udp',       _('UDP games') ],
	[ 'tcp',       _('TCP games') ],
	[ 'duplicate', _('Copies on my route') ],
	[ 'shortcut',  _('Backup copy skips middle nodes') ]
];

var STATUS_TEXT = {
	active:         _('Active'),
	expired:        _('Expired'),
	quota_exceeded: _('Data quota used up'),
	disabled:       _('Disabled'),
	banned:         _('Banned')
};

/* left-aligned form row for the connection card: small bold label on top,
 * content right under it (no right-aligned label column). label '' = none. */
function frow(label, widget) {
	var kids = [];
	if (label)
		kids.push(E('div', { 'class': 'gg-frow-label' }, [ label ]));
	kids.push(E('div', { 'class': 'gg-frow-field' }, Array.isArray(widget) ? widget : [ widget ]));
	return E('div', { 'class': 'gg-frow' }, kids);
}

var layoutStyleDone = false;
function injectLayoutStyle() {
	if (layoutStyleDone || !document.head)
		return;
	layoutStyleDone = true;
	document.head.appendChild(E('style', { 'type': 'text/css' }, [
		/* two equal frames side by side: Connection | Live chat */
		'.gg-frames{display:flex;flex-direction:row;gap:1.2em;align-items:stretch;margin:0 0 1em}' +
		'.gg-frames>.gg-frame{flex:1 1 0;min-width:0;box-sizing:border-box;margin:0 !important;' +
			'padding:1em 1.2em !important;border:1px solid rgba(128,128,128,.35);border-radius:8px;' +
			'display:flex;flex-direction:column}' +
		'.gg-frame>h3,.gg-frame>.ggnet-chat>h3{margin:0 0 .7em !important;padding:0 0 .35em !important;' +
			'border-bottom:1px solid rgba(128,128,128,.3);font-size:1.15em;text-align:left}' +
		'.gg-frame h4{text-align:left}' +
		'@media (max-width:900px){.gg-frames{flex-direction:column}.gg-frames>.gg-frame{flex:none;width:100%}}' +
		/* left-aligned rows */
		'.gg-frow{display:block;text-align:left;margin:0 0 .85em;padding:0}' +
		'.gg-frow-label{font-weight:bold;font-size:90%;opacity:.85;margin:0 0 .3em;text-align:left}' +
		'.gg-frow-field{text-align:left;min-width:0}' +
		'.gg-sel-row{display:flex;flex-wrap:wrap;align-items:center;gap:.35em .5em;margin-top:.45em;' +
			'padding:.35em .6em;border:1px solid rgba(128,128,128,.3);border-radius:6px;max-width:100%;box-sizing:border-box}' +
		'.gg-sel-name{font-weight:bold;overflow:hidden;text-overflow:ellipsis;min-width:0}' +
		'.gg-lock-hint{font-size:85%;opacity:.75;margin-top:.35em}'
	]));
}

function kvTable(rows) {
	return E('table', { 'class': 'table' }, rows.filter(function(r) { return r; }).map(function(r) {
		return E('tr', { 'class': 'tr' }, [
			E('td', { 'class': 'td left', 'style': 'width:33%;font-weight:bold' }, [ r[0] ]),
			E('td', { 'class': 'td left' }, [ r[1] ])
		]);
	}));
}

/* a combo's total like the panel and the Windows client: "74 ms in game" (your ping +
 * links + last node → game server) or "52 ms leave with" (no game server); ≈ = not every
 * part is measured yet */
function comboBadge(t) {
	t = t || {};
	var kids = [ gg.pingBadge(t.ping_ms == null ? null : Number(t.ping_ms)) ];
	if (t.ping_ms != null && Number(t.ping_ms) > 0 && t.approx)
		kids.unshift(E('span', { 'style': 'opacity:.75;margin-right:.15em' }, [ '≈' ]));
	kids.push(E('span', { 'style': 'font-size:80%;opacity:.75;margin-left:.3em' },
		[ t.kind === 'game' ? _('in game') : _('leave with') ]));
	return E('span', { 'style': 'white-space:nowrap' }, kids);
}

function show(el, on) { el.style.display = on ? '' : 'none'; }

function yesno(v) { return v ? '✔' : '✘'; }

function isIPv4(v) {
	var m = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(String(v || ''));
	return !!m && m.slice(1).every(function(x) { return Number(x) <= 255; });
}

/* inline message element helpers */
function setMsg(el, text, severity) {
	el.className = 'alert-message ' + (severity || 'warning');
	el.textContent = text || '';
	show(el, !!text);
}

return view.extend({
	st: null,
	combos: [],
	settings: null,         /* settings_get.settings */
	presetApplied: false,
	presetBusy: false,
	chat: null,
	captcha: null,          /* {id, image, expires} */
	captchaLoading: false,
	lockUntil: 0,           /* ms */
	loginBusy: false,
	selectBusy: false,
	aggrBusy: false,
	acctSig: null,
	aggrSig: null,
	targetSig: null,

	load: function() {
		return Promise.all([
			gg.call('status'),
			gg.call('combos'),
			gg.call('settings_get')
		]);
	},

	/* ---------------------------------------------------------------- */
	/* Signed out                                                       */
	/* ---------------------------------------------------------------- */

	buildLogin: function() {
		var self = this;

		this.inUser = E('input', { 'type': 'text', 'id': 'ggnet-user', 'class': 'cbi-input-text', 'autocomplete': 'username', 'autocapitalize': 'off', 'spellcheck': 'false', 'style': 'flex:1 1 12em;min-width:0;width:auto' });
		this.inPass = E('input', { 'type': 'password', 'id': 'ggnet-pass', 'class': 'cbi-input-password', 'autocomplete': 'current-password', 'style': 'width:100%;box-sizing:border-box' });
		this.inRemember = E('input', { 'type': 'checkbox', 'id': 'ggnet-remember' });
		this.inCaptcha = E('input', { 'type': 'text', 'class': 'cbi-input-text', 'autocomplete': 'off', 'autocapitalize': 'off', 'spellcheck': 'false', 'style': 'width:12em' });
		this.captchaImg = E('img', { 'alt': _('Captcha'), 'style': 'width:200px;height:64px;border:1px solid #888;background:#fff;display:block;margin:.3em auto .4em' });
		this.btnNewCaptcha = E('button', {
			'class': 'btn cbi-button',
			'click': function(ev) { ev.preventDefault(); self.newCaptcha(); }
		}, _('New picture'));

		this.captchaRow = E('div', { 'style': 'margin:.8em 0;text-align:center' }, [
			E('div', {}, _('Type the characters in the picture:')),
			this.captchaImg,
			E('div', {}, [ this.inCaptcha, ' ', this.btnNewCaptcha ])
		]);
		show(this.captchaRow, false);

		this.loginMsg = E('div', { 'class': 'alert-message warning', 'style': 'display:none' });
		this.lockMsg = E('div', { 'class': 'alert-message warning', 'style': 'display:none' });
		this.devicesBox = E('div', { 'style': 'display:none;overflow-x:auto' });

		this.btnLogin = E('button', {
			'class': 'btn cbi-button cbi-button-action important',
			'style': 'width:100%;margin:.8em 0 0',
			'click': function(ev) { ev.preventDefault(); self.doLogin(); }
		}, _('Sign in'));

		var onEnter = function(ev) { if (ev.key === 'Enter') { ev.preventDefault(); self.doLogin(); } };
		this.inUser.addEventListener('keydown', onEnter);
		this.inPass.addEventListener('keydown', onEnter);
		this.inCaptcha.addEventListener('keydown', onEnter);

		var lnk = 'white-space:nowrap';
		this.lnkSignup = E('a', { 'target': '_blank', 'rel': 'noopener noreferrer', 'style': lnk + ';display:none' }, _('Sign up'));
		this.lnkForgot = E('a', { 'target': '_blank', 'rel': 'noopener noreferrer', 'style': lnk + ';display:none' }, _('Forgot password?'));
		this.lnkSep = E('span', { 'style': 'opacity:.5;display:none' }, '·');

		var lbl = function(forId, text) {
			return E('label', { 'for': forId, 'style': 'display:block;font-weight:bold;margin:.8em 0 .25em' }, text);
		};

		return E('div', {
			'class': 'cbi-section',
			'style': 'max-width:440px;margin:1.2em auto;padding:1.4em 1.6em;border:1px solid rgba(128,128,128,.35);border-radius:10px;box-sizing:border-box'
		}, [
			E('div', { 'style': 'text-align:center' }, [
				E('img', { 'src': L.resource('ggnet/logo.png'), 'alt': 'GGamers', 'width': '72', 'height': '72', 'style': 'width:72px;height:72px' }),
				E('h3', { 'style': 'margin:.4em 0 .2em;border:0;padding:0' }, _('Sign in to GGamers Network')),
				E('div', { 'style': 'opacity:.8' }, _('Use your GGamers account to route your games through GGamers servers and combos.'))
			]),
			lbl('ggnet-user', _('Username')),
			E('div', { 'style': 'display:flex;flex-wrap:wrap;gap:.3em .7em;align-items:center' }, [
				this.inUser,
				E('span', { 'style': 'display:inline-flex;gap:.5em;font-size:90%' }, [ this.lnkSignup, this.lnkSep, this.lnkForgot ])
			]),
			lbl('ggnet-pass', _('Password')),
			this.inPass,
			E('div', { 'style': 'margin-top:.8em' }, [
				this.inRemember, ' ',
				E('label', { 'for': 'ggnet-remember' }, _('Remember password on this router')),
				E('div', { 'class': 'cbi-value-description', 'style': 'margin-left:1.6em' },
					_('Lets the router sign in again by itself (for example after a reboot).'))
			]),
			this.captchaRow,
			this.lockMsg,
			this.loginMsg,
			this.devicesBox,
			this.btnLogin,
			E('div', { 'style': 'margin-top:1em;font-size:85%;opacity:.65;text-align:center' },
				'🔒 ' + _('Your password is sent once over HTTPS to GGamers — never to a proxy server.'))
		]);
	},

	setLinks: function(st) {
		var su = gg.safeUrl(st.signup_url), fu = gg.safeUrl(st.forgot_url);
		var set = function(a, url) {
			if (url) a.setAttribute('href', url); else a.removeAttribute('href');
			show(a, !!url);
		};
		set(this.lnkSignup, su);
		set(this.lnkForgot, fu);
		show(this.lnkSep, !!(su && fu));
	},

	setLoginMsg: function(text, severity) {
		this.loginMsg.className = 'alert-message ' + (severity || 'warning');
		this.loginMsg.textContent = text || '';
		show(this.loginMsg, !!text);
	},

	setCaptcha: function(c) {
		if (!c || !c.image) {
			this.captcha = null;
			show(this.captchaRow, false);
			return;
		}
		this.captcha = {
			id: c.id,
			image: c.image,
			expires: Date.now() + (Number(c.expires_in) > 0 ? Number(c.expires_in) * 1000 : 300000)
		};
		/* only data: PNG images from the daemon */
		if (/^data:image\/(png|jpeg|gif);base64,/.test(String(c.image)))
			this.captchaImg.src = c.image;
		this.inCaptcha.value = '';
		show(this.captchaRow, true);
	},

	newCaptcha: function() {
		var self = this;
		if (this.captchaLoading)
			return;
		this.captchaLoading = true;
		this.btnNewCaptcha.disabled = true;
		gg.call('captcha').then(function(res) {
			self.captchaLoading = false;
			self.btnNewCaptcha.disabled = false;
			if (res.ok)
				self.setCaptcha(res);
			else
				self.setLoginMsg(_('Couldn\'t load a new picture — try again.') + ' ' + gg.errorText(res), 'danger');
		});
	},

	renderDevices: function(devices, max) {
		if (!devices || !devices.length) {
			show(this.devicesBox, false);
			return;
		}
		var rows = devices.map(function(d) {
			return E('tr', { 'class': 'tr' }, [
				E('td', { 'class': 'td' }, [ String(d.name || '?') ]),
				E('td', { 'class': 'td' }, [ String(d.platform || '') ]),
				E('td', { 'class': 'td' }, [ gg.formatTime(d.last_seen) ]),
				E('td', { 'class': 'td' }, [ d.active === false ? _('Free') : (d.free_at ? gg.formatTime(d.free_at) : _('Only support can free it')) ])
			]);
		});
		dom.content(this.devicesBox, [
			E('p', {}, [ max ? _('Devices on this account (maximum %d):').format(max) : _('Devices on this account:') ]),
			E('table', { 'class': 'table cbi-section-table' }, [
				E('tr', { 'class': 'tr table-titles' }, [
					E('th', { 'class': 'th' }, _('Device')),
					E('th', { 'class': 'th' }, _('Platform')),
					E('th', { 'class': 'th' }, _('Last seen')),
					E('th', { 'class': 'th' }, _('Place frees at'))
				])
			].concat(rows))
		]);
		show(this.devicesBox, true);
	},

	doLogin: function() {
		var self = this;
		if (this.loginBusy || Date.now() < this.lockUntil)
			return;

		var u = this.inUser.value.trim(), p = this.inPass.value;
		if (!u || !p) {
			this.setLoginMsg(_('Enter your username and password.'), 'warning');
			return;
		}
		if (this.captcha && !this.inCaptcha.value.trim()) {
			this.setLoginMsg(_('Type the characters in the picture.'), 'warning');
			return;
		}

		this.loginBusy = true;
		this.btnLogin.disabled = true;
		this.btnLogin.textContent = _('Signing in…');
		this.setLoginMsg('');
		show(this.devicesBox, false);

		gg.call('login', {
			username: u,
			password: p,
			remember: !!this.inRemember.checked,
			captcha_id: this.captcha ? String(this.captcha.id) : '',
			captcha: this.captcha ? this.inCaptcha.value.trim() : ''
		}).then(function(res) {
			self.loginBusy = false;
			self.btnLogin.textContent = _('Sign in');
			self.btnLogin.disabled = false;

			if (res.ok) {
				self.inPass.value = '';
				self.setCaptcha(null);
				self.setLoginMsg('');
				return self.pollStatus();
			}

			/* a captcha works once: always take the new one */
			if (res.captcha)
				self.setCaptcha(res.captcha);
			else if (res.error === 'captcha_required')
				self.newCaptcha();

			if (res.error === 'locked' && Number(res.retry_after_sec) > 0)
				self.lockUntil = Date.now() + Number(res.retry_after_sec) * 1000;

			if (res.error === 'device_limit')
				self.renderDevices(res.devices, res.max_devices);

			var sev = ([ 'banned', 'ip_banned', 'disabled', 'tampered', 'daemon_down' ].indexOf(res.error) >= 0) ? 'danger' : 'warning';
			self.setLoginMsg(gg.errorText(res), sev);
			self.tick();
		});
	},

	/* 1 s timer: lockout countdown, captcha expiry */
	tick: function() {
		var now = Date.now();
		var st = this.st || {};
		var lb = st.login_block || {};
		var until = this.lockUntil;
		if (Number(lb.retry_until) > 0)
			until = Math.max(until, Number(lb.retry_until) * 1000);

		if (until > now) {
			var left = Math.ceil((until - now) / 1000);
			this.btnLogin.disabled = true;
			this.lockMsg.textContent = (lb.message ? String(lb.message) + ' ' : '') +
				_('You can try again in %s.').format(gg.formatDuration(left));
			show(this.lockMsg, true);
		}
		else {
			if (!this.loginBusy)
				this.btnLogin.disabled = false;
			show(this.lockMsg, false);
		}

		if (this.captcha && now > this.captcha.expires && !this.captchaLoading && this.signedOutBox.style.display !== 'none')
			this.newCaptcha();

		/* live uptime */
		if (st.signed_in && st.running && st.proxy && st.proxy.since && this.uptimeEl)
			this.uptimeEl.textContent = gg.formatDuration(now / 1000 - Number(st.proxy.since));
	},

	/* ---------------------------------------------------------------- */
	/* Signed in                                                        */
	/* ---------------------------------------------------------------- */

	/* compact account line + banners when signed in (details: Account tab) */
	buildAccount: function() {
		this.maintBox = E('div', { 'class': 'alert-message warning', 'style': 'display:none;white-space:pre-wrap' });
		this.bannerBox = E('div', { 'style': 'display:none' });
		this.noticesBox = E('div', { 'style': 'display:none' });
		this.acctBody = E('span');

		return E('div', {}, [
			E('div', { 'style': 'display:flex;flex-wrap:wrap;align-items:center;gap:.3em 1em;margin:.2em 0 .8em' }, [
				this.acctBody,
				E('a', { 'href': L.url('admin/services/ggnet/account'), 'style': 'font-size:90%' }, _('Account details →'))
			]),
			this.bannerBox,
			this.maintBox,
			this.noticesBox
		]);
	},

	/* top card when signed in */
	buildConnCard: function() {
		var self = this;

		this.aggrBox = E('div', { 'style': 'display:none' });

		this.targetPick = gg.picker({
			placeholder: _('— pick a server or combo —'),
			searchPlaceholder: _('Search servers and combos…'),
			style: 'min-width:min(22em,100%);max-width:100%',
			onChange: function(v) { self.doSelect(v); }
		});
		this.targetErr = E('div', { 'class': 'cbi-value-description', 'style': 'color:#c33;display:none' });
		this.lockHint = E('div', { 'class': 'gg-lock-hint', 'style': 'display:none' }, [ '🔒 ' + _('Stop the connection to switch server or combo.') ]);
		this.selectMsg = E('div', { 'class': 'cbi-value-description', 'style': 'color:#c33;display:none' });
		/* selected target, like Windows: flag + name + live latency */
		this.selFlag = E('span');
		this.selName = E('span', { 'class': 'gg-sel-name' });
		this.selPing = E('span');
		this.selRow = E('div', { 'class': 'gg-sel-row', 'style': 'display:none', 'title': _('Router → selected server (or the combo\'s first node), measured every 3 seconds') }, [
			this.selFlag, this.selName, this.selPing
		]);
		this.blockMsg = E('div', { 'class': 'cbi-value-description', 'style': 'color:#c33;display:none' });

		this.btnStart = E('button', {
			'class': 'btn cbi-button cbi-button-positive',
			'click': function(ev) { ev.preventDefault(); self.doStartStop(); }
		}, _('Start'));
		this.btnRefresh = E('button', {
			'class': 'btn cbi-button',
			'click': function(ev) { ev.preventDefault(); self.doRefresh(); }
		}, _('Refresh'));

		this.statusLine = E('div', { 'style': 'font-weight:bold' });
		this.uptimeEl = E('span');
		this.statsLine = E('div', { 'style': 'font-size:85%;opacity:.75;margin-top:.2em' });
		this.lastErr = E('div', { 'style': 'color:#c33;white-space:pre-wrap;display:none;margin-top:.2em' });

		this.btnPreset = E('button', {
			'class': 'btn cbi-button cbi-button-action',
			'click': function(ev) { ev.preventDefault(); self.doPreset(); }
		}, '🎮 ' + _('Apply gaming preset'));
		this.btnOptions = E('button', {
			'class': 'btn cbi-button',
			'click': function(ev) { ev.preventDefault(); self.openOptions(); }
		}, '⚙ ' + _('Protocol & options'));
		this.btnTest = E('button', {
			'class': 'btn cbi-button',
			'click': function(ev) { ev.preventDefault(); self.doConnTest(); }
		}, '🩺 ' + _('Test connection'));
		this.testBox = E('div', { 'style': 'display:none;margin-top:.6em' });
		this.toolbarMsg = E('div', { 'class': 'alert-message', 'style': 'display:none;margin-top:.5em' });

		this.route = routemod.create();
		this.routeBox = E('div', { 'style': 'display:none' }, [ this.route.node ]);
		this.aggrDetailsBody = E('div');
		this.aggrDetails = E('details', { 'style': 'margin-top:.8em;display:none' }, [
			E('summary', { 'style': 'cursor:pointer;font-weight:bold' }, '＋ ' + _('Details')),
			this.aggrDetailsBody
		]);

		/* the card itself is the left frame (see render()) */
		return [
			E('h3', {}, _('Connection')),
			frow(_('Server or combo'), [ this.targetPick.node, this.selRow, this.lockHint, this.selectMsg, this.targetErr ]),
			frow('', [
				E('div', { 'style': 'display:flex;flex-wrap:wrap;gap:.5em' }, [ this.btnStart, this.btnRefresh ]),
				this.blockMsg
			]),
			frow(_('Status'), [ this.statusLine, this.statsLine, this.lastErr ]),
			frow('', [
				E('div', { 'style': 'display:flex;flex-wrap:wrap;gap:.5em' }, [ this.btnPreset, this.btnOptions, this.btnTest ]),
				this.toolbarMsg,
				this.testBox
			]),
			this.aggrBox,
			this.routeBox,
			this.aggrDetails
		];
	},

	renderAccount: function(st) {
		var sub = st.subscription || {};
		var sig = JSON.stringify([ st.username, st.badge, st.staff, sub.chat_role, sub.active, sub.status ]);
		if (sig === this.acctSig)
			return;
		this.acctSig = sig;

		var role = sub.chat_role || (sub.active ? 'active' : 'inactive');
		var head = [
			E('span', { 'style': 'opacity:.7' }, _('Signed in as')), ' ',
			E('strong', { 'style': 'color:' + gg.roleColor(role) }, [ String(st.username || sub.username || '') ])
		];
		if (gg.roleBadge(role))
			head.push(gg.badgeEl(gg.roleBadge(role), gg.roleColor(role)));
		if (st.badge && !st.staff)
			head.push(E('span', { 'style': 'margin-left:.6em;font-size:90%' }, [ String(st.badge) ]));
		if (sub.status && !sub.active)
			head.push(E('span', { 'style': 'margin-left:.6em;font-weight:bold;color:#c33' }, [ STATUS_TEXT[sub.status] || String(sub.status) ]));

		dom.content(this.acctBody, head);
	},

	/* 1.32: "Panel unreachable" after 20 s; 1.36: this version is refused; a newer release */
	renderBanners: function(st) {
		var self = this;
		if (!this.bannerBox)
			return;
		var up = st.update || {};
		var sig = JSON.stringify([ !!st.panel_unreachable, st.update_required || '', !!up.available, up.latest || '', !!up.installing, up.status || '' ]);
		if (sig === this.bannerSig)
			return;
		this.bannerSig = sig;
		var kids = [];
		if (st.panel_unreachable)
			kids.push(E('div', { 'class': 'alert-message warning' }, [ '⚠ ' + _('Panel unreachable, reconnecting…') + ' ',
				E('span', { 'style': 'opacity:.8' }, _('Your games keep running.')) ]));
		var updBtn = function() {
			return E('button', {
				'class': 'btn cbi-button cbi-button-action', 'style': 'margin-left:.6em',
				'disabled': up.installing ? 'disabled' : null,
				'click': function(ev) {
					ev.preventDefault();
					ev.target.disabled = true;
					gg.act('update_install', {}, _('Update')).then(function() { self.bannerSig = null; self.pollStatus(); });
				}
			}, up.installing ? _('Installing…') : _('Update to %s').format(String(up.latest)));
		};
		if (st.update_required) {
			var row = [ '⛔ ' + String(st.update_required) ];
			if (up.available && up.can_install)
				row.push(updBtn());
			else
				row.push(' ', E('a', { 'href': gg.safeUrl(up.page || ''), 'target': '_blank', 'rel': 'noopener' }, _('Download')));
			kids.push(E('div', { 'class': 'alert-message danger' }, row));
		} else if (up.available) {
			var r2 = [ '⬆ ' + _('GG Network %s is available (you have %s).').format(String(up.latest), String(up.current)) ];
			if (up.can_install)
				r2.push(updBtn());
			else if (up.no_file)
				r2.push(' ', E('span', { 'style': 'opacity:.8' }, String(up.no_file)));
			if (up.url)
				r2.push(' ', E('a', { 'href': gg.safeUrl(up.url), 'target': '_blank', 'rel': 'noopener' }, _('What\'s new')));
			kids.push(E('div', { 'class': 'alert-message info' }, r2));
		}
		if (up.status && up.installing)
			kids.push(E('div', { 'class': 'alert-message info' }, [ String(up.status) ]));
		dom.content(this.bannerBox, kids);
		show(this.bannerBox, kids.length > 0);
	},

	renderMaintenance: function(st) {
		var m = st.maintenance || {};
		var text = m.notice ? String(m.notice) : '';
		this.maintBox.className = 'alert-message ' + (m.blocks_connect || m.active ? 'danger' : 'warning');
		this.maintBox.textContent = text ? '🔧 ' + text : '';
		show(this.maintBox, !!text);
	},

	renderNotices: function(st) {
		var list = Array.isArray(st.notices) ? st.notices : [];
		var sig = JSON.stringify(list);
		if (sig === this.noticeSig)
			return;
		this.noticeSig = sig;
		if (!list.length) {
			show(this.noticesBox, false);
			return;
		}
		var color = { warn: '#d29922', warning: '#d29922', error: '#c33', danger: '#c33' };
		dom.content(this.noticesBox, [
			E('h4', {}, _('Notices')),
			E('table', { 'class': 'table' }, list.slice().reverse().map(function(n) {
				return E('tr', { 'class': 'tr' }, [
					E('td', { 'class': 'td', 'style': 'white-space:nowrap;width:12em' }, [ gg.formatTime(n.ts) ]),
					E('td', { 'class': 'td', 'style': 'white-space:pre-wrap;color:' + (color[n.level] || 'inherit') }, [ String(n.text || '') ])
				]);
			}))
		]);
		show(this.noticesBox, true);
	},

	/* Staff: the connection choice (§12.2), like the Windows client — three modes, each offered only
	 * as far as GGamers' switches allow:
	 *   Normal connection — SOCKS5 only
	 *   🔥 Aggressive — single path — UDP + TCP games + copies on the combo's route
	 *   🔥 Aggressive — multipath   — the same + the backup path that skips the middle nodes (shortcut)
	 * The mode ticks its boxes; ticking or unticking a box moves the mode to match. An option GGamers has
	 * off is shown unticked and locked. Aggressive mode needs a combo. Frozen while connected. */
	renderAggr: function(st) {
		var self = this;
		var am = st.aggressive_mode || {};
		var visible = !!(st.staff && am.enabled && st.aggr_allowed !== false);
		show(this.aggrBox, visible);
		if (!visible) {
			this.aggrSig = null;
			return;
		}

		var sig = JSON.stringify([ !!am.udp, !!am.tcp, !!am.duplicate, !!am.shortcut ]);
		if (sig !== this.aggrSig) {
			this.aggrSig = sig;
			this.aggrInputs = {};

			this.aggrSel = E('select', {
				'class': 'cbi-input-select',
				'change': function() { self.onConnChoice(); }
			}, [
				E('option', { 'value': '0' }, _('Normal connection')),
				E('option', { 'value': '1' }, '🔥 ' + _('Aggressive — single path')),
				am.shortcut ? E('option', { 'value': '2' }, '🔥 ' + _('Aggressive — multipath')) : ''
			]);

			this.aggrSwitches = E('div', { 'style': 'margin-top:.5em' }, AGGR_OPTS.map(function(o) {
				var cb = E('input', {
					'type': 'checkbox',
					'id': 'ggnet-aggr-' + o[0],
					'change': function() { self.onAggrOption(); }
				});
				self.aggrInputs[o[0]] = cb;
				return E('div', { 'title': am[o[0]] ? null : _('Turned off on the panel') }, [
					cb, ' ',
					E('label', { 'for': 'ggnet-aggr-' + o[0] }, o[1] + (o[0] === 'shortcut' ? ' ' + _('(combos only)') : ''))
				]);
			}));
			this.aggrHint = E('div', { 'style': 'display:none;color:#d29922;margin-top:.3em' });

			dom.content(this.aggrBox, [
				frow(_('Connection choice'), [
					this.aggrSel,
					this.aggrSwitches,
					this.aggrHint
				])
			]);
		}

		/* sync from the saved choice unless the user is busy with it */
		var ch = st.aggr_choice || {};
		var active = document.activeElement;
		if (!this.aggrBusy && active !== this.aggrSel && Object.keys(this.aggrInputs).every(function(k) { return active !== self.aggrInputs[k]; })) {
			var combo = String(st.selected || '').indexOf('combo:') === 0;
			var on = !!ch.on && combo;   /* a plain server: shown as Normal, the choice is kept for the next combo */
			this.aggrSel.value = String(!on ? 0 : (ch.shortcut && am.shortcut ? 2 : 1));
			AGGR_OPTS.forEach(function(o) { self.aggrInputs[o[0]].checked = !!(am[o[0]] && ch[o[0]]); });
		}
		this.greyAggrOptions(st);
	},

	/* panel off → locked off; copies and the backup path need UDP or TCP; the backup path needs a combo */
	greyAggrOptions: function(st) {
		st = st || this.st || {};
		var am = st.aggressive_mode || {}, inp = this.aggrInputs || {};
		if (!this.aggrSel)
			return;
		var running = !!st.running;
		var mode = Number(this.aggrSel.value);
		this.aggrSel.disabled = running;
		show(this.aggrSwitches, mode > 0);
		var anyGame = (inp.udp && inp.udp.checked) || (inp.tcp && inp.tcp.checked);
		var combo = String(st.selected || '').indexOf('combo:') === 0;
		var en = { udp: !!am.udp, tcp: !!am.tcp, duplicate: !!am.duplicate && anyGame, shortcut: !!am.shortcut && anyGame && combo };
		AGGR_OPTS.forEach(function(o) {
			var cb = inp[o[0]];
			if (!cb) return;
			cb.disabled = running || !en[o[0]];
			cb.parentNode.style.opacity = cb.disabled ? '.55' : '';
		});
		this.aggrSel.title = running ? _('Stop the connection to change it.') : '';
	},

	onConnChoice: function() {
		var st = this.st || {}, am = st.aggressive_mode || {}, inp = this.aggrInputs;
		var mode = Number(this.aggrSel.value);
		if (mode > 0 && String(st.selected || '').indexOf('combo:') !== 0) {
			/* combo-only: bounce back to Normal and say why */
			this.aggrSel.value = '0';
			this.aggrHint.textContent = '🔥 ' + _('Aggressive mode works only with a combo — pick a combo from the list first.');
			show(this.aggrHint, true);
			this.greyAggrOptions(st);
			this.renderRoute(st);
			return;
		}
		show(this.aggrHint, false);
		if (mode > 0) {
			/* the mode ticks its boxes, each only as far as the panel offers it */
			inp.udp.checked = !!am.udp;
			inp.tcp.checked = !!am.tcp;
			inp.duplicate.checked = !!am.duplicate;
			inp.shortcut.checked = mode === 2 && !!am.shortcut;
		}
		this.greyAggrOptions(st);
		this.doAggrSet(mode > 0);
	},

	onAggrOption: function() {
		var st = this.st || {}, am = st.aggressive_mode || {}, inp = this.aggrInputs;
		/* the mode always matches the boxes: no UDP and no TCP left → Normal; the backup path → multipath */
		var anyGame = (inp.udp.checked && am.udp) || (inp.tcp.checked && am.tcp);
		var mode = !anyGame ? 0 : (inp.shortcut.checked && am.shortcut ? 2 : 1);
		if (!mode) {
			/* Normal again; the boxes come back ticked the next time an Aggressive mode is picked */
			inp.udp.checked = !!am.udp;
			inp.tcp.checked = !!am.tcp;
		}
		this.aggrSel.value = String(mode);
		this.greyAggrOptions(st);
		this.doAggrSet(mode > 0);
	},

	doAggrSet: function(on) {
		var self = this;
		var args = { on: !!on };
		[ 'udp', 'tcp', 'duplicate', 'shortcut' ].forEach(function(k) { args[k] = !!self.aggrInputs[k].checked; });
		this.aggrBusy = true;
		if (this.st) {   /* draw the new route at once */
			this.st.aggr_choice = args;
			this.st.aggr_effective = !!on;
			this.renderRoute(this.st);
		}
		gg.act('aggr_set', args, _('Connection choice')).then(function() {
			self.aggrBusy = false;
			self.pollStatus();
		});
	},

	/* ---------------------------------------------------------------- */
	/* The route picture (Windows AggrRouteView): shown while Aggressive mode is on for a combo */
	renderRoute: function(st) {
		if (!this.route)
			return;
		var combo = String(st.selected || '').indexOf('combo:') === 0;
		var on = !!st.aggr_effective && st.aggr_allowed !== false && (st.aggressive_mode || {}).enabled;
		show(this.routeBox, !!(on && combo));
		if (!on || !combo)
			return;
		var id = Number(String(st.selected).slice(6));
		var c = (this.combos || []).filter(function(x) { return Number(x.id) === id; })[0] || {};
		var hops = Array.isArray(c.hops) ? c.hops : [];
		var ccOf = function(name) {
			var h = hops.filter(function(x) { return String(x.name || '').toLowerCase() === String(name || '').toLowerCase(); })[0];
			return h ? String(h.cc || '') : '';
		};
		var ar = st.aggr_run || {};
		var exit = hops.length ? String(hops[hops.length - 1].name || '') : '';
		var lanes = [], caption = '', flowing = false, latency = null;

		if (st.running && ar.active && Array.isArray(ar.paths) && ar.paths.length) {
			if (ar.exit)
				exit = String(ar.exit);
			ar.paths.slice().sort(function(a, b) { return Number(a.id) - Number(b.id); }).forEach(function(p) {
				var state = p.not_reachable ? 2 : (p.welcomed || Number(p.rtt_ms) > 0 ? 0 : 1);
				var copies = Number(p.id) === 0 ? Math.max(1, Number(ar.copies) || 1) : 1;
				var via = String(p.via || '').split('→').map(function(x) { return x.trim(); })
					.filter(function(x) { return x && x.toLowerCase() !== exit.toLowerCase(); });
				var nodes = via.map(function(x) { return { name: x, cc: ccOf(x) }; });
				for (var i = 0; i < copies; i++)
					lanes.push({ label: i === 0 ? (p.kind === 'shortcut' ? _('shortcut') : '') : _('copy %d').format(i + 1),
						state: state, nodes: i === 0 ? nodes : [], group: Number(p.id) });
				if (!p.not_reachable && Number(p.rtt_ms) > 0)
					latency = latency == null ? Number(p.rtt_ms) : Math.min(latency, Number(p.rtt_ms));
			});
			flowing = lanes.some(function(l) { return l.state === 0; });
			var down = lanes.filter(function(l) { return l.state === 2; }).length;
			caption = ar.recovering ? _('Recovering the tunnel on a new local port…')
				: (down ? _('%d line(s) not reachable — the others keep the game going').format(down) : '');
		}
		else {
			/* before a session: the lanes the switches would give */
			var am = st.aggressive_mode || {}, ch = st.staff ? (st.aggr_choice || {}) : am;
			var dup = !!(am.duplicate && ch.duplicate), sc = !!(am.shortcut && ch.shortcut);
			var copies = dup ? Math.min(Math.max(Number(am.copies) || 1, 1), 3) : 1;
			var before = hops.slice(0, Math.max(0, hops.length - 1)).map(function(h) { return { name: String(h.name || ''), cc: String(h.cc || '') }; });
			var backup = hops.length > 2 ? before.slice(0, 1) : [];
			for (var i = 0; i < copies; i++)
				lanes.push({ label: i === 0 ? '' : _('copy %d').format(i + 1), state: 1, nodes: i === 0 ? before : [], group: 0 });
			if (sc)
				lanes.push({ label: _('shortcut'), state: 1, nodes: backup, group: 1 });
			caption = st.running ? _('Normal connection') + (ar.result ? ' — ' + String(ar.result) : '') : _('Ready — press Start to connect');
		}
		this.route.update(lanes, flowing, exit, ccOf(exit), flowing ? latency : null, caption);
	},

	doRestart: function() {
		var self = this;
		gg.act('stop', {}, _('Stop')).then(function() {
			return gg.act('start', {}, _('Start'));
		}).then(function() { self.pollStatus(); });
	},

	/* Target selector (flags need a custom dropdown: a <select> can't hold images) */
	renderTargets: function(st) {
		var items = [];
		(Array.isArray(st.servers) ? st.servers : []).forEach(function(s) {
			if (s.available === false)
				return;
			var cc = gg.isCountry(s.cc) ? String(s.cc).toUpperCase() : '';
			var ping = (s.ping_ms == null) ? null : Number(s.ping_ms);
			items.push({ value: 'server:' + s.name, cc: cc, label: _('Server: %s').format(String(s.name)), search: String(s.name),
				ping: ping == null ? 'm' : (ping < 0 ? '-1' : String(Math.round(ping))),
				content: function() {
					return [ _('Server: %s').format(String(s.name)), ' ', gg.pingBadge(ping) ];
				} });
		});

		var totals = {};
		(Array.isArray(st.combo_totals) ? st.combo_totals : []).forEach(function(t) { totals[t.id] = t; });
		this.combos.forEach(function(c) {
			var hops = Array.isArray(c.hops) ? c.hops : [];
			var tot = totals[c.id] || null;
			var item = {
				ping: tot ? [ tot.ping_ms == null ? 'm' : Math.round(Number(tot.ping_ms)), tot.kind, tot.approx ].join('/') : '',
				value: 'combo:' + c.id,
				search: [ c.name ].concat(hops.map(function(h) { return h.name; })).join(' '),
				disabled: c.available === false,
				content: function() {
					var kids = [ _('Combo: %s').format(String(c.name || '?')) ];
					if (c.official)
						kids.push(gg.badgeEl(_('Official'), '#e3b341'));
					var route = [ ' (' ];
					hops.forEach(function(h, i) {
						if (i) route.push(' → ');
						route = route.concat(gg.ccLabel(h.cc, String(h.name || '?')));
					});
					route.push(')');
					kids.push(E('span', { 'style': 'opacity:.75;margin-left:.3em' }, route));
					if (tot && c.available !== false)
						kids.push(' ', comboBadge(tot));
					return kids;
				}
			};
			if (c.available === false) {
				var down = hops.filter(function(h) { return h.online === false; }).map(function(h) { return h.name; });
				item.sub = '— ' + (down.length ? _('unavailable: %s').format(down.join(', ')) : _('unavailable'));
			}
			items.push(item);
		});

		var sel = st.selected || '';
		if (sel && !items.some(function(o) { return o.value === sel; }))
			items.unshift({ value: sel, label: String(st.selected_label || sel) + ' — ' + _('not available'), disabled: true });

		var sig = JSON.stringify([ items.map(function(o) { return [ o.value, o.cc, o.label, o.search, o.sub, o.disabled, o.ping ]; }), sel,
			this.combos.map(function(c) { return [ c.id, c.official, (c.hops || []).map(function(h) { return h.cc; }) ]; }) ]);
		if (sig !== this.targetSig && !this.targetPick.isOpen() && !this.selectBusy) {
			this.targetSig = sig;
			this.targetPick.setItems(items);
			this.targetPick.setValue(sel);
		}

		/* the target is locked while connected */
		var running = !!st.running;
		this.targetPick.setDisabled(running || this.selectBusy);
		show(this.lockHint, running);
		if (!running && this.selectMsgRunning) {
			this.selectMsgRunning = false;
			show(this.selectMsg, false);
		}

		this.renderSelected(st);

		this.targetErr.textContent = st.selected_error ? String(st.selected_error) : '';
		show(this.targetErr, !!st.selected_error);
	},

	/* "[flag] name  [42 ms]" for the selected target, refreshed with every status poll */
	renderSelected: function(st) {
		if (!st.selected) {
			show(this.selRow, false);
			return;
		}
		var cc = gg.isCountry(st.selected_cc) ? String(st.selected_cc).toUpperCase() : '';
		if (cc !== this.selCc) {
			this.selCc = cc;
			dom.content(this.selFlag, cc ? [ gg.flag(cc, { size: 16 }) ] : []);
		}
		this.selName.textContent = String(st.selected_label || st.selected);
		var p = st.selected_ping_ms, t = st.selected_total;
		var key = (p == null || p === '') ? 'null' : String(Math.round(Number(p)));
		if (t)
			key += '|' + [ t.kind, t.approx, Math.round(Number(t.first_ms) || 0), Math.round(Number(t.links_ms) || 0), Math.round(Number(t.game_ms) || 0) ].join('/');
		if (key !== this.selPingKey) {
			this.selPingKey = key;
			if (t) {
				var parts = [];
				if (t.first_ms != null) parts.push(_('you %d').format(Math.round(Number(t.first_ms))));
				parts.push(_('links %d').format(Math.round(Number(t.links_ms) || 0)));
				if (t.game_ms != null) parts.push(_('game %d').format(Math.round(Number(t.game_ms))));
				dom.content(this.selPing, [ comboBadge(t),
					E('span', { 'style': 'font-size:80%;opacity:.7;margin-left:.4em' }, [ '(' + parts.join(' + ') + ' ms)' ]) ]);
			}
			else
				dom.content(this.selPing, [ gg.pingBadge(p == null || p === '' ? null : Number(p)) ]);
		}
		show(this.selRow, true);
	},

	doSelect: function(target) {
		var self = this;
		if (!target)
			return;
		if (this.st && this.st.running) {
			this.targetSig = null;
			this.targetPick.setValue(this.st.selected || '');
			return;
		}
		this.selectBusy = true;
		this.targetPick.setDisabled(true);
		show(this.selectMsg, false);
		gg.call('select', { target: target }).then(function(res) {
			self.selectBusy = false;
			self.targetSig = null;
			if (!res.ok) {
				self.selectMsgRunning = res.error === 'running';
				self.selectMsg.textContent = res.error === 'running'
					? (res.message ? String(res.message) : _('Stop the connection first to switch to another server or combo.'))
					: _('Select') + ': ' + gg.errorText(res);
				show(self.selectMsg, true);
				if (res.error !== 'running')
					gg.notify(res, _('Select'));
			}
			self.pollStatus();
		});
	},

	renderConnect: function(st) {
		var running = !!st.running;
		this.btnStart.textContent = running ? _('Stop') : _('Start');
		this.btnStart.className = 'btn cbi-button ' + (running ? 'cbi-button-negative' : 'cbi-button-positive');
		if (!this.startBusy)
			this.btnStart.disabled = !running && (!st.can_connect || !st.selected);

		var why = '';
		if (!running && !st.can_connect)
			why = st.connect_block ? String(st.connect_block) : _('You can\'t connect right now.');
		else if (!running && !st.selected)
			why = _('Pick a server or combo first.');
		this.blockMsg.textContent = why;
		show(this.blockMsg, !!why);
	},

	doStartStop: function() {
		var self = this;
		var running = this.st && this.st.running;
		this.startBusy = true;
		this.btnStart.disabled = true;
		gg.act(running ? 'stop' : 'start', {}, running ? _('Stop') : _('Start')).then(function() {
			self.startBusy = false;
			return self.pollStatus();
		});
	},

	doRefresh: function() {
		var self = this;
		this.btnRefresh.disabled = true;
		gg.act('refresh', {}, _('Refresh')).then(function() {
			return self.loadCombos();
		}).then(function() {
			self.btnRefresh.disabled = false;
			return self.pollStatus();
		});
	},

	/* Running panel + §12.12 details */
	renderRunning: function(st) {
		var running = !!st.running;
		var p = st.proxy || {};

		if (!running) {
			dom.content(this.statusLine, E('span', { 'style': 'opacity:.75' }, '○ ' + _('Not connected')));
			this.statsLine.textContent = st.selected_label ? _('Selected: %s').format(String(st.selected_label)) : '';
			show(this.lastErr, !!p.last_error);
			this.lastErr.textContent = p.last_error ? _('Last error: %s').format(String(p.last_error)) : '';
			show(this.aggrDetails, false);
			return;
		}

		this.uptimeEl.textContent = p.since ? gg.formatDuration(Date.now() / 1000 - Number(p.since)) : '–';
		dom.content(this.statusLine, [
			E('span', { 'style': 'color:#3fb950' }, [ '● ' + _('Connected to %s').format(String(p.target_label || st.selected_label || p.target || '–')) ]),
			E('span', { 'style': 'font-weight:normal' }, [
				'  ·  ⏱ ', this.uptimeEl,
				'  ·  ' + _('↑ %s  ↓ %s').format(gg.formatBytes(p.bytes_up || 0), gg.formatBytes(p.bytes_down || 0))
			])
		]);
		this.statsLine.textContent = [
			_('TCP %d active / %d total').format(Number(p.tcp_active) || 0, Number(p.tcp_total) || 0),
			_('UDP flows %d').format(Number(p.udp_flows) || 0),
			_('SOCKS5 %d TCP, %d UDP').format(Number(p.socks_tcp) || 0, Number(p.socks_udp) || 0),
			_('tunnel %d TCP, %d UDP').format(Number(p.tunnel_tcp) || 0, Number(p.tunnel_udp) || 0)
		].join('  ·  ');
		this.lastErr.textContent = p.last_error ? _('Last error: %s').format(String(p.last_error)) : '';
		show(this.lastErr, !!p.last_error);

		this.renderAggrDetails(st);
	},

	renderAggrDetails: function(st) {
		var ar = st.aggr_run;
		var am = st.aggressive_mode || {};
		var on = !!st.aggr_effective;
		show(this.aggrDetails, !!(ar || on));
		if (!ar && !on)
			return;
		ar = ar || {};
		var p = st.proxy || {};

		var src = st.staff ? (st.aggr_choice || {}) : am;
		var optNames = AGGR_OPTS.filter(function(o) { return src[o[0]] && am[o[0]]; }).map(function(o) { return o[1]; });
		var header = on ? _('Aggressive mode: ON') + (optNames.length ? ' (' + optNames.join(', ') + ')' : '') : _('Aggressive mode: OFF');

		var session = String(ar.result || (ar.asked ? '–' : _('Not asked')));
		if (ar.active)
			session += '  ·  ' + _('exit %s').format(ar.exit || '?') +
				' · udp ' + yesno(ar.udp) + ' tcp ' + yesno(ar.tcp) +
				' · ' + _('copies %d').format(Number(ar.copies) || 1) +
				' · shortcut ' + yesno(ar.shortcut);

		var paths = Array.isArray(ar.paths) ? ar.paths : [];
		var pathRows = paths.map(function(x) {
			var w;
			if (x.not_reachable) w = E('span', { 'style': 'color:#c33' }, _('not reachable'));
			else if (x.welcomed && Number(x.status || 0) === 0) w = E('span', { 'style': 'color:#3fb950' }, 'WELCOME ✔');
			else if (x.welcomed) w = E('span', { 'style': 'color:#c33' }, [ _('WELCOME status %d').format(Number(x.status)) ]);
			else w = E('span', { 'style': 'color:#c33' }, _('no WELCOME'));
			return E('tr', { 'class': 'tr' }, [
				E('td', { 'class': 'td' }, [ _('Path %d').format(Number(x.id) || 0) ]),
				E('td', { 'class': 'td' }, [ String(x.kind || '') ]),
				E('td', { 'class': 'td', 'style': 'font-family:monospace' }, [ String(x.host || '?') + ':' + String(x.port || '?') ]),
				E('td', { 'class': 'td' }, [ x.via ? _('via %s').format(x.via) : '' ]),
				E('td', { 'class': 'td' }, w),
				E('td', { 'class': 'td' }, [ Number(x.rtt_ms) > 0 ? gg.formatMs(x.rtt_ms) : _('no PONG') ])
			]);
		});

		var socksTotal = (Number(p.socks_tcp) || 0) + (Number(p.socks_udp) || 0);
		var fallbacks = Array.isArray(ar.fallbacks) ? ar.fallbacks : [];

		var body = [
			E('p', { 'style': 'font-weight:bold;margin-top:.5em' }, [ header ]),
			kvTable([
				[ _('Session'), session ],
				[ _('Tunnel'), _('UDP frames sent %s / received %s · UDP packets sent %s / received %s · TCP streams %s').format(
					gg.formatNum(ar.frames_sent), gg.formatNum(ar.frames_recv),
					gg.formatNum(ar.udp_sent), gg.formatNum(ar.udp_recv),
					gg.formatNum(ar.tcp_streams)) ],
				[ _('SOCKS5'), _('%d connections (%d TCP, %d UDP)').format(socksTotal, Number(p.socks_tcp) || 0, Number(p.socks_udp) || 0) ]
			])
		];

		if (pathRows.length)
			body.push(E('table', { 'class': 'table cbi-section-table' }, [
				E('tr', { 'class': 'tr table-titles' }, [
					E('th', { 'class': 'th' }, _('Path')),
					E('th', { 'class': 'th' }, _('Kind')),
					E('th', { 'class': 'th' }, _('Address')),
					E('th', { 'class': 'th' }, _('Via')),
					E('th', { 'class': 'th' }, _('WELCOME')),
					E('th', { 'class': 'th' }, _('Round trip'))
				])
			].concat(pathRows)));

		if (fallbacks.length) {
			body.push(E('h5', {}, _('Fallbacks to SOCKS5')));
			body.push(E('pre', { 'style': 'max-height:12em;overflow:auto;white-space:pre-wrap' }, [ fallbacks.map(String).join('\n') ]));
		}

		dom.content(this.aggrDetailsBody, body);
	},

	/* ---------------------------------------------------------------- */
	/* Test connection (Windows "Test connection", run from the router) */
	/* ---------------------------------------------------------------- */

	doConnTest: function() {
		var self = this;
		if (this.testBusy)
			return;
		var st = this.st || {};
		var close = E('button', {
			'class': 'btn cbi-button', 'style': 'position:absolute;top:.3em;right:.3em;padding:0 .5em;min-width:0;height:auto;line-height:1.6em',
			'title': _('Close'),
			'click': function(ev) { ev.preventDefault(); show(self.testBox, false); }
		}, '✕');

		if (!st.selected) {
			dom.content(this.testBox, E('div', { 'class': 'alert-message warning' }, _('Pick a server or combo first.')));
			show(this.testBox, true);
			return;
		}

		var label = String(st.selected_label || st.selected);
		this.testBusy = true;
		this.btnTest.disabled = true;
		dom.content(this.btnTest, [ E('span', { 'class': 'spinning' }, _('Testing…')) ]);
		dom.content(this.testBox, E('div', { 'class': 'alert-message info' }, [
			E('span', { 'class': 'spinning' }, [ _('Testing the connection through %s… this can take up to 15 seconds.').format(label) ])
		]));
		show(this.testBox, true);

		gg.call('conn_test').then(function(res) {
			self.testBusy = false;
			self.btnTest.disabled = false;
			dom.content(self.btnTest, '🩺 ' + _('Test connection'));

			if (!res.ok) {
				dom.content(self.testBox, E('div', { 'class': 'alert-message danger', 'style': 'position:relative;padding-right:2.5em' }, [
					E('strong', {}, _('Test connection')), ': ', gg.errorText(res), close
				]));
				return;
			}

			var steps = Array.isArray(res.steps) ? res.steps : [];
			var allOk = res.all_ok != null ? !!res.all_ok : (steps.length > 0 && steps.every(function(x) { return x.ok; }));
			var good = '#3fb950', bad = '#e04848';

			var rows = steps.map(function(x) {
				var msv = (x.ms != null && x.ms !== '' && isFinite(Number(x.ms))) ? gg.formatMs(x.ms) : '';
				return E('div', { 'style': 'display:flex;flex-wrap:wrap;gap:.2em .6em;align-items:baseline;padding:.15em 0' }, [
					E('span', { 'style': 'flex:none;width:1.2em;font-weight:bold;color:' + (x.ok ? good : bad) }, [ x.ok ? '✔' : '✖' ]),
					E('span', { 'style': 'flex:none;min-width:7em;font-weight:bold' }, [ String(x.name || '') ]),
					E('span', { 'style': 'flex:none;min-width:4.5em;opacity:.8;font-family:monospace' }, [ msv ]),
					E('span', { 'style': 'flex:1 1 12em;opacity:.85' }, [ String(x.detail || '') ])
				]);
			});

			dom.content(self.testBox, E('div', {
				'style': 'position:relative;border:1px solid ' + (allOk ? good : bad) + ';border-left-width:4px;border-radius:6px;padding:.6em 2.4em .6em .9em'
			}, [
				E('div', { 'style': 'font-size:90%;opacity:.75;margin-bottom:.3em' }, [
					_('Test connection — %s').format(String(res.target_label || label))
				]),
				E('div', {}, rows.length ? rows : [ E('em', {}, _('No test steps were returned.')) ]),
				E('div', { 'style': 'font-weight:bold;margin-top:.4em;color:' + (allOk ? good : bad) }, [ String(res.summary || (allOk ? _('Everything works.') : _('The test found a problem.'))) ]),
				close
			]));
		});
	},

	/* ---------------------------------------------------------------- */
	/* Toolbar: gaming preset + protocol & options dialog               */
	/* ---------------------------------------------------------------- */

	setSettings: function(res) {
		if (res && res.ok && res.settings) {
			this.settings = res.settings;
			this.presetApplied = !!res.preset_applied;
			this.settingsErr = null;
		}
		else if (res && !res.ok) {
			this.settingsErr = res;
		}
		this.renderToolbar();
	},

	loadSettings: function() {
		var self = this;
		return gg.call('settings_get').then(function(res) { self.setSettings(res); });
	},

	renderToolbar: function() {
		if (!this.btnPreset)
			return;
		if (this.presetApplied) {
			this.btnPreset.textContent = '🎮 ' + _('Gaming preset applied ✓');
			this.btnPreset.disabled = true;
			this.btnPreset.title = _('The recommended router tuning is on. Change single options on the Settings page.');
		}
		else {
			this.btnPreset.textContent = this.presetBusy ? _('Applying…') : '🎮 ' + _('Apply gaming preset');
			this.btnPreset.disabled = this.presetBusy || !this.settings;
			this.btnPreset.title = (!this.settings && this.settingsErr)
				? gg.errorText(this.settingsErr)
				: _('QoS low latency, TCP quick ACK, keepalive 30 s, high priority, large buffers');
		}
		this.btnOptions.disabled = !!this.optionsBusy;
	},

	doPreset: function() {
		var self = this;
		if (this.presetBusy || this.presetApplied)
			return;
		this.presetBusy = true;
		setMsg(this.toolbarMsg, '');
		this.renderToolbar();
		gg.call('preset_apply').then(function(res) {
			self.presetBusy = false;
			if (res.ok)
				setMsg(self.toolbarMsg, '🎮 ' + _('Gaming preset applied.'), 'success');
			else
				setMsg(self.toolbarMsg, _('Gaming preset') + ': ' + gg.errorText(res), 'danger');
			return self.loadSettings();
		});
	},

	openOptions: function() {
		var self = this;
		if (this.optionsBusy)
			return;
		this.optionsBusy = true;
		this.renderToolbar();
		setMsg(this.toolbarMsg, '');
		gg.call('settings_get').then(function(res) {
			self.optionsBusy = false;
			self.setSettings(res);
			if (!res.ok || !res.settings) {
				setMsg(self.toolbarMsg, _('Protocol & options') + ': ' + gg.errorText(res), 'danger');
				return;
			}
			self.showOptionsModal(res.settings);
		});
	},

	showOptionsModal: function(s) {
		var self = this;
		var uid = 'ggnet-opt-';

		var cb = function(id, checked, text, note) {
			var input = E('input', { 'type': 'checkbox', 'id': uid + id });
			input.checked = !!checked;
			var wrap = E('div', { 'style': 'margin:.25em 0' }, [
				input, ' ', E('label', { 'for': uid + id }, text),
				note ? E('div', { 'class': 'cbi-value-description', 'style': 'margin-left:1.6em' }, note) : ''
			]);
			return { input: input, node: wrap };
		};
		var radio = function(id, value, checked, text) {
			var input = E('input', { 'type': 'radio', 'name': uid + 'proto', 'id': uid + id, 'value': value });
			input.checked = !!checked;
			return { input: input, node: E('div', { 'style': 'margin:.25em 0' }, [ input, ' ', E('label', { 'for': uid + id }, text) ]) };
		};

		var tcpOnly = s.udp_mode === 'tcp_only';
		var rUdp = radio('udp', 'udp', !tcpOnly, _('Enable UDP relay (games)'));
		var rTcp = radio('tcp', 'tcp_only', tcpOnly, _('TCP only'));
		var cBlock = cb('block', s.block_udp, _('Block UDP while TCP-only'),
			_('Drops the selected devices\' internet UDP so games fall back to TCP.'));
		cBlock.node.style.marginLeft = '1.6em';
		var cWeb = cb('web', s.bypass_web, _('Bypass web (HTTP/HTTPS/QUIC)'),
			_('Web traffic (TCP 80/443, UDP 443) goes direct — saves your data quota.'));
		var cVoice = cb('voice', s.bypass_voice !== false, _('Bypass voice chat & remote tools'),
			_('Discord, TeamSpeak, Mumble, voice and video calls (WhatsApp, Teams, Zoom, Meet), ZeroTier, Tailscale, WireGuard, AnyDesk, TeamViewer and Parsec go direct, so they don\'t use GG Network\'s bandwidth. A router can\'t see which program sends, so they are recognised by their ports. Games that use Google\'s STUN port (19302) to find their NAT type then see your home connection.'));
		var cLocal = cb('local', s.bypass_local, _('Bypass local / LAN'),
			_('Private and reserved address ranges are never tunneled.'));
		var cV6 = cb('v6', s.block_ipv6 !== false, _('Block IPv6 for tunneled devices (recommended)'),
			_('GG Network carries IPv4. Without this, sites and games reached over IPv6 go direct.'));
		var cRed = cb('red', s.udp_redundancy, _('3× UDP redundancy (anti packet-loss)'),
			_('This session only — it is off again after a restart.'));
		var cDns = cb('dns', s.tunnel_dns, _('Tunnel DNS (UDP/53)'),
			_('The devices\' DNS queries go through GG Network to the server below.'));
		var inDns = E('input', {
			'type': 'text', 'class': 'cbi-input-text', 'style': 'width:12em',
			'placeholder': '1.1.1.1', 'autocapitalize': 'off', 'spellcheck': 'false'
		});
		inDns.value = s.dns_server ? String(s.dns_server) : '1.1.1.1';
		var msg = E('div', { 'class': 'alert-message', 'style': 'display:none' });

		var sync = function() {
			cBlock.input.disabled = !rTcp.input.checked;
			cBlock.node.style.opacity = rTcp.input.checked ? '' : '.5';
			inDns.disabled = !cDns.input.checked;
		};
		[ rUdp.input, rTcp.input, cDns.input ].forEach(function(i) { i.addEventListener('change', sync); });
		sync();

		var btnSave = E('button', {
			'class': 'btn cbi-button cbi-button-positive important',
			'click': function(ev) {
				ev.preventDefault();
				var next = {
					udp_mode: rTcp.input.checked ? 'tcp_only' : 'udp',
					block_udp: !!cBlock.input.checked,
					bypass_web: !!cWeb.input.checked,
					bypass_voice: !!cVoice.input.checked,
					bypass_local: !!cLocal.input.checked,
					block_ipv6: !!cV6.input.checked,
					udp_redundancy: !!cRed.input.checked,
					tunnel_dns: !!cDns.input.checked,
					dns_server: inDns.value.trim() || '1.1.1.1'
				};
				if (next.tunnel_dns && !isIPv4(next.dns_server)) {
					setMsg(msg, _('Enter the DNS server as an IPv4 address, for example 1.1.1.1.'), 'warning');
					inDns.focus();
					return;
				}
				var changed = {}, n = 0;
				Object.keys(next).forEach(function(k) {
					var old = s[k];
					if (k === 'dns_server' && !old) old = '1.1.1.1';
					if (k === 'udp_mode' && !old) old = 'udp';
					if (typeof next[k] === 'boolean') old = !!old;
					if (next[k] !== old) { changed[k] = next[k]; n++; }
				});
				if (!n) {
					ui.hideModal();
					return;
				}
				btnSave.disabled = true;
				setMsg(msg, _('Saving…'), 'info');
				gg.call('settings_set', { settings: changed }).then(function(res) {
					btnSave.disabled = false;
					if (!res.ok) {
						setMsg(msg, gg.errorText(res), 'danger');
						return;
					}
					ui.hideModal();
					setMsg(self.toolbarMsg, _('Protocol & options saved.'), 'success');
					self.loadSettings();
				});
			}
		}, _('Save'));

		ui.showModal('⚙ ' + _('Protocol & options'), [
			E('h4', {}, _('Protocol')),
			rUdp.node, rTcp.node, cBlock.node,
			E('h4', {}, _('Options')),
			cWeb.node, cVoice.node, cLocal.node, cV6.node, cRed.node, cDns.node,
			E('div', { 'style': 'margin:.2em 0 .6em' }, [ E('label', { 'style': 'margin-left:1.6em;margin-right:.4em' }, _('DNS server')), inDns ]),
			E('p', {}, E('a', { 'href': L.url('admin/services/ggnet/settings') }, _('More tuning settings (router enhancements) on the Settings page…'))),
			msg,
			E('div', { 'class': 'right' }, [
				E('button', { 'class': 'btn cbi-button', 'click': function(ev) { ev.preventDefault(); ui.hideModal(); } }, _('Cancel')),
				' ',
				btnSave
			])
		]);
	},

	/* ---------------------------------------------------------------- */

	loadCombos: function() {
		var self = this;
		return gg.call('combos').then(function(res) { self.setCombos(res); });
	},

	setCombos: function(res) {
		if (!res || !res.ok || res.enabled === false) {
			if (res && res.ok)
				this.combos = [];
			return;
		}
		var seen = {}, list = [];
		(res.mine || []).concat(res.attached || []).forEach(function(c) {
			if (!seen[c.id]) { seen[c.id] = true; list.push(c); }
		});
		this.combos = list;
	},

	pollStatus: function() {
		var self = this;
		return gg.call('status').then(function(st) { self.update(st); });
	},

	update: function(st) {
		if (!st.ok) {
			this.daemonMsg.textContent = gg.errorText(st);
			show(this.daemonMsg, true);
			show(this.signedOutBox, false);
			show(this.signedInBox, false);
			show(this.chatCol, false);
			this.setChat(false);
			return;
		}
		show(this.daemonMsg, false);
		var wasSignedIn = !!(this.st && this.st.signed_in);
		this.st = st;

		var signedIn = !!st.signed_in;
		show(this.signedOutBox, !signedIn);
		show(this.signedInBox, signedIn);
		show(this.chatCol, signedIn);
		this.setChat(signedIn);
		this.setLinks(st);
		if (!signedIn && this.testBox)
			show(this.testBox, false);

		if (signedIn && !wasSignedIn && !this.settings)
			this.loadSettings();

		if (!signedIn) {
			if (st.username && !this.inUser.value && document.activeElement !== this.inUser)
				this.inUser.value = String(st.username);
			if (st.remember != null && !this.rememberInit) {
				this.rememberInit = true;
				this.inRemember.checked = !!st.remember;
			}
			this.acctSig = null;
			this.tick();
			return;
		}

		this.renderBanners(st);
		this.renderMaintenance(st);
		this.renderNotices(st);
		this.renderAccount(st);
		this.renderAggr(st);
		this.renderRoute(st);
		this.renderTargets(st);
		this.renderConnect(st);
		this.renderRunning(st);
	},

	/* embedded live chat: only polls while signed in */
	setChat: function(on) {
		if (on) {
			if (!this.chat) {
				this.chat = chatmod.create({ fill: true });
				dom.content(this.chatCol, [ this.chat.render() ]);
			}
			else {
				this.chat.start();
			}
		}
		else if (this.chat) {
			this.chat.stop();
		}
	},

	render: function(data) {
		report.mount();
		var self = this;
		this.setCombos(data[1]);

		this.daemonMsg = E('div', { 'class': 'alert-message danger', 'style': 'display:none' });
		this.signedOutBox = E('div', { 'style': 'display:none' }, [ this.buildLogin() ]);
		injectLayoutStyle();
		/* two equal frames: Connection | Live chat (one column below 900 px) */
		this.connCard = E('div', { 'class': 'cbi-section gg-frame' }, this.buildConnCard());
		this.accountBox = this.buildAccount();
		/* the chat frame only exists while signed in */
		this.chatCol = E('div', { 'class': 'cbi-section gg-frame', 'style': 'display:none' });
		this.signedInBox = E('div', { 'style': 'display:none' }, [
			this.accountBox,
			E('div', { 'class': 'gg-frames' }, [
				this.connCard,
				this.chatCol
			])
		]);
		this.setSettings(data[2]);

		var root = E('div', {}, [
			E('h2', {}, _('GG Network')),
			this.daemonMsg,
			this.signedOutBox,
			this.signedInBox
		]);

		this.update(data[0]);

		poll.add(function() { return self.pollStatus(); }, 2);
		poll.add(function() {
			if (self.st && self.st.signed_in)
				return self.loadCombos();
		}, 60);
		poll.add(function() {
			if (self.st && self.st.signed_in && !self.presetBusy)
				return self.loadSettings();
		}, 15);
		window.setInterval(function() { self.tick(); }, 1000);

		return root;
	},

	handleSave: null,
	handleSaveApply: null,
	handleReset: null
});
