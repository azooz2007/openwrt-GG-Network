#!/bin/sh
# GG Network installer for OpenWrt releases that use apk (25.x / snapshot)
# or when you'd rather not use the .ipk:
#
#   tar -xzf ggnet-*-installer.tar.gz -C /tmp && sh /tmp/ggnet/install.sh
#   sh /tmp/ggnet/install.sh uninstall
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"

need_pkgs="kmod-nft-tproxy ca-bundle"

install_deps() {
	missing=""
	for p in $need_pkgs; do
		if command -v apk >/dev/null 2>&1; then
			apk info -e "$p" >/dev/null 2>&1 || missing="$missing $p"
		elif command -v opkg >/dev/null 2>&1; then
			opkg status "$p" 2>/dev/null | grep -q "^Status:.*installed" || missing="$missing $p"
		fi
	done
	[ -z "$missing" ] && return 0
	echo "Installing dependencies:$missing"
	if command -v apk >/dev/null 2>&1; then
		apk update && apk add $missing
	else
		opkg update && opkg install $missing
	fi
}

case "$1" in
uninstall)
	[ -x "$HERE/prerm" ] && "$HERE/prerm"
	( cd "$HERE/root" && find . -type f ) | while read -r f; do
		case "$f" in ./etc/config/ggnet) continue ;; esac
		rm -f "/${f#./}"
	done
	[ -x "$HERE/postrm" ] && "$HERE/postrm"
	echo "GG Network removed (settings kept in /etc/config/ggnet, sign-in in /etc/ggnet)."
	exit 0
	;;
esac

install_deps
[ -x /etc/init.d/ggnet ] && /etc/init.d/ggnet stop 2>/dev/null || true
# Keep an existing config.
[ -f /etc/config/ggnet ] && cp /etc/config/ggnet /tmp/ggnet.config.keep
( cd "$HERE/root" && tar -cf - . ) | ( cd / && tar -xf - )
[ -f /tmp/ggnet.config.keep ] && mv /tmp/ggnet.config.keep /etc/config/ggnet
"$HERE/postinst"
echo "GG Network installed. Open LuCI → Services → GG Network."
